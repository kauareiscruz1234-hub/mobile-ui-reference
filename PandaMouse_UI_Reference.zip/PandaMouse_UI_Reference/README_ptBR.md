# Referência visual — Panda Mouse Pro

Este pacote foi montado a partir do arquivo `Pandamouse.7z` enviado na conversa. O pacote contém **recursos Android decodificados** e uma seleção de **fontes Java reconstruídas pelo JADX** para consulta da interface; não é o projeto original do desenvolvedor.

## Identificação

- Nome no APK: **Panda Mouse Pro**
- ID do pacote: `com.panda.mouse`
- Implementação visual observada: **Activities e Views nativas de Android**, com layouts XML, drawables e Views customizadas.
- A busca por `ImGui` nos DEX, bibliotecas nativas e fontes reconstruídas não encontrou referências. O visual desse APK não aparenta ser feito com ImGui.

## O que está incluído

- `decoded_resources/res/`: 1.341 recursos decodificados — layouts, drawables, ícones, fontes, cores, temas, animações, menus e recursos relacionados.
- `decompiled_sources/sources/com/chaozhuo/gameassistant/`: 61 fontes Java selecionadas para as telas e Views da interface, incluindo o launcher e componentes do editor flutuante.
- `metadata/AndroidManifest.xml`: Manifest decodificado para consultar Activities e componentes declarados.
- `INVENTARIO_ARQUIVOS.md`: lista de todos os arquivos incluídos.

## Mapa visual encontrado

- **Entrada e tela inicial:** `SplashActivity`, `XActivity`, `activity_splash.xml`, `activity_home.xml` — cabeçalho, status do dispositivo/ativação e lista de jogos.
- **Adicionar e administrar jogos:** `activity_add_app.xml`, `item_add_app.xml`, `item_installed_app.xml`.
- **Perfis e configurações:** `activity_keymaps.xml`, `activity_settings.xml`, `advanced_settings.xml`, `activity_cloud_account.xml`.
- **Cursor e telas auxiliares:** `activity_cursors.xml`, `activity_connect_status.xml`, `activity_process.xml`.
- **Editor sobre o jogo:** `head_view_layout.xml`, `key_map_view.xml`, `key_view.xml`, `expanded_panel_layout.xml`, `expanded_panel_grid_view.xml`, `game_mode_layout.xml` e os `key_*_setting_dialog.xml`.
- **Peças do overlay:** `HeadView`, `FloatView`, `ExpandedPanel*View`, `KeyMapView`, `KeyView`, `SettingView`, `JoystickView`, `FireView`, `SightView`, `SwipeKeyView`, `ZoomKeyView`, `MacroKeyView`, entre outras.
- **Atalhos visuais:** a barra/cabeçalho do editor inclui ações de concluir, ativar/desativar, adicionar controle, abrir ajustes e trocar modo/layout. O nome de cada XML e View facilita localizar o componente correspondente.

## Limites importantes

1. **Não é fonte original nem projeto Android Studio pronto.** Layouts e recursos foram decodificados; o Java foi decompilado do bytecode. Métodos e classes internos aparecem obfuscados e algumas referências dependem de outras partes que não foram incluídas.
2. O JADX gerou arquivos, mas reportou **120 erros de decompilação** no APK completo. A seleção serve para estudo visual/arquitetural; pode haver trechos incorretos, incompletos ou difíceis de reutilizar.
3. As fontes selecionadas incluem callbacks de interface, mas **não incluem o mecanismo completo de mapeamento/injeção, serviço de ativação, scripts ADB, DEX/SO de injeção ou bibliotecas nativas**. Essas partes não são necessárias para estudar o visual solicitado.
4. Os nomes, ícones e elementos visuais do Panda Mouse podem estar protegidos por direitos autorais/marca. Para um aplicativo próprio, use o material como referência e crie uma identidade visual independente; confirme permissões antes de redistribuir qualquer asset ou código.

## Referências pesquisadas

- [Dear ImGui — repositório oficial](https://github.com/ocornut/imgui): biblioteca de GUI em C++ (licença MIT), com backend Android; fornece o toolkit, não um mapeador completo.
- [KeySync — GitHub](https://github.com/aka-munan/keysync): projeto Android aberto que descreve teclado/mouse externos mapeados para toques na tela; usa Shizuku. É uma referência de arquitetura de mapeador, não “só a interface”. Licença Apache-2.0 conforme o repositório.
- [XtMapper — documentação](https://xtr126.github.io/XtMapper-docs/guides/about/): mapeador aberto orientado principalmente a Android-x86/PC, com emulação mouse/teclado-para-toque; não é uma base direta para qualquer telefone Android.
- [Key Mapper — GitHub](https://github.com/keymapperorg/KeyMapper): app Android aberto para remapear botões/macros; não é exatamente um mapper de teclado/mouse para jogos. Licença GPL-3.0 no repositório.
- [FAQ oficial ASUS ROG](https://www.asus.com/us/support/faq/1040977/): descreve o recurso **Key Mapping** dentro do **Game Genie** para atribuir botões do ROG Kunai a pontos de toque. Isso indica uma função integrada ao ecossistema ROG, não uma source pública independente da ASUS.
- [Panda Mouse Pro na Google Play](https://play.google.com/store/apps/details?id=com.panda.mouse): usada para confirmar o nome comercial e o pacote identificado.
