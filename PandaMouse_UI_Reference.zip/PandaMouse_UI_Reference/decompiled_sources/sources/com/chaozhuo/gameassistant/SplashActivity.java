package com.chaozhuo.gameassistant;

import I1I1II.il1;
import ILL.Ilil11ILI;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.Iii;
import com.google.firebase.firestore.remote.iilli;
import com.panda.mouse.R;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import l1L1LI.Iii1lill1;
import p067il1.liIli;
import p080l11l.iI1;
import p090lLI1.iIiI1;
import p111lll.IL1i1iil;
import p111lll.llL;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SplashActivity extends BaseActivity {

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public boolean f7402Li;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public boolean f7403lLiLIli;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public static final String[] f7400iLLL = {"com.panda.mouseinject.dex", "com.panda.mouselibinject.so", "inject2.sh", "activate.sh", "nohup_activate.sh", "x64com.panda.mouselibinject.so", "x86_64com.panda.mouselibinject.so"};

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public static final String f7399i1LIiLLl = String.valueOf(liIli.f29528lILlii1L);
    public Iii II = null;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public boolean f7404lii1 = false;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public boolean f7401II1 = true;

    public final void IL() {
        iIiI1.f32587liIli.when(new iilli(this, 16)).done(new llL(this, 0));
    }

    public final void ii1() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        if (!this.f7402Li) {
            this.f7403lLiLIli = true;
            return;
        }
        this.f7403lLiLIli = false;
        startActivity(new Intent(this, (Class<?>) XActivity.class));
        finish();
    }

    /* JADX WARN: Code duplicated, block: B:120:0x01d0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:130:0x01fa A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:142:? A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) throws Throwable {
        boolean z;
        int i;
        char c;
        Throwable th;
        FileOutputStream fileOutputStream;
        InputStream inputStreamOpen;
        FileOutputStream fileOutputStream2;
        int i2 = Build.VERSION.SDK_INT;
        il1 ilil11ILI = i2 >= 31 ? new Ilil11ILI(this) : new il1(this);
        ilil11ILI.iilli();
        super.onCreate(bundle);
        int i3 = 7;
        ilil11ILI.ii1(new Iii1lill1(this, i3));
        char c2 = 1;
        getOnBackPressedDispatcher().liIli(new IL1i1iil(true), this);
        int i4 = 0;
        boolean z2 = i2 >= 33 && iLLLiIl1.iIiI1.liIli(this, "android.permission.POST_NOTIFICATIONS") != 0;
        setContentView(R.layout.activity_splash);
        File file = new File(XApp.f7417IiiiL.getExternalFilesDir(null), "scripts");
        if (!file.exists()) {
            file.mkdirs();
        }
        String strIlil11ILI = iI1.Ilil11ILI(new StringBuilder("kScriptsVersion"), f7399i1LIiLLl, "Copied");
        boolean z3 = XApp.f7417IiiiL.f7418ilI11.getBoolean(strIlil11ILI, false);
        boolean z4 = 0;
        int i5 = 0;
        while (i5 < i3) {
            String str = f7400iLLL[i5];
            File file2 = new File(file, str);
            if (!z3 && file2.exists()) {
                file2.delete();
            }
            if (file2.exists()) {
                z = z2;
                i = i4;
                c = c2;
            } else {
                XApp.f7417IiiiL.getClass();
                try {
                    inputStreamOpen = XApp.f7417IiiiL.getAssets().open(str);
                    c = c2;
                    try {
                        fileOutputStream2 = new FileOutputStream(file2);
                        try {
                            try {
                                byte[] bArr = new byte[8192];
                                while (true) {
                                    int i6 = inputStreamOpen.read(bArr);
                                    z = z2;
                                    if (i6 != -1) {
                                        try {
                                            fileOutputStream2.write(bArr, i4, i6);
                                            z2 = z;
                                        } catch (Exception e) {
                                            e = e;
                                            try {
                                                if (liIli.liIli.f33010ilI11) {
                                                    String str2 = "copy " + file2.getAbsolutePath() + " error";
                                                    i = i4;
                                                    try {
                                                        Object[] objArr = new Object[3];
                                                        objArr[i] = "INJECT";
                                                        objArr[c] = str2;
                                                        objArr[2] = e;
                                                        liIli.liIli.LI1lllLl("XApp", objArr);
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                        th = th;
                                                        fileOutputStream = fileOutputStream2;
                                                        if (fileOutputStream != null) {
                                                            try {
                                                                fileOutputStream.close();
                                                            } catch (IOException e2) {
                                                                if (liIli.liIli.f33010ilI11) {
                                                                    String str3 = "copy " + file2.getAbsolutePath() + " error";
                                                                    Object[] objArr2 = new Object[3];
                                                                    objArr2[i] = "INJECT";
                                                                    objArr2[c] = str3;
                                                                    objArr2[2] = e2;
                                                                    liIli.liIli.LI1lllLl("XApp", objArr2);
                                                                }
                                                            }
                                                        }
                                                        if (inputStreamOpen == null) {
                                                            throw th;
                                                        }
                                                        try {
                                                            inputStreamOpen.close();
                                                            throw th;
                                                        } catch (IOException e3) {
                                                            if (!liIli.liIli.f33010ilI11) {
                                                                throw th;
                                                            }
                                                            String str4 = "copy " + file2.getAbsolutePath() + " error";
                                                            Object[] objArr3 = new Object[3];
                                                            objArr3[i] = "INJECT";
                                                            objArr3[c] = str4;
                                                            objArr3[2] = e3;
                                                            liIli.liIli.LI1lllLl("XApp", objArr3);
                                                            throw th;
                                                        }
                                                    }
                                                } else {
                                                    i = i4;
                                                }
                                                if (fileOutputStream2 != null) {
                                                    try {
                                                        fileOutputStream2.close();
                                                    } catch (IOException e4) {
                                                        if (liIli.liIli.f33010ilI11) {
                                                            String str5 = "copy " + file2.getAbsolutePath() + " error";
                                                            Object[] objArr4 = new Object[3];
                                                            objArr4[i] = "INJECT";
                                                            objArr4[c] = str5;
                                                            objArr4[2] = e4;
                                                            liIli.liIli.LI1lllLl("XApp", objArr4);
                                                        }
                                                    }
                                                }
                                                if (inputStreamOpen != null) {
                                                    try {
                                                        inputStreamOpen.close();
                                                    } catch (IOException e5) {
                                                        if (liIli.liIli.f33010ilI11) {
                                                            String str6 = "copy " + file2.getAbsolutePath() + " error";
                                                            Object[] objArr5 = new Object[3];
                                                            objArr5[i] = "INJECT";
                                                            objArr5[c] = str6;
                                                            objArr5[2] = e5;
                                                            liIli.liIli.LI1lllLl("XApp", objArr5);
                                                        }
                                                    }
                                                }
                                                z4 = c;
                                                i5++;
                                                c2 = c;
                                                z2 = z;
                                                i4 = i;
                                                i3 = 7;
                                                z4 = z4;
                                            } catch (Throwable th3) {
                                                th = th3;
                                                i = i4;
                                            }
                                        }
                                    } else {
                                        try {
                                            break;
                                        } catch (IOException e6) {
                                            if (liIli.liIli.f33010ilI11) {
                                                String str7 = "copy " + file2.getAbsolutePath() + " error";
                                                Object[] objArr6 = new Object[3];
                                                objArr6[i4] = "INJECT";
                                                objArr6[c] = str7;
                                                objArr6[2] = e6;
                                                liIli.liIli.LI1lllLl("XApp", objArr6);
                                            }
                                        }
                                    }
                                }
                                fileOutputStream2.close();
                                try {
                                    inputStreamOpen.close();
                                } catch (IOException e7) {
                                    if (liIli.liIli.f33010ilI11) {
                                        String str8 = "copy " + file2.getAbsolutePath() + " error";
                                        Object[] objArr7 = new Object[3];
                                        objArr7[i4] = "INJECT";
                                        objArr7[c] = str8;
                                        objArr7[2] = e7;
                                        liIli.liIli.LI1lllLl("XApp", objArr7);
                                    }
                                }
                                i = i4;
                            } catch (Throwable th4) {
                                th = th4;
                                i = i4;
                                fileOutputStream = fileOutputStream2;
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                                if (inputStreamOpen == null) {
                                    throw th;
                                }
                                inputStreamOpen.close();
                                throw th;
                            }
                        } catch (Exception e8) {
                            e = e8;
                            z = z2;
                        }
                    } catch (Exception e9) {
                        e = e9;
                        z = z2;
                        fileOutputStream2 = null;
                    } catch (Throwable th5) {
                        th = th5;
                        i = i4;
                        fileOutputStream = null;
                        if (fileOutputStream != null) {
                            fileOutputStream.close();
                        }
                        if (inputStreamOpen == null) {
                            throw th;
                        }
                        inputStreamOpen.close();
                        throw th;
                    }
                } catch (Exception e10) {
                    e = e10;
                    z = z2;
                    c = c2;
                    fileOutputStream2 = null;
                    inputStreamOpen = null;
                } catch (Throwable th6) {
                    c = c2;
                    th = th6;
                    i = i4;
                    fileOutputStream = null;
                    inputStreamOpen = null;
                }
                z4 = c;
            }
            i5++;
            c2 = c;
            z2 = z;
            i4 = i;
            i3 = 7;
            z4 = z4;
        }
        boolean z5 = z2;
        boolean z6 = c2;
        if (!z3) {
            XApp.f7417IiiiL.f7418ilI11.edit().putBoolean(strIlil11ILI, z6).commit();
        }
        this.f7404lii1 = z4;
        if (z5) {
            iLLLiIl1.iIiI1.iI1(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
        } else {
            IL();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onPause() {
        this.f7402Li = false;
        super.onPause();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 10) {
            if ((iArr.length > 0 && iArr[0] == 0) || iLLLiIl1.iIiI1.liIli(this, "android.permission.POST_NOTIFICATIONS") == 0) {
                IL();
                return;
            }
            this.f7401II1 = false;
            IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(this, 2131951627);
            ilil11ILI.IL(R.string.permission_need);
            ilil11ILI.ILLl(R.string.permission_request);
            ((androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l).f3966ILLl = false;
            ilil11ILI.iilli(R.string.permission_grant, new III1.Iii1lill1(this, 5));
            Iii iiiII1 = ilil11ILI.iI1();
            this.II = iiiII1;
            iiiII1.show();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        super.onResume();
        this.f7402Li = true;
        if (this.II != null) {
            if (iLLLiIl1.iIiI1.liIli(this, "android.permission.POST_NOTIFICATIONS") == 0) {
                this.II = null;
                IL();
            } else {
                this.II.show();
            }
        }
        if (this.f7403lLiLIli) {
            ii1();
        }
    }
}
