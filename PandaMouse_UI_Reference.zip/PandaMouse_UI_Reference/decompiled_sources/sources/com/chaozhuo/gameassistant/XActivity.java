package com.chaozhuo.gameassistant;

import I1Ll1L.IiI1l;
import III1.Iii1lill1;
import IL1.Ilil11ILI;
import LILllili.l11lLIL;
import LILllili.lLii;
import android.R;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import androidx.core.widget.ILLl;
import com.chaozhuo.gameassistant.XActivity;
import com.chaozhuo.gameassistant.czkeymap.I1lI111LL;
import com.chaozhuo.gameassistant.czkeymap.bean.AppUpdateInfo;
import com.chaozhuo.gameassistant.czkeymap.iL;
import com.chaozhuo.gameassistant.handlecorrecte.CorrecteActivity;
import com.chaozhuo.gameassistant.homepage.ActivationActivity;
import com.chaozhuo.gameassistant.homepage.AdbShellActivity;
import com.chaozhuo.gameassistant.homepage.AddAppActivity;
import com.chaozhuo.gameassistant.homepage.CloudAccountActivity;
import com.chaozhuo.gameassistant.homepage.ConnectStatusActivity;
import com.chaozhuo.gameassistant.homepage.CursorsActivity;
import com.chaozhuo.gameassistant.homepage.DrawOverlayActivity;
import com.chaozhuo.gameassistant.homepage.KeymapsActivity;
import com.chaozhuo.gameassistant.homepage.ProcessActivity;
import com.chaozhuo.gameassistant.homepage.SettingsActivity;
import com.chaozhuo.gameassistant.homepage.il1;
import com.chaozhuo.gameassistant.homepage.widget.GameLauncherLayout;
import com.chaozhuo.gameassistant.homepage.widget.IndicatorView;
import com.chaozhuo.superme.R$string;
import com.chaozhuo.superme.client.liIli;
import com.google.android.gms.internal.consent_sdk.I1Ll1L;
import com.google.android.gms.internal.consent_sdk.iLIL;
import com.google.android.gms.internal.consent_sdk.iilli;
import com.google.android.gms.internal.consent_sdk.lLLlLlL;
import com.google.android.gms.internal.consent_sdk.lLliL;
import com.google.android.gms.internal.measurement.i1i1lILII;
import com.google.android.gms.internal.measurement.l1Li1i;
import com.google.android.ump.ConsentInformation$PrivacyOptionsRequirementStatus;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.internal.common.li1;
import com.google.firebase.firestore.Il1iLli;
import iILliI1I1.ILl;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.Executor;
import l1iILl1.Iii;
import org.jdeferred.DoneCallback;
import p047iIiii.IIlI;
import p047iIiii.LIIillI;
import p047iIiii.LILllili;
import p047iIiii.Ll11Ll;
import p047iIiii.ilI1LL;
import p090lLI1.iIiI1;
import p111lll.iLLLiIl1;
import p111lll.ilI;
import p111lll.ll1Li;
import p111lll.llL;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class XActivity extends LicenseCheckerActivity implements iL {
    public static WeakReference iiL;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public TextView f7405IIiiI;
    public boolean IIlII;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public ILl f7408LLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public ImageView f7409Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public ilI1LL f7410i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public IndicatorView f7411iLLL;
    public long iilL1Ll;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public int f7412ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public long f7413ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public TextView f7414lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public ILl f7415lIllIIiI;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public GameLauncherLayout f7416lLiLIli;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public boolean f7406IlLi = false;
    public int I1Ii1IilI = 0;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public final Ilil11ILI f7407LLIi = new Ilil11ILI(13);
    public final il1 iiIL1liI = new il1(this, 3);

    public final void I1lI111LL(final boolean z) {
        iIiI1.f32587liIli.when(new Runnable() { // from class: lll.II1llI
            @Override // java.lang.Runnable
            public final void run() {
                WeakReference weakReference = XActivity.iiL;
                liIli liili = liIli.f8581Iii;
                String string = liili.f8583Iii1lill1.getString(R$string.engine_process_name);
                List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) liili.f8583Iii1lill1.getSystemService("activity")).getRunningAppProcesses();
                if (runningAppProcesses != null) {
                    Iterator<ActivityManager.RunningAppProcessInfo> it = runningAppProcesses.iterator();
                    while (it.hasNext()) {
                        if (it.next().processName.endsWith(string)) {
                            IiI1l iiI1l = new IiI1l(liili.f8583Iii1lill1, lLll1L.liIli.f32910ilI11);
                            iiI1l.f178LLl1LlLL = "go_to_hell";
                            iiI1l.lLi1I = String.valueOf(z);
                            iiI1l.iI1();
                            return;
                        }
                    }
                }
            }
        }).done(new llL(this, 1));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.iL
    public final void ILl() {
        IndicatorView indicatorView;
        if (isFinishing() || isDestroyed() || (indicatorView = this.f7411iLLL) == null) {
            return;
        }
        indicatorView.liIli(this.f7406IlLi);
    }

    public final void L1i11iI(Message message) {
        ilI1LL ili1ll;
        int i = message.what;
        if (i != 1) {
            if (i == 2 && (ili1ll = this.f7410i1LIiLLl) != null) {
                this.f7410i1LIiLLl = null;
                Ll1LIL1l(ili1ll);
                return;
            }
            return;
        }
        String str = (String) message.obj;
        if (TextUtils.isEmpty(str)) {
            return;
        }
        li1.il1().getClass();
        if (li1.iL(str)) {
            return;
        }
        li1.il1().getClass();
        SharedPreferences sharedPreferences = XApp.f7417IiiiL.getSharedPreferences("com.chaozhuo.gameassistant_SP_APP_MANAGER", 0);
        String string = sharedPreferences.getString("KEY_APP_ADD_LIST", "");
        String[] strArrSplit = string.split(",");
        if (liIli.liIli.f33010ilI11) {
            liIli.liIli.LI1lllLl("AppRepository", "addApp pkg=", str);
        }
        if (!Arrays.asList(strArrSplit).contains(str)) {
            if (liIli.liIli.f33010ilI11) {
                liIli.liIli.LI1lllLl("AppRepository", "addApp 2 pkg=", str);
            }
            SharedPreferences.Editor editorEdit = sharedPreferences.edit();
            editorEdit.putString("KEY_APP_ADD_LIST", string + str + ",");
            editorEdit.commit();
        }
        try {
            I1lI111LL.f7502IiiiL.Iii1lill1().IIiiI(str);
        } catch (Exception unused) {
        }
        GameLauncherLayout gameLauncherLayout = this.f7416lLiLIli;
        li1.il1().getClass();
        gameLauncherLayout.setNewAppList(li1.iI1());
        Bundle bundle = new Bundle();
        bundle.putString("package_name", str);
        i1i1lILII i1i1lilii = FirebaseAnalytics.getInstance(XApp.f7417IiiiL).f25976liIli;
        i1i1lilii.getClass();
        i1i1lilii.liIli(new l1Li1i(i1i1lilii, (String) null, "game_added", bundle, false));
    }

    /* JADX WARN: Code duplicated, block: B:33:0x006d  */
    /* JADX WARN: Code duplicated, block: B:36:0x0073  */
    /* JADX WARN: Code duplicated, block: B:39:0x0088  */
    /* JADX WARN: Code duplicated, block: B:42:0x008f  */
    /* JADX WARN: Code duplicated, block: B:43:0x0091  */
    /* JADX WARN: Code duplicated, block: B:46:0x0098  */
    /* JADX WARN: Code duplicated, block: B:47:0x009a  */
    /* JADX WARN: Code duplicated, block: B:50:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:51:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:54:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:55:0x00ac  */
    /* JADX WARN: Code duplicated, block: B:58:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:59:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:62:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:65:0x00c1 A[FALL_THROUGH] */
    /* JADX WARN: Code duplicated, block: B:69:0x00d3  */
    /* JADX WARN: Switch 'out' block B:65:0x00c1 for B:32:0x006a already processed. Defaulting to fallback option. */
    /*  JADX ERROR: UnsupportedOperationException in pass: RegionMakerVisitor
        java.lang.UnsupportedOperationException
        	at java.base/java.util.Collections$UnmodifiableCollection.add(Collections.java:1092)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker$1.leaveRegion(SwitchRegionMaker.java:419)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:91)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:31)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.insertBreaksForCase(SwitchRegionMaker.java:399)
        	at jadx.core.dex.visitors.regions.maker.SwitchRegionMaker.insertBreaks(SwitchRegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.PostProcessRegions.leaveRegion(PostProcessRegions.java:31)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverseInternal(DepthRegionTraversal.java:91)
        	at jadx.core.dex.visitors.regions.DepthRegionTraversal.traverse(DepthRegionTraversal.java:27)
        	at jadx.core.dex.visitors.regions.PostProcessRegions.process(PostProcessRegions.java:21)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:31)
        */
    public final void Ll1LIL1l(p047iIiii.ilI1LL r17) {
        /*
            Method dump skipped, instruction units count: 348
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.chaozhuo.gameassistant.XActivity.Ll1LIL1l(iIiii.ilI1LL):void");
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002a  */
    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        boolean z;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            GameLauncherLayout gameLauncherLayout = this.f7416lLiLIli;
            if (gameLauncherLayout == null || !gameLauncherLayout.f8029LIIl) {
                z = false;
            } else {
                Rect rect = new Rect();
                gameLauncherLayout.getGlobalVisibleRect(rect);
                if (rect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                    z = false;
                } else {
                    z = true;
                }
            }
            this.IIlII = z;
        }
        if (!this.IIlII) {
            return super.dispatchTouchEvent(motionEvent);
        }
        if (actionMasked == 1) {
            this.f7416lLiLIli.setEditing(false);
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.IIlII = false;
        }
        return true;
    }

    public final void iLLLiIl1(Intent intent, boolean z) {
        startActivity(intent);
        if (z) {
            this.f7407LLIi.getClass();
            SharedPreferences sharedPreferences = getSharedPreferences("play_review", 0);
            Calendar calendar = Calendar.getInstance();
            String str = calendar.get(1) + "-" + calendar.get(6);
            String string = sharedPreferences.getString("first_mapping_day", "");
            SharedPreferences.Editor editorPutBoolean = sharedPreferences.edit().putBoolean("mapping_return_pending", true);
            if (string.isEmpty()) {
                editorPutBoolean.putString("first_mapping_day", str);
            } else if (!string.equals(str)) {
                editorPutBoolean.putBoolean("used_on_two_days", true);
            }
            editorPutBoolean.apply();
        }
    }

    public final boolean ii1() {
        GameLauncherLayout gameLauncherLayout;
        return (isFinishing() || isDestroyed() || !hasWindowFocus() || !this.f7406IlLi || this.f7410i1LIiLLl != null || (gameLauncherLayout = this.f7416lLiLIli) == null || gameLauncherLayout.f8029LIIl) ? false : true;
    }

    public final void ilI1() {
        boolean z = lLll1L.liIli.ll() > System.currentTimeMillis();
        Ilil11ILI ilil11ILI = new Ilil11ILI(this, 2131951627);
        androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
        ilil11ILI2.f3966ILLl = false;
        ilil11ILI2.f3983lILlii1L = "Support diagnostics";
        ilil11ILI.IiI1l(R.string.cancel, null);
        File file = new File(lLll1L.liIli.il().getParentFile(), p067il1.Ilil11ILI.f29472ILl);
        if (file.isFile()) {
            l11lLIL l11llil = new l11lLIL(this, this, file, 2);
            ilil11ILI2.f3984lLliL = "Share log";
            ilil11ILI2.f3974LI1Il = l11llil;
        }
        if (z) {
            ilil11ILI2.f3969Iii = "Disabling diagnostic logging will close Panda. The collected log will remain available for sharing.";
            ilil11ILI.Il1iLli("Disable", new iILliI1I1.liIli(this, 1));
        } else {
            ilil11ILI2.f3969Iii = "Enabling diagnostic logging will close Panda. Please reopen the app and reproduce the problem.";
            ilil11ILI.Il1iLli("Enable", new lLii(this, this, 7));
        }
        ilil11ILI.ii1();
    }

    public final void l1LLlI(ilI1LL ili1ll) {
        boolean zIL1i1iil;
        int i;
        if (isFinishing() || isDestroyed() || this.f7416lLiLIli.f8029LIIl) {
            return;
        }
        if (ili1ll instanceof IIlI) {
            startActivity(new Intent(this, (Class<?>) AddAppActivity.class));
            return;
        }
        try {
            zIL1i1iil = I1lI111LL.f7502IiiiL.Iii1lill1().IL1i1iil();
        } catch (Exception unused) {
            zIL1i1iil = false;
        }
        if (zIL1i1iil) {
            iILliI1I1.IiI1l iiI1l = iILliI1I1.IiI1l.f28393Iii1lill1;
            AppUpdateInfo appUpdateInfo = iiI1l.f28395liIli;
            AppUpdateInfo appUpdateInfo2 = null;
            if (appUpdateInfo != null && appUpdateInfo.updateAvailable && (i = appUpdateInfo.latestVersionCode) > 0 && i > 1400 && !TextUtils.isEmpty(appUpdateInfo.updateUrl)) {
                SharedPreferences sharedPreferences = XApp.f7417IiiiL.getSharedPreferences("update_pref", 0);
                if (iiI1l.f28395liIli.forceUpdate || sharedPreferences.getInt("APP_UPDATE_IGNORED_VERSION_googleps", 0) != iiI1l.f28395liIli.latestVersionCode) {
                    appUpdateInfo2 = iiI1l.f28395liIli;
                }
            }
            if (appUpdateInfo2 != null) {
                Ilil11ILI ilil11ILI = new Ilil11ILI(this, 2131951627);
                androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                ilil11ILI2.f3983lILlii1L = TextUtils.isEmpty(appUpdateInfo2.title) ? getString(com.panda.mouse.R.string.update_title) : appUpdateInfo2.title;
                ilil11ILI2.f3969Iii = TextUtils.isEmpty(appUpdateInfo2.message) ? getString(com.panda.mouse.R.string.update_content) : appUpdateInfo2.message;
                ilil11ILI.iilli(com.panda.mouse.R.string.button_update, new lLii(this, appUpdateInfo2, 6));
                ilil11ILI.IiI1l(appUpdateInfo2.forceUpdate ? com.panda.mouse.R.string.dialog_cancel : com.panda.mouse.R.string.button_ignore, new Iii1lill1(appUpdateInfo2, 6));
                ilil11ILI2.f3966ILLl = false;
                ilil11ILI.ii1();
                return;
            }
            if (((PowerManager) getSystemService("power")).isIgnoringBatteryOptimizations(getPackageName()) || DrawOverlayActivity.f7868iil) {
                boolean z = p049iL1.iL.f28845iIiI1.f28848Iii1lill1;
                if ((Settings.canDrawOverlays(this) || DrawOverlayActivity.f7869lll) && ((lLLli11iI.ILl.Il1iLli() != 0 || DrawOverlayActivity.f7867Ll1) && this.f7406IlLi)) {
                    Ll1LIL1l(ili1ll);
                    return;
                }
            }
            startActivity(new Intent(this, (Class<?>) DrawOverlayActivity.class));
            this.f7410i1LIiLLl = ili1ll;
        }
    }

    public final void lIIl(ilI1LL ili1ll) {
        if (ili1ll instanceof Ll11Ll) {
            iLLLiIl1.f33263Ll1LIL1l.f33283liIli = true;
            startActivity(new Intent(this, (Class<?>) CorrecteActivity.class));
            return;
        }
        if (ili1ll instanceof LIIillI) {
            iLLLiIl1.f33263Ll1LIL1l.f33283liIli = true;
            startActivity(new Intent(this, (Class<?>) AdbShellActivity.class));
        } else if (ili1ll instanceof LILllili) {
            iLLLiIl1.f33263Ll1LIL1l.f33283liIli = true;
            startActivity(new Intent(this, (Class<?>) ProcessActivity.class));
        } else {
            iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
            ll1Li ll1li = new ll1Li(this, ili1ll, 1);
            illliil1.getClass();
            ll1li.run();
        }
    }

    public final void lL() {
        int displayId = getWindowManager().getDefaultDisplay().getDisplayId();
        if (liIli.liIli.f33010ilI11) {
            liIli.liIli.Il("XActivity", "target displayId: ", Integer.valueOf(displayId));
        }
        try {
            I1lI111LL.f7502IiiiL.Iii1lill1().lLL1L111l(displayId);
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void llL() {
        boolean zIlil11ILI = I1lI111LL.f7502IiiiL.Ilil11ILI();
        TextView textView = this.f7405IIiiI;
        if (textView != null) {
            textView.setText(zIlil11ILI ? com.panda.mouse.R.string.pro_plus_active : com.panda.mouse.R.string.pro_plus_upgrade);
            int color = getResources().getColor(zIlil11ILI ? com.panda.mouse.R.color.color_primary : com.panda.mouse.R.color.text_primary, null);
            this.f7405IIiiI.setTextColor(color);
            TextView textView2 = this.f7405IIiiI;
            ColorStateList colorStateListValueOf = ColorStateList.valueOf(color);
            textView2.getClass();
            if (Build.VERSION.SDK_INT >= 24) {
                textView2.setCompoundDrawableTintList(colorStateListValueOf);
            } else if (textView2 instanceof ILLl) {
                ((ILLl) textView2).setSupportCompoundDrawablesTintList(colorStateListValueOf);
            }
        }
        TextView textView3 = this.f7414lIL;
        if (textView3 != null) {
            textView3.setText(zIlil11ILI ? com.panda.mouse.R.string.pro_plus_home_active_description : com.panda.mouse.R.string.pro_plus_home_description);
        }
        iLLLiIl1.f33263Ll1LIL1l.Iii1lill1();
    }

    @Override // com.chaozhuo.gameassistant.LicenseCheckerActivity, com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        boolean zLiii1;
        super.onCreate(bundle);
        setContentView(com.panda.mouse.R.layout.activity_home);
        View viewFindViewById = findViewById(com.panda.mouse.R.id.id_root_layout);
        final int i = 2;
        final int i2 = 1;
        final int i3 = 0;
        if (liIli.liIli.f33010ilI11) {
            liIli.liIli.Il("XActivity", "channel=", "googleps");
        }
        I1lI111LL i1lI111LL = I1lI111LL.f7502IiiiL;
        try {
            zLiii1 = i1lI111LL.Iii1lill1().Liii1();
        } catch (Exception unused) {
            zLiii1 = false;
        }
        this.f7406IlLi = zLiii1;
        try {
            i1lI111LL.Iii1lill1().lLLL1Il(this.iiIL1liI);
        } catch (Exception unused2) {
        }
        this.I1Ii1IilI = liIli.f8581Iii.liIli();
        TextView textView = (TextView) viewFindViewById.findViewById(com.panda.mouse.R.id.text_title);
        final int i4 = 3;
        textView.setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i5) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i6 = xActivity.f7412ilL;
                            if (i6 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i7 = i6 + 1;
                                xActivity.f7412ilL = i7;
                                if (i7 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i8 = 0;
                                final int i9 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i8) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i10 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i10) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i11 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i11) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i9) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        textView.setText(((Object) getText(com.panda.mouse.R.string.app_name)) + " 14");
        ImageView imageView = (ImageView) viewFindViewById.findViewById(com.panda.mouse.R.id.image_more);
        this.f7409Li = imageView;
        final int i5 = 5;
        imageView.setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i6 = i5;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i6) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i7 = xActivity.f7412ilL;
                            if (i7 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i8 = i7 + 1;
                                xActivity.f7412ilL = i8;
                                if (i8 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i9 = 0;
                                final int i10 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i9) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i11 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i11) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i12 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i12) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i10) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        LinearLayout linearLayout = (LinearLayout) viewFindViewById.findViewById(com.panda.mouse.R.id.layout_footer);
        IndicatorView indicatorView = (IndicatorView) viewFindViewById.findViewById(com.panda.mouse.R.id.indicator_header);
        this.f7411iLLL = indicatorView;
        final int i6 = 6;
        View.OnClickListener onClickListener = new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i7 = i6;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i7) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i8 = xActivity.f7412ilL;
                            if (i8 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i9 = i8 + 1;
                                xActivity.f7412ilL = i9;
                                if (i9 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i10 = 0;
                                final int i11 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i10) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i12 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i12) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i13 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i13) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i11) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        };
        final int i7 = 7;
        View.OnClickListener onClickListener2 = new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i8 = i7;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i8) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i9 = xActivity.f7412ilL;
                            if (i9 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i10 = i9 + 1;
                                xActivity.f7412ilL = i10;
                                if (i10 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i11 = 0;
                                final int i12 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i11) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i13 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i13) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i14 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i14) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i12) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        };
        View viewFindViewById2 = indicatorView.findViewById(com.panda.mouse.R.id.layout1);
        viewFindViewById2.setOnClickListener(onClickListener);
        viewFindViewById2.setClickable(true);
        indicatorView.findViewById(com.panda.mouse.R.id.arrow1).setVisibility(0);
        indicatorView.findViewById(com.panda.mouse.R.id.layout2).setOnClickListener(onClickListener2);
        GameLauncherLayout gameLauncherLayout = (GameLauncherLayout) viewFindViewById.findViewById(com.panda.mouse.R.id.layout_game_launcher);
        this.f7416lLiLIli = gameLauncherLayout;
        gameLauncherLayout.setColumnCount(getResources().getInteger(com.panda.mouse.R.integer.game_launcher_column_count));
        this.f7416lLiLIli.setOnItemActionListener(new iLll1LIL.liIli(this));
        LayoutInflater.from(this).inflate(com.panda.mouse.R.layout.advanced_settings, linearLayout);
        View viewFindViewById3 = linearLayout.findViewById(com.panda.mouse.R.id.id_manage_cursors);
        View viewFindViewById4 = linearLayout.findViewById(com.panda.mouse.R.id.id_gamepad_calibration);
        final int i8 = 8;
        linearLayout.findViewById(com.panda.mouse.R.id.id_settings).setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i9 = i8;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i9) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i10 = xActivity.f7412ilL;
                            if (i10 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i11 = i10 + 1;
                                xActivity.f7412ilL = i11;
                                if (i11 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i12 = 0;
                                final int i13 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i12) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i14 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i14) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i15 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i15) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i13) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        final int i9 = 9;
        linearLayout.findViewById(com.panda.mouse.R.id.id_manage_keymaps).setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i10 = i9;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i10) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i11 = xActivity.f7412ilL;
                            if (i11 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i12 = i11 + 1;
                                xActivity.f7412ilL = i12;
                                if (i12 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i13 = 0;
                                final int i14 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i13) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i15 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i15) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i16 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i16) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i14) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        final int i10 = 10;
        viewFindViewById3.setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i11 = i10;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i11) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i12 = xActivity.f7412ilL;
                            if (i12 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i13 = i12 + 1;
                                xActivity.f7412ilL = i13;
                                if (i13 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i14 = 0;
                                final int i15 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i14) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i16 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i16) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i17 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i17) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i15) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        viewFindViewById4.setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i11 = i3;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i11) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i12 = xActivity.f7412ilL;
                            if (i12 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i13 = i12 + 1;
                                xActivity.f7412ilL = i13;
                                if (i13 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i14 = 0;
                                final int i15 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i14) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i16 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i16) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i17 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i17) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i15) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        linearLayout.findViewById(com.panda.mouse.R.id.id_adb_shell).setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i11 = i2;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i11) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i12 = xActivity.f7412ilL;
                            if (i12 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i13 = i12 + 1;
                                xActivity.f7412ilL = i13;
                                if (i13 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i14 = 0;
                                final int i15 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i14) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i16 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i16) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i17 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i17) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i15) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        linearLayout.findViewById(com.panda.mouse.R.id.id_process_info).setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i11 = i;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i11) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i12 = xActivity.f7412ilL;
                            if (i12 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i13 = i12 + 1;
                                xActivity.f7412ilL = i13;
                                if (i13 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i14 = 0;
                                final int i15 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i14) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i16 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i16) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i17 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i17) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i15) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        final int i11 = 4;
        linearLayout.findViewById(com.panda.mouse.R.id.id_pro_plus).setOnClickListener(new View.OnClickListener(this) { // from class: lll.li1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ XActivity f33303IiiiL;

            {
                this.f33303IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i12 = i11;
                boolean z = false;
                final XActivity xActivity = this.f33303IiiiL;
                switch (i12) {
                    case 0:
                        WeakReference weakReference = XActivity.iiL;
                        xActivity.l1LLlI(new Ll11Ll());
                        break;
                    case 1:
                        WeakReference weakReference2 = XActivity.iiL;
                        xActivity.l1LLlI(new LIIillI());
                        break;
                    case 2:
                        WeakReference weakReference3 = XActivity.iiL;
                        xActivity.l1LLlI(new LILllili());
                        break;
                    case 3:
                        WeakReference weakReference4 = XActivity.iiL;
                        if (lLll1L.liIli.ll() <= System.currentTimeMillis()) {
                            long jElapsedRealtime = SystemClock.elapsedRealtime();
                            int i13 = xActivity.f7412ilL;
                            if (i13 != 0 && jElapsedRealtime - xActivity.iilL1Ll <= 5000) {
                                int i14 = i13 + 1;
                                xActivity.f7412ilL = i14;
                                if (i14 >= 7) {
                                    xActivity.f7412ilL = 0;
                                    EditText editText = new EditText(new p067il1.ILLl(xActivity, 2131951627));
                                    editText.setSingleLine(true);
                                    editText.setInputType(1);
                                    editText.setHint("Input code...");
                                    Ilil11ILI ilil11ILI = new Ilil11ILI(xActivity, 2131951627);
                                    androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                                    ilil11ILI2.f3966ILLl = false;
                                    ilil11ILI2.f3983lILlii1L = "Support diagnostics";
                                    ilil11ILI2.f3973L1i11iI = editText;
                                    ilil11ILI2.f3979ii1 = 0;
                                    ilil11ILI.IiI1l(R.string.cancel, null);
                                    ilil11ILI.iilli(R.string.ok, new l11lLIL(xActivity, editText, xActivity));
                                    ilil11ILI.ii1();
                                }
                            } else {
                                xActivity.iilL1Ll = jElapsedRealtime;
                                xActivity.f7412ilL = 1;
                            }
                        } else {
                            xActivity.ilI1();
                        }
                        break;
                    case 4:
                        WeakReference weakReference5 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                    case 5:
                        WeakReference weakReference6 = XActivity.iiL;
                        PopupMenu popupMenu = new PopupMenu(xActivity, xActivity.f7409Li);
                        popupMenu.getMenuInflater().inflate(com.panda.mouse.R.menu.x_activity_menu, popupMenu.getMenu());
                        MenuItem menuItemFindItem = popupMenu.getMenu().findItem(com.panda.mouse.R.id.menu_item_privacy_options);
                        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
                        illliil1.getClass();
                        if (!I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil1.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                            z = true;
                        }
                        menuItemFindItem.setVisible(z);
                        if (Build.VERSION.SDK_INT >= 28) {
                            popupMenu.getMenu().setGroupDividerEnabled(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: lll.LIIlL
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                XActivity xActivity2 = xActivity;
                                WeakReference weakReference7 = XActivity.iiL;
                                int itemId = menuItem.getItemId();
                                final int i15 = 0;
                                final int i16 = 1;
                                if (itemId != com.panda.mouse.R.id.menu_item_privacy_options) {
                                    if (itemId != com.panda.mouse.R.id.menu_item_exit) {
                                        return false;
                                    }
                                    xActivity2.I1lI111LL(false);
                                    return true;
                                }
                                iLLLiIl1 illliil2 = iLLLiIl1.f33263Ll1LIL1l;
                                illliil2.getClass();
                                if (!iLLLiIl1.liIli(xActivity2) && !I1lI111LL.f7502IiiiL.Ilil11ILI() && illliil2.f33264IL.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.REQUIRED) {
                                    final L1i11iI l1i11iI = new L1i11iI(illliil2, 0);
                                    iilli iilliVar = (iilli) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20730ILl).zzb();
                                    iilliVar.getClass();
                                    com.google.android.gms.internal.consent_sdk.LIIlL.liIli();
                                    lLLlLlL lllllll = (lLLlLlL) ((I1Ll1L) com.google.android.gms.internal.consent_sdk.Ilil11ILI.l1LLlI(xActivity2).f20735iL).zzb();
                                    if (lllllll == null) {
                                        com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                switch (i15) {
                                                    case 0:
                                                        l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                        break;
                                                    case 1:
                                                        l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                        break;
                                                    case 2:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                        break;
                                                    default:
                                                        l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                        break;
                                                }
                                            }
                                        });
                                        return true;
                                    }
                                    if (lllllll.f20883Ilil11ILI.f20810Ilil11ILI.get() != null || lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                        if (lllllll.Iii1lill1() == ConsentInformation$PrivacyOptionsRequirementStatus.NOT_REQUIRED) {
                                            final int i17 = 2;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i17) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lLliL lllil = (lLliL) iilliVar.f20811lILlii1L.get();
                                        if (lllil == null) {
                                            final int i18 = 3;
                                            com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                                @Override // java.lang.Runnable
                                                public final void run() {
                                                    switch (i18) {
                                                        case 0:
                                                            l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                            break;
                                                        case 1:
                                                            l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                            break;
                                                        case 2:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                            break;
                                                        default:
                                                            l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                            break;
                                                    }
                                                }
                                            });
                                            return true;
                                        }
                                        lllil.liIli(xActivity2, l1i11iI);
                                        iilliVar.f20809Iii1lill1.execute(new com.google.android.gms.internal.consent_sdk.iL(iilliVar, 1));
                                        return true;
                                    }
                                    com.google.android.gms.internal.consent_sdk.LIIlL.f20752liIli.post(new Runnable() { // from class: com.google.android.gms.internal.consent_sdk.ILLl
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            switch (i16) {
                                                case 0:
                                                    l1i11iI.liIli(new zzg(1, "No consentInformation.").zza());
                                                    break;
                                                case 1:
                                                    l1i11iI.liIli(new zzg(3, "No valid response received yet.").zza());
                                                    break;
                                                case 2:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is not required.").zza());
                                                    break;
                                                default:
                                                    l1i11iI.liIli(new zzg(3, "Privacy options form is being loading. Please try again later.").zza());
                                                    break;
                                            }
                                        }
                                    });
                                    if (lllllll.lILlii1L()) {
                                        synchronized (lllllll.f20880ILl) {
                                            z2 = lllllll.f20885iL;
                                        }
                                        if (!z2) {
                                            lllllll.Ilil11ILI(true);
                                            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI3 = lllllll.f20882Iii1lill1;
                                            Iii iii2 = lllllll.f20886il1;
                                            iLIL ilil = new iLIL(lllllll);
                                            iLIL ilil2 = new iLIL(lllllll);
                                            ilil11ILI3.getClass();
                                            ((Executor) ilil11ILI3.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI3, xActivity2, iii2, ilil, ilil2, 2));
                                            return true;
                                        }
                                    }
                                    Log.w("UserMessagingPlatform", "Retry request is not executed. consentInfoUpdateHasBeenCalled=" + lllllll.lILlii1L() + ", retryRequestIsInProgress=" + lllllll.ILl());
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        break;
                    case 6:
                        WeakReference weakReference7 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ConnectStatusActivity.class));
                        break;
                    case 7:
                        WeakReference weakReference8 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) ActivationActivity.class));
                        break;
                    case 8:
                        WeakReference weakReference9 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) SettingsActivity.class));
                        break;
                    case 9:
                        WeakReference weakReference10 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) KeymapsActivity.class));
                        break;
                    default:
                        WeakReference weakReference11 = XActivity.iiL;
                        xActivity.getClass();
                        xActivity.startActivity(new Intent(xActivity, (Class<?>) CursorsActivity.class));
                        break;
                }
            }
        });
        viewFindViewById3.setVisibility(0);
        linearLayout.findViewById(com.panda.mouse.R.id.manage_cursors_divider).setVisibility(0);
        viewFindViewById4.setVisibility(8);
        linearLayout.findViewById(com.panda.mouse.R.id.gamepad_calibration_divider).setVisibility(8);
        IndicatorView indicatorView2 = this.f7411iLLL;
        if (indicatorView2 != null) {
            indicatorView2.liIli(this.f7406IlLi);
        }
        iILliI1I1.IiI1l iiI1l = iILliI1I1.IiI1l.f28393Iii1lill1;
        final SharedPreferences sharedPreferences = XApp.f7417IiiiL.getSharedPreferences("update_pref", 0);
        final long jCurrentTimeMillis = System.currentTimeMillis();
        String string = sharedPreferences.getString("APP_UPDATE_CONTENT", "");
        if (TextUtils.isEmpty(string)) {
            iiI1l.f28395liIli = null;
        } else {
            try {
                iiI1l.f28395liIli = (AppUpdateInfo) iILliI1I1.IiI1l.f28394Ilil11ILI.Ilil11ILI(AppUpdateInfo.class, string);
            } catch (Exception unused3) {
                iiI1l.f28395liIli = null;
            }
        }
        if (jCurrentTimeMillis - sharedPreferences.getLong("APP_UPDATE_TIMESTAMP", 0L) >= 14400000) {
            iIiI1.f32587liIli.when(new com.google.common.util.concurrent.ll1Li(i2)).done(new DoneCallback() { // from class: iILliI1I1.ILLl
                {
                    IiI1l iiI1l2 = IiI1l.f28393Iii1lill1;
                }

                @Override // org.jdeferred.DoneCallback
                public final void onDone(Object obj) {
                    IiI1l iiI1l2 = IiI1l.f28393Iii1lill1;
                    AppUpdateInfo appUpdateInfo = (AppUpdateInfo) obj;
                    com.google.gson.ILl iLl = IiI1l.f28394Ilil11ILI;
                    if (appUpdateInfo == null) {
                        return;
                    }
                    if (liIli.liIli.f33010ilI11) {
                        liIli.liIli.Il("UpdateHelper", "checkAppUpdate: ", iLl.Iii(appUpdateInfo));
                    }
                    iiI1l2.f28395liIli = appUpdateInfo;
                    sharedPreferences.edit().putLong("APP_UPDATE_TIMESTAMP", jCurrentTimeMillis).putString("APP_UPDATE_CONTENT", iLl.Iii(appUpdateInfo)).apply();
                }
            });
        }
        com.chaozhuo.gameassistant.czkeymap.il1.liIli().f7572ilI11.add(this);
        GameLauncherLayout gameLauncherLayout2 = this.f7416lLiLIli;
        li1.il1().getClass();
        gameLauncherLayout2.setNewAppList(li1.iI1());
        this.f7405IIiiI = (TextView) linearLayout.findViewById(com.panda.mouse.R.id.id_pro_plus_title);
        this.f7414lIL = (TextView) linearLayout.findViewById(com.panda.mouse.R.id.id_pro_plus_info);
        this.f7408LLi = new ILl(new lIl1Ll.Ilil11ILI(this));
        this.f7415lIllIIiI = new ILl(new ilI(this));
        iLLLiIl1 illliil1 = iLLLiIl1.f33263Ll1LIL1l;
        illliil1.f33274iI1 = this;
        illliil1.f33282lLliL = (FrameLayout) viewFindViewById.findViewById(com.panda.mouse.R.id.id_banner_container);
        illliil1.f33273LI1Il = viewFindViewById.findViewById(com.panda.mouse.R.id.id_pro_plus_trial);
        illliil1.f33265ILLl = viewFindViewById.findViewById(com.panda.mouse.R.id.pro_plus_trial_divider);
        illliil1.f33267IiI1l = (TextView) viewFindViewById.findViewById(com.panda.mouse.R.id.id_pro_plus_trial_title);
        illliil1.f33278iilli = (TextView) viewFindViewById.findViewById(com.panda.mouse.R.id.id_pro_plus_trial_info);
        int i12 = 12;
        illliil1.f33273LI1Il.setOnClickListener(new L11L.iL(illliil1, i12));
        illliil1.lILlii1L();
        illliil1.Ilil11ILI(false);
        if (!I1lI111LL.f7502IiiiL.Ilil11ILI()) {
            Iii iii2 = new Iii(i11);
            lLLlLlL lllllll = illliil1.f33264IL;
            IIlLll1.Iii iii3 = new IIlLll1.Iii(i12, illliil1, this);
            Il1iLli il1iLli = new Il1iLli(22);
            synchronized (lllllll.f20887lILlii1L) {
                lllllll.f20884iIiI1 = true;
            }
            lllllll.f20886il1 = iii2;
            ((Queue) lllllll.f20881Iii.f20861Iii.get()).add(Long.valueOf(System.currentTimeMillis()));
            com.google.android.gms.internal.consent_sdk.Ilil11ILI ilil11ILI = lllllll.f20882Iii1lill1;
            ilil11ILI.getClass();
            ((Executor) ilil11ILI.f20733Ilil11ILI).execute(new ILLl1i.liIli(ilil11ILI, this, iii2, iii3, il1iLli, 2));
        }
        llL();
        BaseActivity.Il1iLli(findViewById(com.panda.mouse.R.id.id_home_header), viewFindViewById);
        new Handler().postDelayed(new com.google.firebase.firestore.remote.iilli(this, 17), 200L);
        lL();
        iiL = new WeakReference(this);
        getOnBackPressedDispatcher().liIli(new androidx.fragment.app.ilI(this, i4), this);
    }

    @Override // com.chaozhuo.gameassistant.LicenseCheckerActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onDestroy() {
        ILl iLl = this.f7408LLi;
        if (iLl != null) {
            iLl.Iii1lill1();
            this.f7408LLi = null;
        }
        ILl iLl2 = this.f7415lIllIIiI;
        if (iLl2 != null) {
            iLl2.Iii1lill1();
            this.f7415lIllIIiI = null;
        }
        com.chaozhuo.gameassistant.czkeymap.il1.liIli().f7572ilI11.remove(this);
        I1lI111LL i1lI111LL = I1lI111LL.f7502IiiiL;
        try {
            i1lI111LL.Iii1lill1().lIIiI(this.iiIL1liI);
        } catch (Exception unused) {
        }
        super.onDestroy();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onPause() {
        Ilil11ILI ilil11ILI = this.f7407LLIi;
        ilil11ILI.f673IiiiL++;
        ((Handler) ilil11ILI.f675lLL1L111l).removeCallbacksAndMessages(null);
        super.onPause();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        boolean zLiii1;
        super.onResume();
        lL();
        llL();
        int iLiIli = liIli.f8581Iii.liIli();
        if (this.I1Ii1IilI != iLiIli) {
            I1lI111LL i1lI111LL = I1lI111LL.f7502IiiiL;
            try {
                zLiii1 = i1lI111LL.Iii1lill1().Liii1();
            } catch (Exception unused) {
                zLiii1 = false;
            }
            this.f7406IlLi = zLiii1;
            try {
                i1lI111LL.Iii1lill1().lLLL1Il(this.iiIL1liI);
            } catch (Exception unused2) {
            }
            this.I1Ii1IilI = iLiIli;
            ILl();
        }
        Intent intent = new Intent("com.chaozhuo.gameassistant.ACTION_START_UP");
        intent.putExtra("package_start_up", getPackageName());
        sendBroadcast(intent);
        Ilil11ILI ilil11ILI = this.f7407LLIi;
        int i = ilil11ILI.f673IiiiL;
        Handler handler = (Handler) ilil11ILI.f675lLL1L111l;
        ilil11ILI.f673IiiiL = i + 1;
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(new L11.Iii1lill1(ilil11ILI, new WeakReference(this), ilil11ILI.f673IiiiL, 5), 1000L);
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
    }
}
