package com.chaozhuo.gameassistant.czkeymap.bean;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.chaozhuo.gameassistant.convert.bean.CommandInfo;
import com.chaozhuo.gameassistant.convert.bean.PathInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeyInfo implements Parcelable {
    public static final Parcelable.Creator<KeyInfo> CREATOR = new Parcelable.Creator<KeyInfo>() { // from class: com.chaozhuo.gameassistant.czkeymap.bean.KeyInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyInfo createFromParcel(Parcel parcel) {
            return new KeyInfo(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyInfo[] newArray(int i) {
            return new KeyInfo[i];
        }
    };
    public int args;
    public int args2;
    public String args3;
    public String displayIcon;
    public String displayName;
    public int keyCode;
    public String keyName;
    public int modifier;
    public int operate;
    public float radiusRatio;
    public String specialClass;
    public int totalTime;
    public int type;
    public List<KeyPosInfo> keyPosList = new ArrayList();
    public List<PathInfo> path = new ArrayList();
    public List<CommandInfo> commands = new ArrayList();

    public KeyInfo() {
    }

    public void clearKeyCode() {
        this.keyCode = 0;
        this.modifier = 0;
        this.keyName = "";
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        KeyInfo keyInfo = (KeyInfo) obj;
        if (this.keyCode != keyInfo.keyCode || this.modifier != keyInfo.modifier || this.type != keyInfo.type || this.radiusRatio != keyInfo.radiusRatio || this.operate != keyInfo.operate || this.totalTime != keyInfo.totalTime || this.args != keyInfo.args || this.args2 != keyInfo.args2 || !TextUtils.equals(this.args3, keyInfo.args3) || !TextUtils.equals(this.keyName, keyInfo.keyName) || !TextUtils.equals(this.displayIcon, keyInfo.displayIcon) || !TextUtils.equals(this.displayName, keyInfo.displayName) || !TextUtils.equals(this.specialClass, keyInfo.specialClass) || this.keyPosList.size() != keyInfo.keyPosList.size()) {
            return false;
        }
        for (int i = 0; i < this.keyPosList.size(); i++) {
            if (!this.keyPosList.get(i).equals(keyInfo.keyPosList.get(i))) {
                return false;
            }
        }
        return this.path.equals(keyInfo.path) && this.commands.equals(keyInfo.commands);
    }

    public int hashCode() {
        int i = this.keyCode * 31;
        String str = this.keyName;
        int iHashCode = (i + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.displayIcon;
        int iHashCode2 = (iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.displayName;
        int iHashCode3 = (((iHashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31) + this.modifier) * 31;
        String str4 = this.specialClass;
        int iHashCode4 = (((((iHashCode3 + (str4 != null ? str4.hashCode() : 0)) * 31) + this.type) * 31) + (Float.compare(this.radiusRatio, 0.0f) != 0 ? Float.floatToIntBits(this.radiusRatio) : 0)) * 31;
        List<KeyPosInfo> list = this.keyPosList;
        int iHashCode5 = (((((((((iHashCode4 + (list != null ? list.hashCode() : 0)) * 31) + this.operate) * 31) + this.totalTime) * 31) + this.args) * 31) + this.args2) * 31;
        String str5 = this.args3;
        int iHashCode6 = (iHashCode5 + (str5 != null ? str5.hashCode() : 0)) * 31;
        List<PathInfo> list2 = this.path;
        int iHashCode7 = (iHashCode6 + (list2 != null ? list2.hashCode() : 0)) * 31;
        List<CommandInfo> list3 = this.commands;
        return iHashCode7 + (list3 != null ? list3.hashCode() : 0);
    }

    public String toString() {
        return "KeyInfo{keyCode=" + this.keyCode + ", keyName='" + this.keyName + "', displayIcon='" + this.displayIcon + "', displayName='" + this.displayName + "', modifier=" + this.modifier + ", specialClass='" + this.specialClass + "', type=" + this.type + ", radiusRatio=" + this.radiusRatio + ", keyPosList=" + this.keyPosList + ", operate=" + this.operate + ", totalTime=" + this.totalTime + ", args=" + this.args + ", args2=" + this.args2 + ", args3=" + this.args3 + ", path=" + this.path + ", commands=" + this.commands + '}';
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.keyCode);
        parcel.writeString(this.keyName);
        parcel.writeString(this.displayIcon);
        parcel.writeString(this.displayName);
        parcel.writeInt(this.modifier);
        parcel.writeString(this.specialClass);
        parcel.writeInt(this.type);
        parcel.writeFloat(this.radiusRatio);
        parcel.writeList(this.keyPosList);
        parcel.writeInt(this.operate);
        parcel.writeInt(this.totalTime);
        parcel.writeInt(this.args);
        parcel.writeInt(this.args2);
        parcel.writeString(this.args3);
        parcel.writeList(this.path);
        parcel.writeList(this.commands);
    }

    public KeyInfo(KeyInfo keyInfo) {
        this.keyCode = keyInfo.keyCode;
        this.keyName = keyInfo.keyName;
        this.displayIcon = keyInfo.displayIcon;
        this.displayName = keyInfo.displayName;
        this.modifier = keyInfo.modifier;
        this.specialClass = keyInfo.specialClass;
        this.type = keyInfo.type;
        this.radiusRatio = keyInfo.radiusRatio;
        List<KeyPosInfo> list = keyInfo.keyPosList;
        if (list != null && !list.isEmpty()) {
            Iterator<KeyPosInfo> it = keyInfo.keyPosList.iterator();
            while (it.hasNext()) {
                this.keyPosList.add(new KeyPosInfo(it.next()));
            }
        }
        this.operate = keyInfo.operate;
        this.totalTime = keyInfo.totalTime;
        this.args = keyInfo.args;
        this.args2 = keyInfo.args2;
        this.args3 = keyInfo.args3;
        List<PathInfo> list2 = keyInfo.path;
        if (list2 != null && !list2.isEmpty()) {
            Iterator<PathInfo> it2 = keyInfo.path.iterator();
            while (it2.hasNext()) {
                this.path.add(new PathInfo(it2.next()));
            }
        }
        List<CommandInfo> list3 = keyInfo.commands;
        if (list3 == null || list3.isEmpty()) {
            return;
        }
        Iterator<CommandInfo> it3 = keyInfo.commands.iterator();
        while (it3.hasNext()) {
            this.commands.add(new CommandInfo(it3.next()));
        }
    }

    public KeyInfo(Parcel parcel) {
        this.keyCode = parcel.readInt();
        this.keyName = parcel.readString();
        this.displayIcon = parcel.readString();
        this.displayName = parcel.readString();
        this.modifier = parcel.readInt();
        this.specialClass = parcel.readString();
        this.type = parcel.readInt();
        this.radiusRatio = parcel.readFloat();
        this.keyPosList.clear();
        ArrayList arrayList = parcel.readArrayList(KeyPosInfo.class.getClassLoader());
        if (arrayList != null && !arrayList.isEmpty()) {
            this.keyPosList.addAll(arrayList);
        }
        this.operate = parcel.readInt();
        this.totalTime = parcel.readInt();
        this.args = parcel.readInt();
        this.args2 = parcel.readInt();
        this.args3 = parcel.readString();
        ArrayList arrayList2 = parcel.readArrayList(PathInfo.class.getClassLoader());
        this.path.clear();
        if (arrayList2 != null && !arrayList2.isEmpty()) {
            this.path.addAll(arrayList2);
        }
        ArrayList arrayList3 = parcel.readArrayList(CommandInfo.class.getClassLoader());
        this.commands.clear();
        if (arrayList3 == null || arrayList3.isEmpty()) {
            return;
        }
        this.commands.addAll(arrayList3);
    }
}
