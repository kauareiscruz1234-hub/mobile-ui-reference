package com.chaozhuo.gameassistant.czkeymap.bean;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeyMapConfig implements Parcelable {
    public static final Parcelable.Creator<KeyMapConfig> CREATOR = new Parcelable.Creator<KeyMapConfig>() { // from class: com.chaozhuo.gameassistant.czkeymap.bean.KeyMapConfig.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyMapConfig createFromParcel(Parcel parcel) {
            return new KeyMapConfig(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyMapConfig[] newArray(int i) {
            return new KeyMapConfig[i];
        }
    };
    public static final int MASK_CROSSHAIR_COLOR = 3840;
    public static final int MASK_CROSSHAIR_SIZE = 1044480;
    public static final int MASK_CROSSHAIR_TYPE = 240;
    public static final int MASK_CROSSHAIR_VISIBILE = 15;
    public static final int kAccurateAimingVersion = 17;
    public static final int kCurrentVersion = 17;
    public static final int kFireVersion = 12;
    public static final int kModeTypeVersion = 14;
    public static final int kRadialMenuSettingsVersion = 16;
    public static final int kRadialMenuVersion = 15;
    public static final int kRadiusVersion = 10;
    public static final int kRecoilVersion = 11;
    public static final int kSightPosVersion = 13;
    public int accurateAimingKeycode;
    public int crosshairInfo;
    public int currentMode;
    public int cursorClickKeycode;
    public boolean debugMode;
    public boolean handleInvertYLeft;
    public boolean handleInvertYRight;
    public int hideLayoutKeycode;
    public boolean highlightRecordEnabled;
    public int highlightRecordKeycode;
    public final List<ModeConfig> modeList;
    public String pkgName;
    public float scale;
    public int scrollZoomKeycode;
    public int switchModeKeycode;
    public int tint;
    public float transparent;
    public int version;

    public KeyMapConfig() {
        this.transparent = 0.8f;
        this.scale = 1.0f;
        this.tint = 0;
        this.hideLayoutKeycode = 139;
        this.cursorClickKeycode = 0;
        this.scrollZoomKeycode = 113;
        this.modeList = new ArrayList(5);
    }

    private void upgradeAccurateAimingKeycode() {
        if (this.accurateAimingKeycode == 0) {
            ModeConfig curModeConfig = getCurModeConfig();
            KeyInfo keyInfoByType = curModeConfig == null ? null : curModeConfig.getKeyInfoByType(35);
            if (keyInfoByType == null || keyInfoByType.keyCode == 0) {
                Iterator<ModeConfig> it = this.modeList.iterator();
                while (it.hasNext() && ((keyInfoByType = it.next().getKeyInfoByType(35)) == null || keyInfoByType.keyCode == 0)) {
                }
            }
            if (keyInfoByType != null) {
                this.accurateAimingKeycode = keyInfoByType.keyCode;
            }
        }
        for (ModeConfig modeConfig : this.modeList) {
            for (int size = modeConfig.keyList.size() - 1; size >= 0; size--) {
                KeyInfo keyInfo = modeConfig.keyList.get(size);
                if (keyInfo != null && keyInfo.type == 35) {
                    modeConfig.keyList.remove(size);
                }
            }
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public void ensureValid() {
        int i = 0;
        while (i < this.modeList.size()) {
            if (this.modeList.get(i).getEffectiveModeType() != -1) {
                this.modeList.remove(i);
                i--;
            }
            i++;
        }
        int i2 = 0;
        while (true) {
            if (i2 >= this.modeList.size()) {
                this.currentMode = 1;
                break;
            } else if (this.modeList.get(i2).mode == this.currentMode) {
                break;
            } else {
                i2++;
            }
        }
        if (getCurModeConfig() == null) {
            ModeConfig modeConfig = new ModeConfig();
            modeConfig.mode = 1;
            modeConfig.modeType = -1;
            this.modeList.add(modeConfig);
        }
        if (this.version < 17) {
            upgradeAccurateAimingKeycode();
        }
        for (int i3 = 0; i3 < this.modeList.size(); i3++) {
            ModeConfig modeConfig2 = this.modeList.get(i3);
            modeConfig2.ensureValid();
            int i4 = this.version;
            if (i4 < 17) {
                modeConfig2.upgrade(i4, 17);
            }
        }
        if (this.scale < 0.5f) {
            this.scale = 1.0f;
        }
        this.version = 17;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        KeyMapConfig keyMapConfig = (KeyMapConfig) obj;
        if (this.version != keyMapConfig.version || this.currentMode != keyMapConfig.currentMode || Float.compare(this.transparent, keyMapConfig.transparent) != 0 || Float.compare(this.scale, keyMapConfig.scale) != 0 || this.tint != keyMapConfig.tint || this.handleInvertYLeft != keyMapConfig.handleInvertYLeft || this.handleInvertYRight != keyMapConfig.handleInvertYRight || this.switchModeKeycode != keyMapConfig.switchModeKeycode || this.hideLayoutKeycode != keyMapConfig.hideLayoutKeycode || this.cursorClickKeycode != keyMapConfig.cursorClickKeycode || this.scrollZoomKeycode != keyMapConfig.scrollZoomKeycode || this.highlightRecordEnabled != keyMapConfig.highlightRecordEnabled || this.highlightRecordKeycode != keyMapConfig.highlightRecordKeycode || this.accurateAimingKeycode != keyMapConfig.accurateAimingKeycode || this.debugMode != keyMapConfig.debugMode || this.crosshairInfo != keyMapConfig.crosshairInfo || !TextUtils.equals(this.pkgName, keyMapConfig.pkgName) || this.modeList.size() != keyMapConfig.modeList.size()) {
            return false;
        }
        for (int i = 0; i < this.modeList.size(); i++) {
            if (!this.modeList.get(i).equals(keyMapConfig.modeList.get(i))) {
                return false;
            }
        }
        return true;
    }

    public ModeConfig getCurModeConfig() {
        for (ModeConfig modeConfig : this.modeList) {
            if (modeConfig.mode == this.currentMode) {
                return modeConfig;
            }
        }
        return null;
    }

    public int hashCode() {
        String str = this.pkgName;
        return this.modeList.hashCode() + (((((((((((((((((((((((((((int) ((this.scale * 100.0f) + (((int) ((this.transparent * 100.0f) + ((((((str != null ? str.hashCode() : 0) * 31) + this.version) * 31) + this.currentMode) * 31))) * 31))) * 31) + this.tint) * 31) + (this.handleInvertYLeft ? 1 : 0)) * 31) + (this.handleInvertYRight ? 1 : 0)) * 31) + this.switchModeKeycode) * 31) + this.hideLayoutKeycode) * 31) + this.cursorClickKeycode) * 31) + this.scrollZoomKeycode) * 31) + (this.highlightRecordEnabled ? 1 : 0)) * 31) + this.highlightRecordKeycode) * 31) + this.accurateAimingKeycode) * 31) + (this.debugMode ? 1 : 0)) * 31) + this.crosshairInfo) * 31);
    }

    public boolean isEmptyConfig() {
        List<KeyInfo> list;
        List<ModeConfig> list2 = this.modeList;
        if (list2 != null && !list2.isEmpty()) {
            for (ModeConfig modeConfig : this.modeList) {
                if (modeConfig != null && (list = modeConfig.keyList) != null && !list.isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }

    public String toString() {
        return "KeyMapConfig{pkgName='" + this.pkgName + "', version=" + this.version + ", currentMode=" + this.currentMode + ", transparent=" + this.transparent + ", scale=" + this.scale + ", tint=" + this.tint + ",handleInvertYLeft=" + this.handleInvertYLeft + ",handleInvertYRight=" + this.handleInvertYRight + ",switchModeKeycode=" + this.switchModeKeycode + ",hideLayoutKeycode=" + this.hideLayoutKeycode + ",cursorClickKeycode=" + this.cursorClickKeycode + ",scrollZoomKeycode=" + this.scrollZoomKeycode + ",highlightRecordEnabled=" + this.highlightRecordEnabled + ",highlightRecordKeycode=" + this.highlightRecordKeycode + ",accurateAimingKeycode=" + this.accurateAimingKeycode + ",debugMode=" + this.debugMode + ",crosshairInfo=" + this.crosshairInfo + ", modeList=" + this.modeList + '}';
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.pkgName);
        parcel.writeInt(this.version);
        parcel.writeInt(this.currentMode);
        parcel.writeFloat(this.transparent);
        parcel.writeFloat(this.scale);
        parcel.writeInt(this.tint);
        parcel.writeInt(this.handleInvertYLeft ? 1 : 0);
        parcel.writeInt(this.handleInvertYRight ? 1 : 0);
        parcel.writeInt(this.switchModeKeycode);
        parcel.writeInt(this.hideLayoutKeycode);
        parcel.writeInt(this.cursorClickKeycode);
        parcel.writeInt(this.scrollZoomKeycode);
        parcel.writeInt(this.highlightRecordEnabled ? 1 : 0);
        parcel.writeInt(this.highlightRecordKeycode);
        parcel.writeInt(this.accurateAimingKeycode);
        parcel.writeInt(this.debugMode ? 1 : 0);
        parcel.writeInt(this.crosshairInfo);
        parcel.writeList(this.modeList);
    }

    public KeyMapConfig(KeyMapConfig keyMapConfig) {
        this.transparent = 0.8f;
        this.scale = 1.0f;
        this.tint = 0;
        this.hideLayoutKeycode = 139;
        this.cursorClickKeycode = 0;
        this.scrollZoomKeycode = 113;
        this.modeList = new ArrayList(5);
        this.pkgName = keyMapConfig.pkgName;
        this.version = keyMapConfig.version;
        this.currentMode = keyMapConfig.currentMode;
        this.transparent = keyMapConfig.transparent;
        this.scale = keyMapConfig.scale;
        this.tint = keyMapConfig.tint;
        this.handleInvertYLeft = keyMapConfig.handleInvertYLeft;
        this.handleInvertYRight = keyMapConfig.handleInvertYRight;
        this.switchModeKeycode = keyMapConfig.switchModeKeycode;
        this.hideLayoutKeycode = keyMapConfig.hideLayoutKeycode;
        this.cursorClickKeycode = keyMapConfig.cursorClickKeycode;
        this.scrollZoomKeycode = keyMapConfig.scrollZoomKeycode;
        this.highlightRecordEnabled = keyMapConfig.highlightRecordEnabled;
        this.highlightRecordKeycode = keyMapConfig.highlightRecordKeycode;
        this.accurateAimingKeycode = keyMapConfig.accurateAimingKeycode;
        this.debugMode = keyMapConfig.debugMode;
        this.crosshairInfo = keyMapConfig.crosshairInfo;
        Iterator<ModeConfig> it = keyMapConfig.modeList.iterator();
        while (it.hasNext()) {
            this.modeList.add(new ModeConfig(it.next()));
        }
    }

    public KeyMapConfig(Parcel parcel) {
        this.transparent = 0.8f;
        this.scale = 1.0f;
        this.tint = 0;
        this.hideLayoutKeycode = 139;
        this.cursorClickKeycode = 0;
        this.scrollZoomKeycode = 113;
        ArrayList arrayList = new ArrayList(5);
        this.modeList = arrayList;
        this.pkgName = parcel.readString();
        this.version = parcel.readInt();
        this.currentMode = parcel.readInt();
        this.transparent = parcel.readFloat();
        this.scale = parcel.readFloat();
        this.tint = parcel.readInt();
        this.handleInvertYLeft = parcel.readInt() == 1;
        this.handleInvertYRight = parcel.readInt() == 1;
        this.switchModeKeycode = parcel.readInt();
        this.hideLayoutKeycode = parcel.readInt();
        this.cursorClickKeycode = parcel.readInt();
        this.scrollZoomKeycode = parcel.readInt();
        this.highlightRecordEnabled = parcel.readInt() == 1;
        this.highlightRecordKeycode = parcel.readInt();
        this.accurateAimingKeycode = parcel.readInt();
        this.debugMode = parcel.readInt() == 1;
        this.crosshairInfo = parcel.readInt();
        ArrayList arrayList2 = parcel.readArrayList(ModeConfig.class.getClassLoader());
        arrayList.clear();
        if (arrayList2 == null || arrayList2.isEmpty()) {
            return;
        }
        arrayList.addAll(arrayList2);
    }
}
