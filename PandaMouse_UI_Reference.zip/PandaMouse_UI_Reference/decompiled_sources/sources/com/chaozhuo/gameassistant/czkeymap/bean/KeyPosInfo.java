package com.chaozhuo.gameassistant.czkeymap.bean;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeyPosInfo implements Parcelable {
    public static final Parcelable.Creator<KeyPosInfo> CREATOR = new Parcelable.Creator<KeyPosInfo>() { // from class: com.chaozhuo.gameassistant.czkeymap.bean.KeyPosInfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyPosInfo createFromParcel(Parcel parcel) {
            return new KeyPosInfo(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public KeyPosInfo[] newArray(int i) {
            return new KeyPosInfo[i];
        }
    };
    public float x;
    public float y;

    public KeyPosInfo() {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        KeyPosInfo keyPosInfo = (KeyPosInfo) obj;
        return Float.compare(keyPosInfo.x, this.x) == 0 && Float.compare(keyPosInfo.y, this.y) == 0;
    }

    public int hashCode() {
        float f = this.x;
        int iFloatToIntBits = (f != 0.0f ? Float.floatToIntBits(f) : 0) * 31;
        float f2 = this.y;
        return iFloatToIntBits + (f2 != 0.0f ? Float.floatToIntBits(f2) : 0);
    }

    public void set(float f, float f2) {
        this.x = f;
        this.y = f2;
    }

    public String toString() {
        return "KeyPosInfo{x=" + this.x + ", y=" + this.y + '}';
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeFloat(this.x);
        parcel.writeFloat(this.y);
    }

    public KeyPosInfo(float f, float f2) {
        this.x = f;
        this.y = f2;
    }

    public void set(KeyPosInfo keyPosInfo) {
        this.x = keyPosInfo.x;
        this.y = keyPosInfo.y;
    }

    public KeyPosInfo(KeyPosInfo keyPosInfo) {
        this.x = keyPosInfo.x;
        this.y = keyPosInfo.y;
    }

    public KeyPosInfo(Parcel parcel) {
        this.x = parcel.readFloat();
        this.y = parcel.readFloat();
    }
}
