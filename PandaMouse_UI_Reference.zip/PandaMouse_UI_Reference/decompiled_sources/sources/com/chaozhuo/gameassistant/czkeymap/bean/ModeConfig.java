package com.chaozhuo.gameassistant.czkeymap.bean;

import android.graphics.RectF;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import com.chaozhuo.gameassistant.convert.bean.CommandInfo;
import com.chaozhuo.gameassistant.czkeymap.R$dimen;
import iILliI1I1.LI1Il;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import liIli.liIli;
import llL1i.Iii1lill1;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ModeConfig implements Parcelable {
    public static final Parcelable.Creator<ModeConfig> CREATOR = new Parcelable.Creator<ModeConfig>() { // from class: com.chaozhuo.gameassistant.czkeymap.bean.ModeConfig.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModeConfig createFromParcel(Parcel parcel) {
            return new ModeConfig(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ModeConfig[] newArray(int i) {
            return new ModeConfig[i];
        }
    };
    public static final int GAME_MODE_HANDLE = 0;
    public static final int GAME_MODE_KEY = 1;
    public static final int MODE_TYPE_HANDLE = 1;
    public static final int MODE_TYPE_KEY = -1;
    public static final int MODE_TYPE_TOUCH = 0;
    private static final String TAG = "ModeConfig";
    public final List<KeyInfo> keyList;
    public int mode;
    public String modeName;
    public int modeType;
    public float sensitivity;
    public float sensitivitySystem;
    public float sensitivityY;
    public final RectF sightArea;

    public ModeConfig() {
        this.sensitivity = -5.0f;
        this.sensitivityY = -5.0f;
        this.sensitivitySystem = 1.0f;
        this.sightArea = new RectF(0.0f, 0.0f, 0.0f, 0.0f);
        this.keyList = new ArrayList();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public void ensureValid() {
        KeyInfo keyInfoByType = getKeyInfoByType(10);
        if (keyInfoByType != null) {
            int i = keyInfoByType.keyCode;
            if (i == 0 || i == 300) {
                keyInfoByType.keyCode = 312;
            }
            if (getKeyInfoByType(11) == null) {
                KeyInfo keyInfo = new KeyInfo();
                keyInfo.type = 11;
                keyInfo.radiusRatio = keyInfoByType.radiusRatio;
                KeyPosInfo keyPosInfo = new KeyPosInfo();
                keyPosInfo.y = 0.5f;
                keyPosInfo.x = 0.5f;
                keyInfo.keyPosList.add(keyPosInfo);
                this.keyList.add(keyInfo);
            }
        }
        for (KeyInfo keyInfo2 : this.keyList) {
            if (keyInfo2.type == 28) {
                for (CommandInfo commandInfo : keyInfo2.commands) {
                    if (commandInfo.type == 4 && commandInfo.time == 0) {
                        commandInfo.time = 400;
                    }
                }
            }
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ModeConfig modeConfig = (ModeConfig) obj;
        if (this.mode != modeConfig.mode || this.modeType != modeConfig.modeType || Float.compare(this.sensitivity, modeConfig.sensitivity) != 0 || Float.compare(this.sensitivityY, modeConfig.sensitivityY) != 0 || Float.compare(this.sensitivitySystem, modeConfig.sensitivitySystem) != 0 || !TextUtils.equals(this.modeName, modeConfig.modeName) || !this.sightArea.equals(modeConfig.sightArea) || this.keyList.size() != modeConfig.keyList.size()) {
            return false;
        }
        for (int i = 0; i < this.keyList.size(); i++) {
            if (!this.keyList.get(i).equals(modeConfig.keyList.get(i))) {
                return false;
            }
        }
        return true;
    }

    public int getEffectiveModeType() {
        int i = this.mode;
        if (i == 0) {
            return 1;
        }
        if (i == 1) {
            return -1;
        }
        return this.modeType;
    }

    public KeyInfo getKeyInfoByType(int i) {
        for (KeyInfo keyInfo : this.keyList) {
            if (keyInfo != null && keyInfo.type == i) {
                return keyInfo;
            }
        }
        return null;
    }

    public int hashCode() {
        int i = this.mode * 31;
        String str = this.modeName;
        return this.keyList.hashCode() + ((this.sightArea.hashCode() + ((Float.floatToIntBits(this.sensitivitySystem) + ((Float.floatToIntBits(this.sensitivityY) + ((Float.floatToIntBits(this.sensitivity) + ((((i + (str != null ? str.hashCode() : 0)) * 31) + this.modeType) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public String toString() {
        return "ModeConfig{mode=" + this.mode + ", modeName=" + this.modeName + ", modeType=" + this.modeType + ", sensitivity=" + this.sensitivity + ", sensitivityY=" + this.sensitivityY + ", sensitivitySystem=" + this.sensitivitySystem + ", sightArea=" + this.sightArea + ", keyList=" + this.keyList + '}';
    }

    public void upgrade(int i, int i2) {
        if (liIli.f33010ilI11) {
            liIli.Il(TAG, "ModeConfig upgrade from ", Integer.valueOf(i), " to ", Integer.valueOf(i2));
        }
        if (i < 10) {
            DisplayMetrics displayMetricsILLl = Iii1lill1.ILLl(LI1Il.f28411lLliL);
            float dimensionPixelOffset = (LI1Il.f28411lLliL.getResources().getDimensionPixelOffset(R$dimen.base_view_default_height) * 0.5f) / Math.max(displayMetricsILLl.widthPixels, displayMetricsILLl.heightPixels);
            for (KeyInfo keyInfo : this.keyList) {
                switch (keyInfo.type) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        break;
                    default:
                        keyInfo.radiusRatio = dimensionPixelOffset;
                        break;
                }
            }
            i = 10;
        }
        if (i < 11) {
            KeyInfo keyInfoByType = getKeyInfoByType(9);
            if (keyInfoByType != null) {
                keyInfoByType.commands.add(CommandInfo.parseLine("click " + keyInfoByType.args2 + " 0"));
            }
            i = 11;
        }
        if (i < 12) {
            KeyInfo keyInfoByType2 = getKeyInfoByType(9);
            if (keyInfoByType2 != null) {
                keyInfoByType2.keyCode = 311;
            }
            i = 12;
        }
        if (i < 13) {
            i = 13;
        }
        if (i < 14) {
            this.modeType = -1;
            for (KeyInfo keyInfo2 : this.keyList) {
                keyInfo2.keyName = liIli.ILL(keyInfo2.keyCode, keyInfo2.modifier, 0);
            }
            i = 14;
        }
        if (i < 15) {
            for (KeyInfo keyInfo3 : this.keyList) {
                if (keyInfo3.type == 30 && (keyInfo3.operate & 1) != 0) {
                    keyInfo3.type = 50;
                    keyInfo3.operate = 0;
                }
            }
            i = 15;
        }
        if (i < 16) {
            for (KeyInfo keyInfo4 : this.keyList) {
                if (keyInfo4.type == 50) {
                    keyInfo4.totalTime = 0;
                    keyInfo4.args2 = 0;
                }
            }
        }
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.mode);
        parcel.writeString(this.modeName);
        parcel.writeInt(this.modeType);
        parcel.writeFloat(this.sensitivity);
        parcel.writeFloat(this.sensitivityY);
        parcel.writeFloat(this.sensitivitySystem);
        parcel.writeParcelable(this.sightArea, 0);
        parcel.writeList(this.keyList);
    }

    public ModeConfig(ModeConfig modeConfig) {
        this.sensitivity = -5.0f;
        this.sensitivityY = -5.0f;
        this.sensitivitySystem = 1.0f;
        RectF rectF = new RectF(0.0f, 0.0f, 0.0f, 0.0f);
        this.sightArea = rectF;
        this.keyList = new ArrayList();
        this.mode = modeConfig.mode;
        this.modeName = modeConfig.modeName;
        this.modeType = modeConfig.modeType;
        this.sensitivity = modeConfig.sensitivity;
        this.sensitivityY = modeConfig.sensitivityY;
        this.sensitivitySystem = modeConfig.sensitivitySystem;
        rectF.set(modeConfig.sightArea);
        Iterator<KeyInfo> it = modeConfig.keyList.iterator();
        while (it.hasNext()) {
            this.keyList.add(new KeyInfo(it.next()));
        }
    }

    public ModeConfig(Parcel parcel) {
        this.sensitivity = -5.0f;
        this.sensitivityY = -5.0f;
        this.sensitivitySystem = 1.0f;
        RectF rectF = new RectF(0.0f, 0.0f, 0.0f, 0.0f);
        this.sightArea = rectF;
        ArrayList arrayList = new ArrayList();
        this.keyList = arrayList;
        this.mode = parcel.readInt();
        this.modeName = parcel.readString();
        this.modeType = parcel.readInt();
        this.sensitivity = parcel.readFloat();
        this.sensitivityY = parcel.readFloat();
        this.sensitivitySystem = parcel.readFloat();
        RectF rectF2 = (RectF) parcel.readParcelable(RectF.class.getClassLoader());
        rectF.setEmpty();
        if (rectF2 != null) {
            rectF.set(rectF2);
        }
        ArrayList arrayList2 = parcel.readArrayList(KeyInfo.class.getClassLoader());
        arrayList.clear();
        if (arrayList2 == null || arrayList2.isEmpty()) {
            return;
        }
        arrayList.addAll(arrayList2);
    }
}
