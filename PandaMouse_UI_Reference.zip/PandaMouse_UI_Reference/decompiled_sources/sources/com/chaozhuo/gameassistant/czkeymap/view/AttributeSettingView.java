package com.chaozhuo.gameassistant.czkeymap.view;

import L11L.iIiI1;
import L1i.Iii;
import LILllili.L1l;
import LILllili.liIli;
import LL1.iL;
import Ll11Ll.Ilil11ILI;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.chaozhuo.gameassistant.convert.bean.HighlightRecordCommand;
import com.chaozhuo.gameassistant.czkeymap.Ii;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyMapConfig;
import com.chaozhuo.gameassistant.czkeymap.bean.ModeConfig;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.ilI1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import com.chaozhuo.gameassistant.czkeymap.view.AttributeSettingView;
import com.chaozhuo.gameassistant.czkeymap.view.BaseView;
import com.chaozhuo.gameassistant.ipc.handler.HSHandler;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class AttributeSettingView extends LinearLayout {
    public static final /* synthetic */ int iiL = 0;
    public final View I1Ii1IilI;
    public final RadioGroup II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public final RadioButton f7621II1;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public final CustomSeekBarView f7622IIiiI;
    public final ShortKeyView IIlII;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public final ShortKeyView f7623IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final CustomSeekBarView f7624IiiiL;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public final Switch f7625IlLi;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public final ShortKeyView f7626L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public final LinearLayout f7627LIIl;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public final Ilil11ILI f7628LLIi;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public final LinearLayout f7629LLi;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public final CustomSeekBarView f7630LLl1LlLL;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public final RadioButton f7631Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public final View f7632i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public final View f7633iLLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public final ShortKeyView f7634ii111;
    public int iiIL1liI;
    public final Switch iilL1Ll;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final CustomSeekBarView f7635ilI11;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public final Switch f7636ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public final Switch f7637ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public final View f7638lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public final LinearLayout f7639lIllIIiI;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final CustomSeekBarView f7640lLL1L111l;
    public final TextView lLi1I;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public iLLLiIl1 f7641lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public final RadioButton f7642lii1;

    public AttributeSettingView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final void liIli(boolean z) {
        final int i;
        if (z) {
            final KeyMapConfig keyMapConfig = ((li1) this.f7641lLiLIli).f7609liIli;
            ModeConfig curModeConfig = keyMapConfig.getCurModeConfig();
            final int i2 = 0;
            int i3 = (int) (getContext().getSharedPreferences("keymap_prefs", 0).getFloat("KEY_FLOATVIEW_SCALE", 0.8f) * 100.0f);
            CustomSeekBarView customSeekBarView = this.f7635ilI11;
            customSeekBarView.setProgress(i3);
            customSeekBarView.setOnSeekBarChangeListener(Ii.Ilil11ILI().f7512ILLl);
            int i4 = (int) (keyMapConfig.transparent * 100.0f);
            CustomSeekBarView customSeekBarView2 = this.f7630LLl1LlLL;
            customSeekBarView2.setProgress(i4);
            customSeekBarView2.setOnSeekBarChangeListener(((li1) this.f7641lLiLIli).f7598ILl.getAlphaSeekbarListener());
            int iRound = Math.round((keyMapConfig.scale - 0.5f) / 0.015f);
            CustomSeekBarView customSeekBarView3 = this.f7624IiiiL;
            customSeekBarView3.setProgress(iRound);
            customSeekBarView3.setOnSeekBarChangeListener(((li1) this.f7641lLiLIli).f7598ILl.getSizeSeekbarListener());
            CustomSeekBarView customSeekBarView4 = this.f7640lLL1L111l;
            customSeekBarView4.setVisibility(0);
            if (customSeekBarView4.getVisibility() == 0) {
                customSeekBarView4.setProgress(Math.round(((curModeConfig.sensitivitySystem + 10.0f) * 100.0f) / 15.0f));
            }
            this.lLi1I.setText(R$string.tv_sensitivity_tip_keyboard);
            this.f7623IL1LiliI.Iii1lill1(((li1) this.f7641lLiLIli).f7609liIli.hideLayoutKeycode);
            this.f7626L11I.Iii1lill1(((li1) this.f7641lLiLIli).f7609liIli.cursorClickKeycode);
            this.f7634ii111.Iii1lill1(((li1) this.f7641lLiLIli).f7609liIli.scrollZoomKeycode);
            int iLLliL = ilI1.ILLl().lLliL();
            final int i5 = 2;
            final int i6 = 1;
            if (iLLliL == 1) {
                this.f7621II1.setChecked(true);
            } else if (iLLliL != 2) {
                this.f7642lii1.setChecked(true);
            } else {
                this.f7631Li.setChecked(true);
            }
            this.II.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // from class: LILllili.ILl
                @Override // android.widget.RadioGroup.OnCheckedChangeListener
                public final void onCheckedChanged(RadioGroup radioGroup, int i7) {
                    int i8;
                    AttributeSettingView attributeSettingView = this.f2766liIli;
                    int i9 = AttributeSettingView.iiL;
                    attributeSettingView.getClass();
                    int i10 = 0;
                    if (i7 == R$id.id_ps) {
                        i8 = 1;
                    } else {
                        i8 = i7 == R$id.id_nintendo ? 2 : 0;
                    }
                    synchronized (com.chaozhuo.gameassistant.czkeymap.ilI1.ILLl()) {
                        LL1.iIiI1 iiii1 = LL1.iIiI1.f2996iIiI1;
                        iiii1.f2997ILl = i8;
                        iiii1.f2998Iii.removeMessages(4);
                        iiii1.f2998Iii.sendEmptyMessageDelayed(4, 500L);
                    }
                    ArrayList arrayList = ((com.chaozhuo.gameassistant.czkeymap.li1) attributeSettingView.f7641lLiLIli).f7598ILl.f7751L11I.lLi1I;
                    int size = arrayList.size();
                    while (i10 < size) {
                        Object obj = arrayList.get(i10);
                        i10++;
                        BaseView baseView = (BaseView) obj;
                        baseView.LI1Il(baseView.getKeyCode(), baseView.getModifier(), baseView.getName());
                    }
                }
            });
            int i7 = ((li1) this.f7641lLiLIli).f7609liIli.tint;
            int i8 = 0;
            while (true) {
                LinearLayout linearLayout = this.f7627LIIl;
                i = 3;
                if (i8 >= linearLayout.getChildCount()) {
                    break;
                }
                AppCompatImageView appCompatImageView = (AppCompatImageView) linearLayout.getChildAt(i8);
                appCompatImageView.setActivated(i7 == i8);
                appCompatImageView.setOnClickListener(new liIli(this, i));
                i8++;
            }
            int i9 = ((li1) this.f7641lLiLIli).f7609liIli.crosshairInfo;
            boolean z2 = (i9 & 15) != 0;
            int i10 = 8;
            int i11 = (i9 & KeyMapConfig.MASK_CROSSHAIR_COLOR) >> 8;
            final int i12 = 4;
            int i13 = (i9 & KeyMapConfig.MASK_CROSSHAIR_TYPE) >> 4;
            int i14 = (i9 & KeyMapConfig.MASK_CROSSHAIR_SIZE) >> 12;
            int[] iArr = iL.f3004liIli;
            final int i15 = 5;
            int iMin = Math.min(i11, 5);
            int iMin2 = Math.min(i13, 4);
            int iMin3 = Math.min(i14, 100);
            if (iMin3 == 0) {
                iMin3 = 50;
            }
            CustomSeekBarView customSeekBarView5 = this.f7622IIiiI;
            customSeekBarView5.setProgress(iMin3);
            customSeekBarView5.setOnSeekBarChangeListener(new Iii(this, i10));
            Switch r2 = this.f7625IlLi;
            r2.setOnCheckedChangeListener(null);
            r2.setChecked(z2);
            r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this) { // from class: LILllili.Ilil11ILI

                /* JADX INFO: renamed from: Iii1lill1, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2795Iii1lill1;

                {
                    this.f2795Iii1lill1 = this;
                }

                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z3) {
                    int i16 = i2;
                    AttributeSettingView attributeSettingView = this.f2795Iii1lill1;
                    switch (i16) {
                        case 0:
                            KeyMapConfig keyMapConfig2 = ((com.chaozhuo.gameassistant.czkeymap.li1) attributeSettingView.f7641lLiLIli).f7609liIli;
                            keyMapConfig2.crosshairInfo = ((keyMapConfig2.crosshairInfo & (-16)) | (z3 ? 1 : 0)) == true ? 1 : 0;
                            attributeSettingView.I1Ii1IilI.setVisibility(z3 ? 0 : 8);
                            ((com.chaozhuo.gameassistant.czkeymap.li1) attributeSettingView.f7641lLiLIli).iI1();
                            break;
                        default:
                            int i17 = AttributeSettingView.iiL;
                            attributeSettingView.getContext().getSharedPreferences("keymap_prefs", 0).edit().putBoolean("KEY_SENDING_UNMAPPED", z3).commit();
                            break;
                    }
                }
            });
            this.I1Ii1IilI.setVisibility(z2 ? 0 : 8);
            int i16 = 0;
            while (true) {
                LinearLayout linearLayout2 = this.f7629LLi;
                if (i16 >= linearLayout2.getChildCount()) {
                    break;
                }
                AppCompatImageView appCompatImageView2 = (AppCompatImageView) linearLayout2.getChildAt(i16);
                appCompatImageView2.setActivated(iMin2 == i16);
                appCompatImageView2.setOnClickListener(new liIli(this, i6));
                i16++;
            }
            int i17 = 0;
            while (true) {
                LinearLayout linearLayout3 = this.f7639lIllIIiI;
                if (i17 >= linearLayout3.getChildCount()) {
                    break;
                }
                AppCompatImageView appCompatImageView3 = (AppCompatImageView) linearLayout3.getChildAt(i17);
                appCompatImageView3.setActivated(iMin == i17);
                appCompatImageView3.setOnClickListener(new liIli(this, i5));
                i17++;
            }
            final String str = keyMapConfig.pkgName;
            this.iiIL1liI = getContext().getSharedPreferences("keymap_prefs", 0).getInt("KEY_STATUS_INFOBAR", 0);
            final TextView textView = (TextView) findViewById(R$id.id_time);
            final TextView textView2 = (TextView) findViewById(R$id.id_battery);
            final TextView textView3 = (TextView) findViewById(R$id.id_net);
            final TextView textView4 = (TextView) findViewById(R$id.id_fps);
            final TextView textView5 = (TextView) findViewById(R$id.id_keymap_layouts);
            final TextView textView6 = (TextView) findViewById(R$id.id_recoil_speed);
            textView.setSelected((this.iiIL1liI & 1) != 0);
            textView2.setSelected((this.iiIL1liI & 2) != 0);
            textView3.setSelected((this.iiIL1liI & 4) != 0);
            textView4.setSelected((this.iiIL1liI & 32) != 0);
            textView5.setSelected((this.iiIL1liI & 8) != 0);
            textView6.setSelected((this.iiIL1liI & 16) != 0);
            textView.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.Iii1lill1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2773IiiiL;

                {
                    this.f2773IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i18 = i15;
                    String str2 = str;
                    TextView textView7 = textView;
                    AttributeSettingView attributeSettingView = this.f2773IiiiL;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-3)) | (textView7.isSelected() ? 2 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 1:
                            int i20 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-5)) | (textView7.isSelected() ? 4 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 2:
                            int i21 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-33)) | (textView7.isSelected() ? 32 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            p071ilI1LL.ILl.Iii1lill1().il1();
                            break;
                        case 3:
                            int i22 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-9)) | (textView7.isSelected() ? 8 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 4:
                            int i23 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-17)) | (textView7.isSelected() ? 16 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        default:
                            int i24 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = ((attributeSettingView.iiIL1liI & (-2)) | (textView7.isSelected() ? 1 : 0)) == true ? 1 : 0;
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                    }
                }
            });
            textView2.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.Iii1lill1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2773IiiiL;

                {
                    this.f2773IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i18 = i2;
                    String str2 = str;
                    TextView textView7 = textView2;
                    AttributeSettingView attributeSettingView = this.f2773IiiiL;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-3)) | (textView7.isSelected() ? 2 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 1:
                            int i20 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-5)) | (textView7.isSelected() ? 4 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 2:
                            int i21 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-33)) | (textView7.isSelected() ? 32 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            p071ilI1LL.ILl.Iii1lill1().il1();
                            break;
                        case 3:
                            int i22 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-9)) | (textView7.isSelected() ? 8 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 4:
                            int i23 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-17)) | (textView7.isSelected() ? 16 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        default:
                            int i24 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = ((attributeSettingView.iiIL1liI & (-2)) | (textView7.isSelected() ? 1 : 0)) == true ? 1 : 0;
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                    }
                }
            });
            textView3.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.Iii1lill1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2773IiiiL;

                {
                    this.f2773IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i18 = i6;
                    String str2 = str;
                    TextView textView7 = textView3;
                    AttributeSettingView attributeSettingView = this.f2773IiiiL;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-3)) | (textView7.isSelected() ? 2 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 1:
                            int i20 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-5)) | (textView7.isSelected() ? 4 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 2:
                            int i21 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-33)) | (textView7.isSelected() ? 32 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            p071ilI1LL.ILl.Iii1lill1().il1();
                            break;
                        case 3:
                            int i22 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-9)) | (textView7.isSelected() ? 8 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 4:
                            int i23 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-17)) | (textView7.isSelected() ? 16 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        default:
                            int i24 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = ((attributeSettingView.iiIL1liI & (-2)) | (textView7.isSelected() ? 1 : 0)) == true ? 1 : 0;
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                    }
                }
            });
            textView4.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.Iii1lill1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2773IiiiL;

                {
                    this.f2773IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i18 = i5;
                    String str2 = str;
                    TextView textView7 = textView4;
                    AttributeSettingView attributeSettingView = this.f2773IiiiL;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-3)) | (textView7.isSelected() ? 2 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 1:
                            int i20 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-5)) | (textView7.isSelected() ? 4 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 2:
                            int i21 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-33)) | (textView7.isSelected() ? 32 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            p071ilI1LL.ILl.Iii1lill1().il1();
                            break;
                        case 3:
                            int i22 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-9)) | (textView7.isSelected() ? 8 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 4:
                            int i23 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-17)) | (textView7.isSelected() ? 16 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        default:
                            int i24 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = ((attributeSettingView.iiIL1liI & (-2)) | (textView7.isSelected() ? 1 : 0)) == true ? 1 : 0;
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                    }
                }
            });
            textView5.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.Iii1lill1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2773IiiiL;

                {
                    this.f2773IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i18 = i;
                    String str2 = str;
                    TextView textView7 = textView5;
                    AttributeSettingView attributeSettingView = this.f2773IiiiL;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-3)) | (textView7.isSelected() ? 2 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 1:
                            int i20 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-5)) | (textView7.isSelected() ? 4 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 2:
                            int i21 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-33)) | (textView7.isSelected() ? 32 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            p071ilI1LL.ILl.Iii1lill1().il1();
                            break;
                        case 3:
                            int i22 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-9)) | (textView7.isSelected() ? 8 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 4:
                            int i23 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-17)) | (textView7.isSelected() ? 16 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        default:
                            int i24 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = ((attributeSettingView.iiIL1liI & (-2)) | (textView7.isSelected() ? 1 : 0)) == true ? 1 : 0;
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                    }
                }
            });
            textView6.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.Iii1lill1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2773IiiiL;

                {
                    this.f2773IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i18 = i12;
                    String str2 = str;
                    TextView textView7 = textView6;
                    AttributeSettingView attributeSettingView = this.f2773IiiiL;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-3)) | (textView7.isSelected() ? 2 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 1:
                            int i20 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-5)) | (textView7.isSelected() ? 4 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 2:
                            int i21 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-33)) | (textView7.isSelected() ? 32 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            p071ilI1LL.ILl.Iii1lill1().il1();
                            break;
                        case 3:
                            int i22 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-9)) | (textView7.isSelected() ? 8 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        case 4:
                            int i23 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = (attributeSettingView.iiIL1liI & (-17)) | (textView7.isSelected() ? 16 : 0);
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                        default:
                            int i24 = AttributeSettingView.iiL;
                            attributeSettingView.getClass();
                            textView7.setSelected(!textView7.isSelected());
                            attributeSettingView.iiIL1liI = ((attributeSettingView.iiIL1liI & (-2)) | (textView7.isSelected() ? 1 : 0)) == true ? 1 : 0;
                            lLll1L.liIli.i1(attributeSettingView.getContext(), attributeSettingView.iiIL1liI);
                            com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().il1(str2);
                            break;
                    }
                }
            });
            Switch r3 = this.f7636ilL;
            r3.setOnCheckedChangeListener(null);
            r3.setChecked(getContext().getSharedPreferences("keymap_prefs", 0).getBoolean("KEY_SENDING_UNMAPPED", true));
            r3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this) { // from class: LILllili.Ilil11ILI

                /* JADX INFO: renamed from: Iii1lill1, reason: collision with root package name */
                public final /* synthetic */ AttributeSettingView f2795Iii1lill1;

                {
                    this.f2795Iii1lill1 = this;
                }

                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z3) {
                    int i18 = i6;
                    AttributeSettingView attributeSettingView = this.f2795Iii1lill1;
                    switch (i18) {
                        case 0:
                            KeyMapConfig keyMapConfig2 = ((com.chaozhuo.gameassistant.czkeymap.li1) attributeSettingView.f7641lLiLIli).f7609liIli;
                            keyMapConfig2.crosshairInfo = ((keyMapConfig2.crosshairInfo & (-16)) | (z3 ? 1 : 0)) == true ? 1 : 0;
                            attributeSettingView.I1Ii1IilI.setVisibility(z3 ? 0 : 8);
                            ((com.chaozhuo.gameassistant.czkeymap.li1) attributeSettingView.f7641lLiLIli).iI1();
                            break;
                        default:
                            int i19 = AttributeSettingView.iiL;
                            attributeSettingView.getContext().getSharedPreferences("keymap_prefs", 0).edit().putBoolean("KEY_SENDING_UNMAPPED", z3).commit();
                            break;
                    }
                }
            });
            Switch r4 = this.iilL1Ll;
            r4.setOnCheckedChangeListener(null);
            r4.setChecked(keyMapConfig.debugMode);
            r4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: LILllili.Iii
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z3) {
                    int i18 = i2;
                    KeyMapConfig keyMapConfig2 = keyMapConfig;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            keyMapConfig2.debugMode = z3;
                            break;
                        default:
                            int i20 = AttributeSettingView.iiL;
                            keyMapConfig2.highlightRecordEnabled = z3;
                            if (!z3) {
                                com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1.ILl();
                            } else {
                                com.chaozhuo.gameassistant.czkeymap.lIIl liil = com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1;
                                liil.getClass();
                                HighlightRecordCommand highlightRecordCommand = new HighlightRecordCommand();
                                highlightRecordCommand.action = HighlightRecordCommand.ACTION_START;
                                highlightRecordCommand.bufferDurationMs = 30000;
                                liil.lILlii1L(HSHandler.MESSAGE_HIGHLIGHT_RECORD, new com.google.gson.ILl().Iii(highlightRecordCommand));
                            }
                            break;
                    }
                }
            });
            Switch r5 = this.f7637ill;
            r5.setOnCheckedChangeListener(null);
            r5.setChecked(keyMapConfig.highlightRecordEnabled);
            r5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: LILllili.Iii
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z3) {
                    int i18 = i6;
                    KeyMapConfig keyMapConfig2 = keyMapConfig;
                    switch (i18) {
                        case 0:
                            int i19 = AttributeSettingView.iiL;
                            keyMapConfig2.debugMode = z3;
                            break;
                        default:
                            int i20 = AttributeSettingView.iiL;
                            keyMapConfig2.highlightRecordEnabled = z3;
                            if (!z3) {
                                com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1.ILl();
                            } else {
                                com.chaozhuo.gameassistant.czkeymap.lIIl liil = com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1;
                                liil.getClass();
                                HighlightRecordCommand highlightRecordCommand = new HighlightRecordCommand();
                                highlightRecordCommand.action = HighlightRecordCommand.ACTION_START;
                                highlightRecordCommand.bufferDurationMs = 30000;
                                liil.lILlii1L(HSHandler.MESSAGE_HIGHLIGHT_RECORD, new com.google.gson.ILl().Iii(highlightRecordCommand));
                            }
                            break;
                    }
                }
            });
            this.IIlII.Iii1lill1(((li1) this.f7641lLiLIli).f7609liIli.highlightRecordKeycode);
        }
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7641lLiLIli = illliil1;
    }

    public AttributeSettingView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        LayoutInflater.from(context).inflate(R$layout.attribute_layout, this);
        this.f7635ilI11 = (CustomSeekBarView) findViewById(R$id.head_size_seekbar);
        this.f7624IiiiL = (CustomSeekBarView) findViewById(R$id.button_size_seekbar);
        this.f7627LIIl = (LinearLayout) findViewById(R$id.button_color_layout);
        CustomSeekBarView customSeekBarView = (CustomSeekBarView) findViewById(R$id.sensitivity_seekbar);
        this.f7640lLL1L111l = customSeekBarView;
        this.lLi1I = (TextView) findViewById(R$id.id_sensitivity_tip);
        View viewFindViewById = findViewById(R$id.id_bar_back);
        this.f7633iLLL = viewFindViewById;
        viewFindViewById.setOnClickListener(new liIli(this, 0));
        View viewFindViewById2 = findViewById(R$id.id_bar_title);
        this.f7632i1LIiLLl = viewFindViewById2;
        this.f7630LLl1LlLL = (CustomSeekBarView) findViewById(R$id.transparent_seekbar);
        customSeekBarView.setOnSeekBarChangeListener(new L1LLiIII.Ilil11ILI(this, 8));
        ShortKeyView shortKeyView = (ShortKeyView) findViewById(R$id.hide_layouts_key);
        this.f7623IL1LiliI = shortKeyView;
        final int i2 = 0;
        shortKeyView.setOnShortKeyChangeListener(new L1l(this) { // from class: LILllili.lILlii1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ AttributeSettingView f2894IiiiL;

            {
                this.f2894IiiiL = this;
            }

            @Override // LILllili.L1l
            public final void lILlii1L(int i3) {
                switch (i2) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.hideLayoutKeycode = i3;
                        break;
                    case 1:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.scrollZoomKeycode = i3;
                        break;
                    default:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.highlightRecordKeycode = i3;
                        break;
                }
            }
        });
        ShortKeyView shortKeyView2 = (ShortKeyView) findViewById(R$id.scroll_zoom_key);
        this.f7634ii111 = shortKeyView2;
        shortKeyView2.setVisibility(0);
        final int i3 = 1;
        shortKeyView2.setOnShortKeyChangeListener(new L1l(this) { // from class: LILllili.lILlii1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ AttributeSettingView f2894IiiiL;

            {
                this.f2894IiiiL = this;
            }

            @Override // LILllili.L1l
            public final void lILlii1L(int i4) {
                switch (i3) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.hideLayoutKeycode = i4;
                        break;
                    case 1:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.scrollZoomKeycode = i4;
                        break;
                    default:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.highlightRecordKeycode = i4;
                        break;
                }
            }
        });
        this.II = (RadioGroup) findViewById(R$id.id_gamepad_style_group);
        this.f7642lii1 = (RadioButton) findViewById(R$id.id_xbox);
        this.f7621II1 = (RadioButton) findViewById(R$id.id_ps);
        this.f7631Li = (RadioButton) findViewById(R$id.id_nintendo);
        this.f7625IlLi = (Switch) findViewById(R$id.crosshair_switch);
        this.I1Ii1IilI = findViewById(R$id.crosshair_layout);
        this.f7629LLi = (LinearLayout) findViewById(R$id.type_layout);
        this.f7639lIllIIiI = (LinearLayout) findViewById(R$id.color_layout);
        this.f7622IIiiI = (CustomSeekBarView) findViewById(R$id.size_seekbar);
        this.f7638lIL = findViewById(R$id.sending_unmapped_wrapper);
        this.f7636ilL = (Switch) findViewById(R$id.sending_unmapped_switch);
        this.iilL1Ll = (Switch) findViewById(R$id.debug_mode_switch);
        this.f7637ill = (Switch) findViewById(R$id.highlight_record_switch);
        ShortKeyView shortKeyView3 = (ShortKeyView) findViewById(R$id.highlight_record_shortcut);
        this.IIlII = shortKeyView3;
        final int i4 = 2;
        shortKeyView3.setOnShortKeyChangeListener(new L1l(this) { // from class: LILllili.lILlii1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ AttributeSettingView f2894IiiiL;

            {
                this.f2894IiiiL = this;
            }

            @Override // LILllili.L1l
            public final void lILlii1L(int i5) {
                switch (i4) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.hideLayoutKeycode = i5;
                        break;
                    case 1:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.scrollZoomKeycode = i5;
                        break;
                    default:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2894IiiiL.f7641lLiLIli).f7609liIli.highlightRecordKeycode = i5;
                        break;
                }
            }
        });
        this.f7626L11I = (ShortKeyView) findViewById(R$id.joystick_cursor_key);
        Ilil11ILI ilil11ILI = new Ilil11ILI(getContext(), this);
        this.f7628LLIi = ilil11ILI;
        ilil11ILI.f3651iI1 = liIli.liIli.ll(getContext()) ? 1 : 2;
        viewFindViewById2.setOnTouchListener(new iIiI1(this, 1));
    }
}
