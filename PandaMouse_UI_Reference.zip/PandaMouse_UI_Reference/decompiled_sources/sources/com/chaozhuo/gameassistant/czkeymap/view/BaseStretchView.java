package com.chaozhuo.gameassistant.czkeymap.view;

import android.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.chaozhuo.gameassistant.czkeymap.R$dimen;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class BaseStretchView extends BaseView implements View.OnTouchListener {

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public final RelativeLayout f7643IIiiI;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public final View f7644LLi;
    public float iilL1Ll;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public float f7645ilL;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public final RelativeLayout f7646lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public final View f7647lIllIIiI;

    public BaseStretchView(Context context) {
        super(context, null);
        LayoutInflater.from(this.f7659ilI11).inflate(R$layout.base_stretch_view, this);
        this.f7651IlLi = context.getResources().getDimensionPixelSize(R$dimen.base_stretch_view_default_height);
        int i = this.f7651IlLi;
        setLayoutParams(new RelativeLayout.LayoutParams(i, i));
        View viewFindViewById = findViewById(R$id.btn_stretch);
        this.f7644LLi = viewFindViewById;
        viewFindViewById.setOnTouchListener(this);
        this.f7647lIllIIiI = findViewById(R$id.btn_settings);
        this.f7643IIiiI = (RelativeLayout) findViewById(R$id.inner_view_wrapper);
        this.f7646lIL = (RelativeLayout) findViewById(R$id.inner_view);
        this.f7660lLL1L111l = (ImageView) findViewById(R$id.btn_delete);
        this.f7656i1LIiLLl.type = 1;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void Iii1lill1() {
        super.Iii1lill1();
        this.f7643IIiiI.setBackgroundResource(R.color.transparent);
        this.f7644LLi.setVisibility(8);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public View getInnerView() {
        return this.f7646lIL;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void lILlii1L() {
        super.lILlii1L();
        this.f7643IIiiI.setBackgroundResource(R$drawable.circle_background);
        this.f7644LLi.setVisibility(0);
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        if (view.getId() != R$id.btn_stretch) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 0) {
            if (action != 2) {
                return false;
            }
            setScale(Math.max(Math.min((this.iilL1Ll + (motionEvent.getRawX() - this.f7645ilL)) / getWidth(), 2.0f), 0.5f));
            return false;
        }
        this.f7645ilL = motionEvent.getRawX();
        this.iilL1Ll = getScaleX() * getWidth();
        this.f7644LLi.getParent().requestDisallowInterceptTouchEvent(true);
        return false;
    }
}
