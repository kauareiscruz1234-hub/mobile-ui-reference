package com.chaozhuo.gameassistant.czkeymap.view;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.convert.bean.CommandInfo;
import com.chaozhuo.gameassistant.convert.bean.PathInfo;
import com.chaozhuo.gameassistant.czkeymap.R$dimen;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyInfo;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyPosInfo;
import com.chaozhuo.gameassistant.czkeymap.bean.ModeConfig;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.ilI1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import com.chaozhuo.gameassistant.czkeymap.view.BaseView;
import com.chaozhuo.gameassistant.czkeymap.view.CompassView;
import com.chaozhuo.gameassistant.czkeymap.view.KeyMapView;
import com.chaozhuo.gameassistant.czkeymap.view.OrderKeyView;
import com.chaozhuo.gameassistant.czkeymap.view.SettingView;
import com.chaozhuo.gameassistant.czkeymap.view.SightView;
import com.chaozhuo.gameassistant.czkeymap.view.SmartView;
import com.chaozhuo.gameassistant.czkeymap.view.SwipeDrawView;
import com.chaozhuo.gameassistant.czkeymap.view.SwipeKeyView;
import com.chaozhuo.gameassistant.czkeymap.view.ZoomKeyView;
import com.google.android.gms.internal.play_billing.lLii;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import lL1IIi.Iii1lill1;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public abstract class BaseView extends RelativeLayout {
    public static final /* synthetic */ int I1Ii1IilI = 0;
    public float II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public boolean f7648II1;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public float f7649IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public ImageView f7650IiiiL;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public int f7651IlLi;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public float f7652L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public ImageView f7653LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public TextView f7654LLl1LlLL;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public boolean f7655Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public KeyInfo f7656i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public boolean f7657iLLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public float f7658ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final Context f7659ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public ImageView f7660lLL1L111l;
    public final int lLi1I;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public boolean f7661lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public iLLLiIl1 f7662lii1;

    public BaseView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public void ILl() {
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7659ilI11);
        this.f7656i1LIiLLl.keyPosList.clear();
        KeyPosInfo keyPosInfo = new KeyPosInfo();
        this.f7656i1LIiLLl.keyPosList.add(keyPosInfo);
        keyPosInfo.x = (getWidth() / 2.0f) + getX();
        float height = (getHeight() / 2.0f) + getY();
        keyPosInfo.x /= displayMetricsIl1iLli.widthPixels;
        keyPosInfo.y = height / displayMetricsIl1iLli.heightPixels;
    }

    public void Iii1lill1() {
        ImageView imageView = this.f7660lLL1L111l;
        if (imageView != null) {
            imageView.setVisibility(4);
        }
        ImageView imageView2 = this.f7650IiiiL;
        if (imageView2 != null) {
            imageView2.setVisibility(4);
        }
    }

    public void Ilil11ILI() {
        this.f7648II1 = false;
        ImageView imageView = this.f7653LIIl;
        if (imageView != null) {
            imageView.setVisibility(8);
            ((AnimationDrawable) this.f7653LIIl.getBackground()).stop();
        }
        ImageView imageView2 = this.f7650IiiiL;
        if (imageView2 != null) {
            imageView2.setVisibility(4);
        }
    }

    public void LI1Il(int i, int i2, String str) {
        if (liIli.f33010ilI11) {
            liIli.Il("BaseView", "updateKeyCode, keyText: ", str, ", keyCode: ", Integer.valueOf(i), ", modifier: ", Integer.valueOf(i2));
        }
        KeyInfo keyInfo = this.f7656i1LIiLLl;
        keyInfo.keyName = str;
        keyInfo.modifier = i2;
        keyInfo.keyCode = i;
        if (ilI1.ILLl().lLliL() != 0) {
            str = liIli.ILL(i, i2, ilI1.ILLl().lLliL());
        }
        TextView textView = this.f7654LLl1LlLL;
        if (textView != null) {
            textView.setText(str);
        }
        IiI1l();
    }

    public int getArgs() {
        return this.f7656i1LIiLLl.args;
    }

    public int getArgs2() {
        return this.f7656i1LIiLLl.args2;
    }

    public String getArgs3() {
        return this.f7656i1LIiLLl.args3;
    }

    public int getBaseHeight() {
        return this.f7651IlLi;
    }

    public List<CommandInfo> getCommands() {
        return this.f7656i1LIiLLl.commands;
    }

    public iLLLiIl1 getController() {
        return this.f7662lii1;
    }

    public String getDisplayIcon() {
        return this.f7656i1LIiLLl.displayIcon;
    }

    public String getDisplayName() {
        return this.f7656i1LIiLLl.displayName;
    }

    public abstract View getInnerView();

    public int getKeyCode() {
        return this.f7656i1LIiLLl.keyCode;
    }

    public KeyInfo getKeyInfo() {
        return this.f7656i1LIiLLl;
    }

    public int getModifier() {
        return this.f7656i1LIiLLl.modifier;
    }

    public String getName() {
        return this.f7656i1LIiLLl.keyName;
    }

    public int getOperate() {
        return this.f7656i1LIiLLl.operate;
    }

    public List<PathInfo> getPath() {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.f7656i1LIiLLl.path);
        if (!this.f7656i1LIiLLl.path.isEmpty() && !this.f7656i1LIiLLl.keyPosList.isEmpty()) {
            arrayList.remove(0);
            DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7659ilI11);
            KeyPosInfo keyPosInfo = this.f7656i1LIiLLl.keyPosList.get(0);
            arrayList.add(0, new PathInfo(keyPosInfo.x * displayMetricsIl1iLli.widthPixels, keyPosInfo.y * displayMetricsIl1iLli.heightPixels, 0L));
        }
        return arrayList;
    }

    public int getPathAllTime() {
        List<PathInfo> list = this.f7656i1LIiLLl.path;
        int i = 0;
        if (list == null) {
            return 0;
        }
        Iterator<PathInfo> it = list.iterator();
        while (it.hasNext()) {
            i = (int) (((long) i) + it.next().delay);
        }
        return i;
    }

    public float getRadiusRatio() {
        return this.f7656i1LIiLLl.radiusRatio;
    }

    public String getSpecialClass() {
        return this.f7656i1LIiLLl.specialClass;
    }

    public int getTotalTime() {
        return this.f7656i1LIiLLl.totalTime;
    }

    public int getType() {
        return this.f7656i1LIiLLl.type;
    }

    public final void iI1(MotionEvent motionEvent, float f, float f2, float f3, float f4) {
        float scaleX = getScaleX();
        float scaleY = getScaleY();
        float width = getWidth() * scaleX;
        float height = getHeight() * scaleY;
        float width2 = ((1.0f - scaleX) * getWidth()) / 2.0f;
        float height2 = ((1.0f - scaleY) * getHeight()) / 2.0f;
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7659ilI11);
        if (getInnerView() != null) {
            width2 += ((getWidth() - getInnerView().getWidth()) * scaleX) / 2.0f;
            height2 += ((getHeight() - getInnerView().getHeight()) * scaleY) / 2.0f;
            width = getInnerView().getWidth() * scaleX;
            height = getInnerView().getHeight() * scaleY;
        }
        float rawX = (motionEvent.getRawX() + f3) - f;
        float f5 = -width2;
        if (rawX < f5) {
            rawX = f5;
        } else {
            float f6 = rawX + width + width2;
            int i = displayMetricsIl1iLli.widthPixels;
            if (f6 > i) {
                rawX = (i - width) - width2;
            }
        }
        float rawY = (motionEvent.getRawY() + f4) - f2;
        float f7 = -height2;
        if (rawY < f7) {
            rawY = f7;
        } else {
            float f8 = rawY + height + height2;
            int i2 = displayMetricsIl1iLli.heightPixels;
            if (f8 > i2) {
                rawY = (i2 - height) - height2;
            }
        }
        if (liIli.f33010ilI11) {
            liIli.Il("BaseView", "newX: ", Float.valueOf(rawX), ", newY: ", Float.valueOf(rawY));
        }
        iIiI1(rawX, rawY, true);
        ((li1) this.f7662lii1).iIiI1((getWidth() / 2.0f) + getX(), (getHeight() / 2.0f) + getY());
    }

    public final void iIiI1(float f, float f2, boolean z) {
        super.setX(f);
        super.setY(f2);
        Iii();
        if (z) {
            ILl();
        }
    }

    public final void iL() {
        View innerView = getInnerView();
        if (innerView == null) {
            return;
        }
        postDelayed(new lLii(7, this, innerView), 80L);
    }

    public void il1(String str) {
        TextView textView = this.f7654LLl1LlLL;
        if (textView != null) {
            Iii1lill1.lI(textView);
        }
    }

    public void lILlii1L() {
        ImageView imageView;
        ImageView imageView2;
        if (this.f7657iLLL && (imageView2 = this.f7660lLL1L111l) != null) {
            imageView2.setVisibility(0);
        }
        if (this.f7661lLiLIli && (imageView = this.f7650IiiiL) != null && this.f7648II1) {
            imageView.setVisibility(0);
        }
    }

    public void liIli() {
        this.f7648II1 = true;
        ImageView imageView = this.f7653LIIl;
        if (imageView != null) {
            imageView.setVisibility(0);
            ((AnimationDrawable) this.f7653LIIl.getBackground()).start();
        }
        ImageView imageView2 = this.f7650IiiiL;
        if (imageView2 != null) {
            imageView2.setVisibility(this.f7661lLiLIli ? 0 : 4);
        }
        ImageView imageView3 = this.f7660lLL1L111l;
        if (imageView3 != null) {
            imageView3.setVisibility(this.f7657iLLL ? 0 : 4);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        ImageView imageView = this.f7650IiiiL;
        if (imageView != null) {
            final int i = 0;
            imageView.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.iIiI1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ BaseView f2838IiiiL;

                {
                    this.f2838IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ImageView imageView2;
                    ImageView imageView3;
                    int i2 = i;
                    BaseView baseView = this.f2838IiiiL;
                    switch (i2) {
                        case 0:
                            ((com.chaozhuo.gameassistant.czkeymap.li1) baseView.f7662lii1).iL(baseView);
                            break;
                        default:
                            int i3 = BaseView.I1Ii1IilI;
                            if (baseView.getParent() != null) {
                                ((ViewGroup) baseView.getParent()).removeView(baseView);
                                SettingView settingView = ((com.chaozhuo.gameassistant.czkeymap.li1) baseView.f7662lii1).f7598ILl;
                                boolean z = baseView instanceof SightView;
                                if (z) {
                                    ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig().sightArea.setEmpty();
                                    settingView.f7757Li.setVisibility(8);
                                }
                                KeyMapView keyMapView = settingView.f7751L11I;
                                ModeConfig curModeConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) keyMapView.f7731LIIl).f7609liIli.getCurModeConfig();
                                if (baseView instanceof CompassView) {
                                    curModeConfig.keyList.removeAll(((CompassView) baseView).getKeyInfoList());
                                } else if (baseView instanceof ZoomKeyView) {
                                    curModeConfig.keyList.removeAll(((ZoomKeyView) baseView).getKeyInfoList());
                                } else {
                                    if (z) {
                                        BaseView baseViewLILlii1L = keyMapView.lILlii1L(11);
                                        if (baseViewLILlii1L != null && (imageView3 = baseViewLILlii1L.f7660lLL1L111l) != null) {
                                            imageView3.performClick();
                                        }
                                    } else if ((baseView instanceof SmartView) && keyMapView.lILlii1L(12) == null) {
                                        BaseView baseViewLILlii1L2 = keyMapView.lILlii1L(20);
                                        if (baseViewLILlii1L2 != null && (imageView2 = baseViewLILlii1L2.f7660lLL1L111l) != null) {
                                            imageView2.performClick();
                                        }
                                    } else if (baseView instanceof OrderKeyView) {
                                        ArrayList arrayListILl = keyMapView.ILl(((OrderKeyView) baseView).getSpecialClass());
                                        if (arrayListILl.size() > 0) {
                                            Collections.sort(arrayListILl, keyMapView.f7730L11I);
                                            for (int i4 = 0; i4 < arrayListILl.size(); i4++) {
                                                ((OrderKeyView) arrayListILl.get(i4)).setOperate(i4);
                                            }
                                        }
                                    } else if (baseView instanceof SwipeKeyView) {
                                        SwipeDrawView swipeDrawView = (SwipeDrawView) keyMapView.f7728IL1LiliI.remove((SwipeKeyView) baseView);
                                        if (swipeDrawView != null) {
                                            keyMapView.removeView(swipeDrawView);
                                        }
                                    }
                                    curModeConfig.keyList.remove(baseView.getKeyInfo());
                                }
                            }
                            break;
                    }
                }
            });
        }
        ImageView imageView2 = this.f7660lLL1L111l;
        if (imageView2 != null) {
            final int i2 = 1;
            imageView2.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.iIiI1

                /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                public final /* synthetic */ BaseView f2838IiiiL;

                {
                    this.f2838IiiiL = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ImageView imageView3;
                    ImageView imageView4;
                    int i3 = i2;
                    BaseView baseView = this.f2838IiiiL;
                    switch (i3) {
                        case 0:
                            ((com.chaozhuo.gameassistant.czkeymap.li1) baseView.f7662lii1).iL(baseView);
                            break;
                        default:
                            int i4 = BaseView.I1Ii1IilI;
                            if (baseView.getParent() != null) {
                                ((ViewGroup) baseView.getParent()).removeView(baseView);
                                SettingView settingView = ((com.chaozhuo.gameassistant.czkeymap.li1) baseView.f7662lii1).f7598ILl;
                                boolean z = baseView instanceof SightView;
                                if (z) {
                                    ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig().sightArea.setEmpty();
                                    settingView.f7757Li.setVisibility(8);
                                }
                                KeyMapView keyMapView = settingView.f7751L11I;
                                ModeConfig curModeConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) keyMapView.f7731LIIl).f7609liIli.getCurModeConfig();
                                if (baseView instanceof CompassView) {
                                    curModeConfig.keyList.removeAll(((CompassView) baseView).getKeyInfoList());
                                } else if (baseView instanceof ZoomKeyView) {
                                    curModeConfig.keyList.removeAll(((ZoomKeyView) baseView).getKeyInfoList());
                                } else {
                                    if (z) {
                                        BaseView baseViewLILlii1L = keyMapView.lILlii1L(11);
                                        if (baseViewLILlii1L != null && (imageView4 = baseViewLILlii1L.f7660lLL1L111l) != null) {
                                            imageView4.performClick();
                                        }
                                    } else if ((baseView instanceof SmartView) && keyMapView.lILlii1L(12) == null) {
                                        BaseView baseViewLILlii1L2 = keyMapView.lILlii1L(20);
                                        if (baseViewLILlii1L2 != null && (imageView3 = baseViewLILlii1L2.f7660lLL1L111l) != null) {
                                            imageView3.performClick();
                                        }
                                    } else if (baseView instanceof OrderKeyView) {
                                        ArrayList arrayListILl = keyMapView.ILl(((OrderKeyView) baseView).getSpecialClass());
                                        if (arrayListILl.size() > 0) {
                                            Collections.sort(arrayListILl, keyMapView.f7730L11I);
                                            for (int i5 = 0; i5 < arrayListILl.size(); i5++) {
                                                ((OrderKeyView) arrayListILl.get(i5)).setOperate(i5);
                                            }
                                        }
                                    } else if (baseView instanceof SwipeKeyView) {
                                        SwipeDrawView swipeDrawView = (SwipeDrawView) keyMapView.f7728IL1LiliI.remove((SwipeKeyView) baseView);
                                        if (swipeDrawView != null) {
                                            keyMapView.removeView(swipeDrawView);
                                        }
                                    }
                                    curModeConfig.keyList.remove(baseView.getKeyInfo());
                                }
                            }
                            break;
                    }
                }
            });
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (!isEnabled()) {
            return true;
        }
        float rawX = motionEvent.getRawX();
        float rawY = motionEvent.getRawY();
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f7649IL1LiliI = rawX;
            this.f7658ii111 = rawY;
            this.f7652L11I = getX();
            this.II = getY();
            bringToFront();
            return false;
        }
        if (action == 2) {
            float fAbs = Math.abs(rawX - this.f7649IL1LiliI);
            int i = this.lLi1I;
            if (fAbs > i || Math.abs(rawY - this.f7658ii111) > i) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        boolean z;
        super.onSizeChanged(i, i2, i3, i4);
        if (i3 <= 0 || i4 <= 0) {
            return;
        }
        boolean z2 = true;
        if (i != i3) {
            super.setX(getX() - ((i - i3) / 2.0f));
            z = true;
        } else {
            z = false;
        }
        if (i2 != i4) {
            super.setY(getY() - ((i2 - i4) / 2.0f));
        } else {
            z2 = z;
        }
        if (z2) {
            Iii();
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (isEnabled()) {
            int action = motionEvent.getAction();
            if (action == 1) {
                ((li1) this.f7662lii1).iIiI1(-1.0f, -1.0f);
                return true;
            }
            if (action == 2) {
                iI1(motionEvent, this.f7649IL1LiliI, this.f7658ii111, this.f7652L11I, this.II);
                return true;
            }
        }
        return true;
    }

    public void setArgs(int i) {
        this.f7656i1LIiLLl.args = i;
    }

    public void setArgs2(int i) {
        this.f7656i1LIiLLl.args2 = i;
    }

    public void setArgs3(String str) {
        this.f7656i1LIiLLl.args3 = str;
    }

    public void setCommands(List<CommandInfo> list) {
        this.f7656i1LIiLLl.commands.clear();
        if (list == null || list.size() <= 0) {
            return;
        }
        this.f7656i1LIiLLl.commands.addAll(list);
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7662lii1 = illliil1;
    }

    public void setKeyInfo(KeyInfo keyInfo) {
        if (keyInfo == null) {
            return;
        }
        this.f7656i1LIiLLl = keyInfo;
        LI1Il(keyInfo.keyCode, keyInfo.modifier, keyInfo.keyName);
    }

    public void setModifier(int i) {
        this.f7656i1LIiLLl.modifier = i;
    }

    public void setOperate(int i) {
        KeyInfo keyInfo = this.f7656i1LIiLLl;
        if (keyInfo.operate == i) {
            return;
        }
        keyInfo.operate = i;
        IiI1l();
    }

    public void setPath(List<PathInfo> list) {
        this.f7656i1LIiLLl.path.clear();
        if (list != null && list.size() > 0) {
            this.f7656i1LIiLLl.path.addAll(list);
            this.f7656i1LIiLLl.path.remove(0);
            this.f7656i1LIiLLl.path.add(0, new PathInfo(0.0f, 0.0f, 0L));
        }
        IiI1l();
    }

    public void setRadiusRatio(float f) {
        this.f7656i1LIiLLl.radiusRatio = f;
    }

    public void setScale(float f) {
        setScaleX(f);
        setScaleY(f);
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7659ilI11);
        setRadiusRatio(((getScaleY() * getHeight()) * 0.5f) / Math.max(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels));
    }

    public void setSpecialClass(String str) {
        this.f7656i1LIiLLl.specialClass = str;
    }

    public void setTotalTime(int i) {
        this.f7656i1LIiLLl.totalTime = i;
        IiI1l();
    }

    public BaseView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7648II1 = false;
        this.f7655Li = true;
        this.f7661lLiLIli = true;
        this.f7657iLLL = true;
        this.f7659ilI11 = context;
        this.lLi1I = ViewConfiguration.get(context).getScaledTouchSlop();
        setMinimumWidth(context.getResources().getDimensionPixelSize(R$dimen.base_view_min_width));
        setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        KeyInfo keyInfo = new KeyInfo();
        this.f7656i1LIiLLl = keyInfo;
        keyInfo.type = 0;
        keyInfo.keyName = "";
        keyInfo.keyCode = 0;
        keyInfo.radiusRatio = 0.0f;
        KeyPosInfo keyPosInfo = new KeyPosInfo();
        this.f7656i1LIiLLl.keyPosList.add(keyPosInfo);
        keyPosInfo.x = 0.0f;
        keyPosInfo.y = 0.0f;
        KeyInfo keyInfo2 = this.f7656i1LIiLLl;
        keyInfo2.operate = 0;
        keyInfo2.totalTime = 0;
        this.f7651IlLi = context.getResources().getDimensionPixelOffset(R$dimen.base_view_default_height);
    }

    public void IiI1l() {
    }

    public void Iii() {
    }
}
