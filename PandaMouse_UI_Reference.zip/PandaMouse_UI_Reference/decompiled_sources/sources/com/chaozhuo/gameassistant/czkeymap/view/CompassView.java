package com.chaozhuo.gameassistant.czkeymap.view;

import L11L.iL;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$color;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyInfo;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyPosInfo;
import com.chaozhuo.gameassistant.czkeymap.li1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lL1IIi.Iii1lill1;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class CompassView extends BaseStretchView implements View.OnClickListener {
    public static final /* synthetic */ int iiIL1liI = 0;
    public final HashMap IIlII;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public int f7663LLIi;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public final HashMap f7664ill;

    public CompassView(Context context) {
        super(context);
        this.f7664ill = new HashMap(4);
        this.IIlII = new HashMap(4);
        this.f7663LLIi = -1;
        String string = UUID.randomUUID().toString();
        for (int i = 1; i <= 4; i++) {
            KeyInfo keyInfo = new KeyInfo();
            keyInfo.type = i;
            keyInfo.specialClass = string;
            keyInfo.keyPosList.add(new KeyPosInfo());
            this.f7664ill.put(Integer.valueOf(i), keyInfo);
        }
        this.f7656i1LIiLLl.type = 1;
        this.f7646lIL.setBackgroundResource(R$drawable.compass_keyboard_bg);
        LayoutInflater.from(context).inflate(R$layout.compass_view, this.f7646lIL);
        TextView textView = (TextView) findViewById(R$id.left);
        TextView textView2 = (TextView) findViewById(R$id.up);
        TextView textView3 = (TextView) findViewById(R$id.right);
        TextView textView4 = (TextView) findViewById(R$id.down);
        textView.setOnClickListener(this);
        textView2.setOnClickListener(this);
        textView3.setOnClickListener(this);
        textView4.setOnClickListener(this);
        this.IIlII.put(1, textView);
        this.IIlII.put(2, textView2);
        this.IIlII.put(3, textView3);
        this.IIlII.put(4, textView4);
        this.f7647lIllIIiI.setVisibility(0);
        this.f7647lIllIIiI.setOnClickListener(new iL(this, 2));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void ILl() {
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7659ilI11);
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            keyInfo.keyPosList.clear();
            KeyPosInfo keyPosInfo = new KeyPosInfo();
            keyInfo.keyPosList.add(keyPosInfo);
            keyPosInfo.x = (getWidth() / 2.0f) + getX();
            float height = (getHeight() / 2.0f) + getY();
            keyPosInfo.x /= displayMetricsIl1iLli.widthPixels;
            keyPosInfo.y = height / displayMetricsIl1iLli.heightPixels;
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void IiI1l() {
        for (Map.Entry entry : this.f7664ill.entrySet()) {
            Integer num = (Integer) entry.getKey();
            int iIntValue = num.intValue();
            KeyInfo keyInfo = (KeyInfo) entry.getValue();
            TextView textView = (TextView) this.IIlII.get(num);
            boolean zIsEmpty = TextUtils.isEmpty(keyInfo.keyName);
            textView.setText((iIntValue == this.f7663LLIi || !zIsEmpty) ? keyInfo.keyName : "???");
            int i = (iIntValue == this.f7663LLIi || !zIsEmpty) ? R.color.white : R$color.color_error;
            Context context = this.f7659ilI11;
            textView.setTextColor(context.getColor(i));
            ((View) textView.getParent()).setForegroundTintList(ColorStateList.valueOf(context.getColor(iIntValue == this.f7663LLIi ? R$color.color_accent : R$color.color_white)));
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseStretchView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Iii1lill1() {
        super.Iii1lill1();
        this.f7647lIllIIiI.setVisibility(8);
    }

    public final void Il1iLli(KeyInfo keyInfo, String str, int i, int i2) {
        HashMap map = this.f7664ill;
        for (Integer num : map.keySet()) {
            num.getClass();
            if (((KeyInfo) map.get(num)) == keyInfo) {
                ((TextView) this.IIlII.get(num)).setText(str);
                keyInfo.keyName = str;
                keyInfo.keyCode = i;
                keyInfo.modifier = i2;
                break;
            }
        }
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Ilil11ILI() {
        setFocusedId(-1);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void LI1Il(int i, int i2, String str) {
        HashMap map = this.f7664ill;
        for (Integer num : map.keySet()) {
            if (this.f7663LLIi == num.intValue()) {
                ((TextView) this.IIlII.get(num)).setText(str);
                KeyInfo keyInfo = (KeyInfo) map.get(num);
                keyInfo.modifier = i2;
                keyInfo.keyCode = i;
                break;
            }
        }
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public int getArgs() {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                return keyInfo.args;
            }
        }
        return 0;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public int getArgs2() {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                return keyInfo.args2;
            }
        }
        return 0;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public String getArgs3() {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                return keyInfo.args3;
            }
        }
        return "";
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public KeyInfo getKeyInfo() {
        return iilli(this.f7663LLIi);
    }

    public List<KeyInfo> getKeyInfoList() {
        ArrayList arrayList = new ArrayList(4);
        arrayList.addAll(this.f7664ill.values());
        return arrayList;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public int getOperate() {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                return keyInfo.operate;
            }
        }
        return 0;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public float getRadiusRatio() {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                return keyInfo.radiusRatio;
            }
        }
        return 0.0f;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public int getTotalTime() {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                return keyInfo.totalTime;
            }
        }
        return 0;
    }

    public final KeyInfo iilli(int i) {
        return (KeyInfo) this.f7664ill.get(Integer.valueOf(i));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void il1(String str) {
        for (Integer num : this.f7664ill.keySet()) {
            num.getClass();
            TextView textView = (TextView) this.IIlII.get(num);
            if (TextUtils.equals(textView.getText(), str)) {
                Iii1lill1.lI(textView);
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseStretchView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void lILlii1L() {
        super.lILlii1L();
        this.f7647lIllIIiI.setVisibility(0);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void liIli() {
        ((li1) this.f7662lii1).f7598ILl.setFocusView(this);
        IiI1l();
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        bringToFront();
        HashMap map = this.IIlII;
        for (Integer num : map.keySet()) {
            int iIntValue = num.intValue();
            if (map.get(num) == view) {
                setFocusedId(iIntValue);
                break;
            }
        }
        liIli();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setArgs(int i) {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                keyInfo.args = i;
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setArgs2(int i) {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                keyInfo.args2 = i;
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setArgs3(String str) {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                keyInfo.args3 = str;
            }
        }
    }

    public void setFocusedId(int i) {
        this.f7663LLIi = i;
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setKeyInfo(KeyInfo keyInfo) {
        int i = keyInfo.type;
        ((TextView) this.IIlII.get(Integer.valueOf(i))).setText(keyInfo.keyName);
        this.f7664ill.put(Integer.valueOf(i), keyInfo);
        if (TextUtils.isEmpty(getSpecialClass())) {
            setSpecialClass(keyInfo.specialClass);
        }
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setOperate(int i) {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                keyInfo.operate = i;
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setRadiusRatio(float f) {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                keyInfo.radiusRatio = f;
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setTotalTime(int i) {
        for (KeyInfo keyInfo : this.f7664ill.values()) {
            if (keyInfo != null) {
                keyInfo.totalTime = i;
            }
        }
    }
}
