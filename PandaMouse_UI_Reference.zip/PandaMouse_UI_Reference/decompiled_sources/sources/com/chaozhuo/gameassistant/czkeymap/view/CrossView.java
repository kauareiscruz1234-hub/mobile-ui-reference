package com.chaozhuo.gameassistant.czkeymap.view;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class CrossView extends BaseStretchView {
}
