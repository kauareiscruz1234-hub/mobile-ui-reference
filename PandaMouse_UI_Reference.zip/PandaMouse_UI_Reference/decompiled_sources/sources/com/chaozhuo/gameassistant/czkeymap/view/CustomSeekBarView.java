package com.chaozhuo.gameassistant.czkeymap.view;

import I1Ll1iIiI.Iii1lill1;
import LILllili.iL;
import LILllili.il1;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$styleable;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class CustomSeekBarView extends RelativeLayout implements View.OnClickListener {

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public static final /* synthetic */ int f7665Li = 0;
    public iL II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public final Iii1lill1 f7666II1;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public int f7667IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final View f7668IiiiL;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public boolean f7669L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public final String f7670LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public final TextView f7671LLl1LlLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public boolean f7672ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final SeekBar f7673ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final View f7674lLL1L111l;
    public int lLi1I;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public final Handler f7675lii1;

    public CustomSeekBarView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public int getProgress() {
        return (this.f7673ilI11.getProgress() * this.f7667IL1LiliI) + this.lLi1I;
    }

    public final void liIli(int i) {
        String str = this.f7670LIIl;
        if (str != null) {
            Locale locale = Locale.US;
            StringBuilder sb = new StringBuilder();
            sb.append(i);
            this.f7671LLl1LlLL.setText(String.format(str, sb.toString()));
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        if (!this.f7669L11I) {
            this.f7669L11I = true;
            iL iLVar = this.II;
            if (iLVar != null) {
                iLVar.Iii();
            }
        }
        view.setVisibility(0);
        View view2 = this.f7668IiiiL;
        SeekBar seekBar = this.f7673ilI11;
        if (view == view2) {
            this.f7672ii111 = true;
            seekBar.incrementProgressBy(-1);
            this.f7672ii111 = false;
        } else if (view == this.f7674lLL1L111l) {
            this.f7672ii111 = true;
            seekBar.incrementProgressBy(1);
            this.f7672ii111 = false;
        }
        Handler handler = this.f7675lii1;
        Iii1lill1 iii1lill1 = this.f7666II1;
        handler.removeCallbacks(iii1lill1);
        handler.postDelayed(iii1lill1, 500L);
    }

    public void setOnSeekBarChangeListener(iL iLVar) {
        this.II = iLVar;
    }

    public void setProgress(int i) {
        int iRound = Math.round((i - this.lLi1I) / this.f7667IL1LiliI);
        if (iRound <= 0) {
            iRound = 0;
        }
        this.f7673ilI11.setProgress(iRound);
        liIli(getProgress());
    }

    public void setProgressMax(int i) {
        this.f7673ilI11.setMax((i - this.lLi1I) / this.f7667IL1LiliI);
    }

    public void setProgressMin(int i) {
        this.lLi1I = i;
    }

    public void setProgressStep(int i) {
        this.f7667IL1LiliI = Math.max(1, i);
    }

    public void setProgressText(String str) {
        TextView textView = this.f7671LLl1LlLL;
        textView.setVisibility(0);
        textView.setText(str);
    }

    public CustomSeekBarView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7667IL1LiliI = 1;
        this.f7666II1 = new Iii1lill1(this, 6);
        il1 il1Var = new il1(this);
        LayoutInflater.from(context).inflate(R$layout.custom_seekbar_layout, this);
        SeekBar seekBar = (SeekBar) findViewById(R$id.seekbar);
        this.f7673ilI11 = seekBar;
        TextView textView = (TextView) findViewById(R$id.seekbar_title);
        TextView textView2 = (TextView) findViewById(R$id.seekbar_progress);
        this.f7671LLl1LlLL = textView2;
        TextView textView3 = (TextView) findViewById(R$id.left_text);
        TextView textView4 = (TextView) findViewById(R$id.right_text);
        View viewFindViewById = findViewById(R$id.btn_lessen);
        this.f7668IiiiL = viewFindViewById;
        viewFindViewById.setOnClickListener(this);
        View viewFindViewById2 = findViewById(R$id.btn_increase);
        this.f7674lLL1L111l = viewFindViewById2;
        viewFindViewById2.setOnClickListener(this);
        seekBar.setOnSeekBarChangeListener(il1Var);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.CustomSeekBarView);
            textView.setText(typedArrayObtainStyledAttributes.getString(R$styleable.CustomSeekBarView_titleName));
            int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.CustomSeekBarView_titleSize, 0);
            if (dimensionPixelSize > 0) {
                textView.setTextSize(0, dimensionPixelSize);
            }
            String string = typedArrayObtainStyledAttributes.getString(R$styleable.CustomSeekBarView_progressName);
            this.f7670LIIl = string;
            if (!TextUtils.isEmpty(string)) {
                textView2.setVisibility(0);
            }
            String string2 = typedArrayObtainStyledAttributes.getString(R$styleable.CustomSeekBarView_leftName);
            if (TextUtils.isEmpty(string2)) {
                textView3.setVisibility(8);
            } else {
                textView3.setText(string2);
            }
            String string3 = typedArrayObtainStyledAttributes.getString(R$styleable.CustomSeekBarView_rightName);
            if (TextUtils.isEmpty(string3)) {
                textView4.setVisibility(8);
            } else {
                textView4.setText(string3);
            }
            setProgressStep(typedArrayObtainStyledAttributes.getInt(R$styleable.CustomSeekBarView_progressStep, 1));
            setProgressMin(typedArrayObtainStyledAttributes.getInt(R$styleable.CustomSeekBarView_progressMin, 0));
            setProgressMax(typedArrayObtainStyledAttributes.getInt(R$styleable.CustomSeekBarView_progressMax, 100));
            setProgress(typedArrayObtainStyledAttributes.getInt(R$styleable.CustomSeekBarView_progress, this.lLi1I));
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f7675lii1 = new Handler(Looper.getMainLooper());
    }
}
