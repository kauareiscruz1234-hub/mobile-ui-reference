package com.chaozhuo.gameassistant.czkeymap.view;

import L11L.iIiI1;
import LILllili.iI1;
import LILllili.lLliL;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.gridlayout.widget.GridLayout;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ExpandedPanelContentView extends ScrollView {

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final ArrayList f7676IiiiL;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public final ArrayList f7677LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public final ArrayList f7678LLl1LlLL;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public boolean f7679ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final ArrayList f7680lLL1L111l;
    public lLliL lLi1I;

    public ExpandedPanelContentView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f7679ilI11 = true;
        this.f7676IiiiL = new ArrayList();
        this.f7680lLL1L111l = new ArrayList();
        this.f7678LLl1LlLL = new ArrayList();
        this.f7677LIIl = new ArrayList();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [android.view.View, android.view.ViewGroup, android.widget.LinearLayout, com.chaozhuo.gameassistant.czkeymap.view.ExpandedPanelFlowView, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v2, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r0v3, types: [android.view.View, android.view.ViewGroup, android.widget.LinearLayout, com.chaozhuo.gameassistant.czkeymap.view.ExpandedPanelGridView] */
    /* JADX WARN: Type inference failed for: r10v0, types: [android.view.View, android.view.ViewGroup, com.chaozhuo.gameassistant.czkeymap.view.ExpandedPanelContentView] */
    public final void liIli() {
        ?? expandedPanelFlowView;
        removeAllViews();
        if (this.f7679ilI11) {
            Context context = getContext();
            lLliL lllil = this.lLi1I;
            expandedPanelFlowView = new ExpandedPanelGridView(context);
            expandedPanelFlowView.f7683ilI11 = lllil;
            expandedPanelFlowView.setOrientation(1);
            View.inflate(expandedPanelFlowView.getContext(), R$layout.expanded_panel_grid_view, expandedPanelFlowView);
            GridLayout gridLayout = (GridLayout) expandedPanelFlowView.findViewById(R$id.id_basic_grid);
            GridLayout gridLayout2 = (GridLayout) expandedPanelFlowView.findViewById(R$id.id_shooting_grid);
            GridLayout gridLayout3 = (GridLayout) expandedPanelFlowView.findViewById(R$id.id_moba_grid);
            TextView textView = (TextView) expandedPanelFlowView.findViewById(R$id.id_title_shooting);
            TextView textView2 = (TextView) expandedPanelFlowView.findViewById(R$id.id_title_moba);
            expandedPanelFlowView.liIli(this.f7680lLL1L111l, gridLayout, null);
            expandedPanelFlowView.liIli(this.f7678LLl1LlLL, gridLayout2, textView);
            expandedPanelFlowView.liIli(this.f7677LIIl, gridLayout3, textView2);
        } else {
            Context context2 = getContext();
            lLliL lllil2 = this.lLi1I;
            expandedPanelFlowView = new ExpandedPanelFlowView(context2);
            expandedPanelFlowView.f7682ilI11 = this.f7676IiiiL;
            expandedPanelFlowView.f7681IiiiL = lllil2;
            expandedPanelFlowView.setOrientation(1);
            for (int i = 0; i < expandedPanelFlowView.f7682ilI11.size(); i++) {
                iI1 ii2 = (iI1) expandedPanelFlowView.f7682ilI11.get(i);
                View viewInflate = View.inflate(expandedPanelFlowView.getContext(), R$layout.expanded_panel_flow_item, null);
                ImageView imageView = (ImageView) viewInflate.findViewById(R$id.item_image);
                imageView.setImageResource(ii2.f2835lLL1L111l);
                imageView.setTag(ii2);
                imageView.setOnTouchListener(new iIiI1(expandedPanelFlowView, 2));
                ((TextView) viewInflate.findViewById(R$id.text_name)).setText(ii2.f2833LLl1LlLL);
                TextView textView3 = (TextView) viewInflate.findViewById(R$id.text_description);
                int i2 = ii2.f2832LIIl;
                if (i2 != 0) {
                    textView3.setText(i2);
                }
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = liIli.LI1Il(expandedPanelFlowView.getContext(), 8.0f);
                layoutParams.bottomMargin = liIli.LI1Il(expandedPanelFlowView.getContext(), 8.0f);
                expandedPanelFlowView.addView(viewInflate, layoutParams);
            }
        }
        addView(expandedPanelFlowView, -1, -2);
    }

    public void setFuncButtonTouchListener(lLliL lllil) {
        this.lLi1I = lllil;
    }

    public void setViewMode(boolean z) {
        if (this.f7679ilI11 == z) {
            return;
        }
        this.f7679ilI11 = z;
        liIli();
    }

    public void setupDataSet(List<Integer> list) {
        iI1 ii2;
        ArrayList arrayList = this.f7676IiiiL;
        arrayList.clear();
        ArrayList arrayList2 = this.f7680lLL1L111l;
        arrayList2.clear();
        ArrayList arrayList3 = this.f7678LLl1LlLL;
        arrayList3.clear();
        ArrayList arrayList4 = this.f7677LIIl;
        arrayList4.clear();
        for (int i = 0; i < list.size(); i++) {
            int iIntValue = list.get(i).intValue();
            if (iIntValue == 0) {
                ii2 = new iI1(0, iIntValue, R$drawable.key_normal, R$string.tv_key, R$string.key_description, 1);
            } else if (iIntValue == 1) {
                ii2 = new iI1(0, iIntValue, R$drawable.compass_keyboard_normal, R$string.tv_compass, R$string.compass_description, 2);
            } else if (iIntValue == 12) {
                ii2 = new iI1(2, iIntValue, R$drawable.smart_normal, R$string.tv_smart, R$string.smart_description, 7);
            } else if (iIntValue == 28) {
                ii2 = new iI1(0, iIntValue, R$drawable.macro_normal, R$string.tv_macro, R$string.macro_description, 18);
            } else if (iIntValue == 36) {
                ii2 = new iI1(0, iIntValue, R$drawable.zoom_normal, R$string.tv_zoom, R$string.zoom_description, 17);
            } else if (iIntValue == 38) {
                ii2 = new iI1(1, iIntValue, R$drawable.gyro_normal, R$string.tv_gyro, R$string.gyro_description, 19);
            } else if (iIntValue == 40) {
                ii2 = new iI1(1, iIntValue, R$drawable.gcar_normal, R$string.tv_off_car, R$string.offcar_description, 11);
            } else if (iIntValue == 49) {
                ii2 = new iI1(1, iIntValue, R$drawable.drop_normal, R$string.tv_drop, R$string.drop_description, 20);
            } else if (iIntValue != 50) {
                switch (iIntValue) {
                    case 5:
                        ii2 = new iI1(0, iIntValue, R$drawable.cross_normal, R$string.tv_cross, R$string.d_pad_description, 4);
                        break;
                    case 6:
                        ii2 = new iI1(0, iIntValue, R$drawable.joystick_left_normal, R$string.tv_joystick_left, R$string.l_analog_description, 5);
                        break;
                    case 7:
                        ii2 = new iI1(0, iIntValue, R$drawable.joystick_normal, R$string.tv_joystick, R$string.r_analog_description, 6);
                        break;
                    case 8:
                        ii2 = new iI1(2, iIntValue, R$drawable.mouse_compass, R$string.tv_mouse_compass, R$string.mouse_description, 3);
                        break;
                    case 9:
                        ii2 = new iI1(1, iIntValue, R$drawable.fire_normal, R$string.tv_fire, R$string.fire_description, 8);
                        break;
                    case 10:
                        ii2 = new iI1(1, iIntValue, R$drawable.sight_normal, R$string.tv_sight, R$string.sight_description, 9);
                        break;
                    default:
                        switch (iIntValue) {
                            case 30:
                                ii2 = new iI1(1, iIntValue, R$drawable.visual_angle, R$string.tv_visual_angle, R$string.visual_angle_description, 12);
                                break;
                            case 31:
                                ii2 = new iI1(1, iIntValue, R$drawable.backpack_normal, R$string.tv_smart_backpack, R$string.map_bag_description, 10);
                                break;
                            case 32:
                                ii2 = new iI1(0, iIntValue, R$drawable.multiply_normal, R$string.tv_multiply, R$string.multiply_description, 14);
                                break;
                            case 33:
                                ii2 = new iI1(0, iIntValue, R$drawable.swipe_normal, R$string.tv_swipe, R$string.swipe_description, 15);
                                break;
                            case 34:
                                ii2 = new iI1(0, iIntValue, R$drawable.order_normal, R$string.tv_order, R$string.order_description, 16);
                                break;
                            default:
                                ii2 = null;
                                break;
                        }
                        break;
                }
            } else {
                ii2 = new iI1(1, iIntValue, R$drawable.radial_menu, R$string.tv_radial_menu, R$string.radial_menu_description, 13);
            }
            if (ii2 != null) {
                arrayList.add(ii2);
                int i2 = ii2.f2834ilI11;
                if (i2 == 0) {
                    arrayList2.add(ii2);
                } else if (i2 == 1) {
                    arrayList3.add(ii2);
                } else if (i2 == 2) {
                    arrayList4.add(ii2);
                }
            }
        }
        Collections.sort(arrayList);
        Collections.sort(arrayList2);
        Collections.sort(arrayList3);
        Collections.sort(arrayList4);
        liIli();
    }

    public ExpandedPanelContentView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7679ilI11 = true;
        this.f7676IiiiL = new ArrayList();
        this.f7680lLL1L111l = new ArrayList();
        this.f7678LLl1LlLL = new ArrayList();
        this.f7677LIIl = new ArrayList();
    }
}
