package com.chaozhuo.gameassistant.czkeymap.view;

import LILllili.lLliL;
import android.widget.LinearLayout;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ExpandedPanelFlowView extends LinearLayout {

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public lLliL f7681IiiiL;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public ArrayList f7682ilI11;
}
