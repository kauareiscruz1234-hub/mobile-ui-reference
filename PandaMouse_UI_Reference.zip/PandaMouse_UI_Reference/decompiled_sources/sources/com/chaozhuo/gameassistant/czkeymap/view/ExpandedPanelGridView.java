package com.chaozhuo.gameassistant.czkeymap.view;

import LILllili.iI1;
import LILllili.lLliL;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.gridlayout.widget.GridLayout;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import java.util.ArrayList;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ExpandedPanelGridView extends LinearLayout {

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public lLliL f7683ilI11;

    public final void liIli(ArrayList arrayList, final GridLayout gridLayout, TextView textView) {
        View view;
        if (arrayList == null || arrayList.isEmpty()) {
            if (textView != null) {
                textView.setVisibility(8);
            }
            if (gridLayout != null) {
                gridLayout.setVisibility(8);
                return;
            }
            return;
        }
        if (textView != null) {
            textView.setVisibility(0);
        }
        if (gridLayout != null) {
            gridLayout.setVisibility(0);
        }
        int size = arrayList.size() / gridLayout.getColumnCount();
        if (arrayList.size() % gridLayout.getColumnCount() != 0) {
            size++;
        }
        gridLayout.setRowCount(size);
        int rowCount = gridLayout.getRowCount() * gridLayout.getColumnCount();
        for (int i = 0; i < rowCount; i++) {
            if (i < arrayList.size()) {
                iI1 ii2 = (iI1) arrayList.get(i);
                view = View.inflate(getContext(), R$layout.expanded_panel_grid_item, null);
                ImageView imageView = (ImageView) view.findViewById(R$id.item_image);
                imageView.setImageResource(ii2.f2835lLL1L111l);
                imageView.setTag(ii2);
                imageView.setOnTouchListener(new View.OnTouchListener() { // from class: LILllili.LI1Il
                    @Override // android.view.View.OnTouchListener
                    public final boolean onTouch(View view2, MotionEvent motionEvent) {
                        lLliL lllil = this.f2806ilI11.f7683ilI11;
                        if (lllil == null) {
                            return false;
                        }
                        ((IiI1l) lllil).liIli(gridLayout, ((iI1) view2.getTag()).f2831IiiiL, motionEvent);
                        return true;
                    }
                });
                ((TextView) view.findViewById(R$id.item_text)).setText(ii2.f2833LLl1LlLL);
            } else {
                view = new View(getContext());
            }
            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
            ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = liIli.LI1Il(getContext(), 8.0f);
            ((ViewGroup.MarginLayoutParams) layoutParams).width = 0;
            ((ViewGroup.MarginLayoutParams) layoutParams).height = -2;
            layoutParams.f6451Iii1lill1 = GridLayout.LI1Il(Integer.MIN_VALUE, 1, GridLayout.I1Ii1IilI, 1.0f);
            view.setLayoutParams(layoutParams);
            gridLayout.addView(view);
        }
    }
}
