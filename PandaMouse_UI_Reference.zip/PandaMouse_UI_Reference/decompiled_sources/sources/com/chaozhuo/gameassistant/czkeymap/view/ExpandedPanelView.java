package com.chaozhuo.gameassistant.czkeymap.view;

import L11L.iIiI1;
import LILllili.IiI1l;
import LILllili.Il1iLli;
import Ll11Ll.Ilil11ILI;
import android.content.Context;
import android.content.DialogInterface;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.Iii;
import com.chaozhuo.gameassistant.czkeymap.Ii;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.chaozhuo.gameassistant.czkeymap.R$style;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyMapConfig;
import com.chaozhuo.gameassistant.czkeymap.bean.ModeConfig;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import com.chaozhuo.gameassistant.czkeymap.view.ExpandedPanelView;
import java.util.List;
import liIli.liIli;
import p048iL.L1i11iI;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ExpandedPanelView extends LinearLayout {

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public static final /* synthetic */ int f7684i1LIiLLl = 0;
    public Ilil11ILI II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public float f7685II1;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public View f7686IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public TextView f7687IiiiL;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public int f7688L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public iLLLiIl1 f7689LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public ImageView f7690LLl1LlLL;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public float f7691Li;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public boolean f7692iLLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public View f7693ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public View f7694ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public ImageView f7695lLL1L111l;
    public ExpandedPanelContentView lLi1I;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public BaseView f7696lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public Iii f7697lii1;

    public ExpandedPanelView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f7685II1 = 0.0f;
        this.f7691Li = 0.0f;
        this.f7696lLiLIli = null;
        this.f7692iLLL = false;
    }

    public final void liIli(final boolean z) {
        IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(getContext(), R$style.AppTheme_AlertDialog);
        ilil11ILI.ILLl(z ? R$string.reset_prompt : R$string.delete_all_prompt);
        ilil11ILI.iilli(R$string.dialog_ok, new DialogInterface.OnClickListener() { // from class: LILllili.iilli
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                int i2 = ExpandedPanelView.f7684i1LIiLLl;
                ExpandedPanelView expandedPanelView = this.f2855ilI11;
                expandedPanelView.bringToFront();
                if (!z) {
                    KeyMapConfig keyMapConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).f7609liIli;
                    ModeConfig curModeConfig = keyMapConfig.getCurModeConfig();
                    if (curModeConfig == null) {
                        return;
                    }
                    curModeConfig.keyList.clear();
                    curModeConfig.ensureValid();
                    com.chaozhuo.gameassistant.czkeymap.ilI1.ILLl().lIL(keyMapConfig);
                    ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).lILlii1L(curModeConfig.mode);
                    return;
                }
                String str = ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).f7609liIli.pkgName;
                androidx.appcompat.app.Iii iii2 = expandedPanelView.f7697lii1;
                if (iii2 != null) {
                    iii2.dismiss();
                    expandedPanelView.f7697lii1 = null;
                }
                IL1.Ilil11ILI ilil11ILI2 = new IL1.Ilil11ILI(expandedPanelView.getContext(), R$style.AppTheme_AlertDialog);
                int i3 = R$layout.default_layout_loading_dialog;
                androidx.appcompat.app.Ilil11ILI ilil11ILI3 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI2.f675lLL1L111l;
                ilil11ILI3.f3973L1i11iI = null;
                ilil11ILI3.f3979ii1 = i3;
                ilil11ILI3.f3966ILLl = false;
                androidx.appcompat.app.Iii iiiII1 = ilil11ILI2.iI1();
                expandedPanelView.f7697lii1 = iiiII1;
                liIli.liIli.Ii(iiiII1);
                com.chaozhuo.gameassistant.czkeymap.Ii.Ilil11ILI().iIiI1();
                LL1.iIiI1.f2996iIiI1.iIiI1(str, new IiI1l(expandedPanelView), 0);
            }
        });
        ilil11ILI.IiI1l(R$string.dialog_cancel, new Il1iLli(0));
        liIli.Ii(ilil11ILI.iI1());
        Ii.Ilil11ILI().iIiI1();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        Iii iii2 = this.f7697lii1;
        if (iii2 != null) {
            iii2.dismiss();
            this.f7697lii1 = null;
        }
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f7688L11I = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        LayoutInflater.from(getContext()).inflate(R$layout.expanded_panel_layout, this);
        View viewFindViewById = findViewById(R$id.id_bar_back);
        this.f7694ilI11 = viewFindViewById;
        final int i = 0;
        viewFindViewById.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.ILLl

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ExpandedPanelView f2764IiiiL;

            {
                this.f2764IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                ExpandedPanelView expandedPanelView = this.f2764IiiiL;
                switch (i2) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).il1(32768);
                        break;
                    case 1:
                        expandedPanelView.lLi1I.setViewMode(true);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 2:
                        expandedPanelView.lLi1I.setViewMode(false);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 3:
                        int i3 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(true);
                        break;
                    default:
                        int i4 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(false);
                        break;
                }
            }
        });
        this.f7687IiiiL = (TextView) findViewById(R$id.id_bar_title);
        ImageView imageView = (ImageView) findViewById(R$id.view_mode_grid);
        this.f7695lLL1L111l = imageView;
        final int i2 = 1;
        imageView.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.ILLl

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ExpandedPanelView f2764IiiiL;

            {
                this.f2764IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                ExpandedPanelView expandedPanelView = this.f2764IiiiL;
                switch (i3) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).il1(32768);
                        break;
                    case 1:
                        expandedPanelView.lLi1I.setViewMode(true);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 2:
                        expandedPanelView.lLi1I.setViewMode(false);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 3:
                        int i4 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(true);
                        break;
                    default:
                        int i5 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(false);
                        break;
                }
            }
        });
        ImageView imageView2 = (ImageView) findViewById(R$id.view_mode_flow);
        this.f7690LLl1LlLL = imageView2;
        final int i3 = 2;
        imageView2.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.ILLl

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ExpandedPanelView f2764IiiiL;

            {
                this.f2764IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                ExpandedPanelView expandedPanelView = this.f2764IiiiL;
                switch (i4) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).il1(32768);
                        break;
                    case 1:
                        expandedPanelView.lLi1I.setViewMode(true);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 2:
                        expandedPanelView.lLi1I.setViewMode(false);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 3:
                        int i5 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(true);
                        break;
                    default:
                        int i6 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(false);
                        break;
                }
            }
        });
        ExpandedPanelContentView expandedPanelContentView = (ExpandedPanelContentView) findViewById(R$id.expanded_panel_content_view);
        this.lLi1I = expandedPanelContentView;
        expandedPanelContentView.setFuncButtonTouchListener(new IiI1l(this));
        this.lLi1I.setupDataSet((List) li1.f7596IiI1l.get(L1i11iI.f28803Ilil11ILI));
        setViewMode(this.lLi1I.f7679ilI11);
        Ilil11ILI ilil11ILI = new Ilil11ILI(getContext(), this);
        this.II = ilil11ILI;
        ilil11ILI.f3651iI1 = liIli.ll(getContext()) ? 1 : 2;
        final int i4 = 3;
        this.f7687IiiiL.setOnTouchListener(new iIiI1(this, 3));
        View viewFindViewById2 = findViewById(R$id.id_reset);
        this.f7686IL1LiliI = viewFindViewById2;
        viewFindViewById2.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.ILLl

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ExpandedPanelView f2764IiiiL;

            {
                this.f2764IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                ExpandedPanelView expandedPanelView = this.f2764IiiiL;
                switch (i5) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).il1(32768);
                        break;
                    case 1:
                        expandedPanelView.lLi1I.setViewMode(true);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 2:
                        expandedPanelView.lLi1I.setViewMode(false);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 3:
                        int i6 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(true);
                        break;
                    default:
                        int i7 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(false);
                        break;
                }
            }
        });
        View viewFindViewById3 = findViewById(R$id.id_delete_all);
        this.f7693ii111 = viewFindViewById3;
        final int i5 = 4;
        viewFindViewById3.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.ILLl

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ExpandedPanelView f2764IiiiL;

            {
                this.f2764IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i6 = i5;
                ExpandedPanelView expandedPanelView = this.f2764IiiiL;
                switch (i6) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).il1(32768);
                        break;
                    case 1:
                        expandedPanelView.lLi1I.setViewMode(true);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 2:
                        expandedPanelView.lLi1I.setViewMode(false);
                        expandedPanelView.setViewMode(expandedPanelView.lLi1I.f7679ilI11);
                        break;
                    case 3:
                        int i7 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(true);
                        break;
                    default:
                        int i8 = ExpandedPanelView.f7684i1LIiLLl;
                        expandedPanelView.liIli(false);
                        break;
                }
            }
        });
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7689LIIl = illliil1;
    }

    public void setViewMode(boolean z) {
        this.f7695lLL1L111l.setVisibility(z ? 8 : 0);
        this.f7690LLl1LlLL.setVisibility(z ? 0 : 8);
    }

    public ExpandedPanelView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7685II1 = 0.0f;
        this.f7691Li = 0.0f;
        this.f7696lLiLIli = null;
        this.f7692iLLL = false;
    }
}
