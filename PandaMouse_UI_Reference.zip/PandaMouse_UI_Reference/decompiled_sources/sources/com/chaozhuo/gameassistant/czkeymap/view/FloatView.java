package com.chaozhuo.gameassistant.czkeymap.view;

import LILllili.L1i11iI;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.chaozhuo.gameassistant.czkeymap.Ii;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class FloatView extends RelativeLayout {
    public final L1i11iI I1Ii1IilI;
    public final Handler II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public final int f7698II1;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public int f7699IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final WindowManager f7700IiiiL;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public int f7701IlLi;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public final int f7702L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public final boolean f7703LIIl;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public final L1i11iI f7704LLi;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public final ImageView f7705LLl1LlLL;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public boolean f7706Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public int f7707i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public boolean f7708iLLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public int f7709ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final Context f7710ilI11;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public final L1i11iI f7711lIllIIiI;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final WindowManager.LayoutParams f7712lLL1L111l;
    public final DisplayMetrics lLi1I;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public boolean f7713lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public final int f7714lii1;

    public FloatView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final void liIli(boolean z) {
        boolean z2 = this.f7703LIIl;
        ImageView imageView = this.f7705LLl1LlLL;
        if (z) {
            imageView.setImageResource(z2 ? R$drawable.panda_head_portrait : R$drawable.panda_head);
        } else {
            imageView.setImageResource(z2 ? R$drawable.panda_head_portrait_disabled : R$drawable.panda_head_disabled);
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int rawX = (int) motionEvent.getRawX();
        int rawY = (int) motionEvent.getRawY();
        int actionMasked = motionEvent.getActionMasked();
        WindowManager.LayoutParams layoutParams = this.f7712lLL1L111l;
        L1i11iI l1i11iI = this.f7704LLi;
        L1i11iI l1i11iI2 = this.I1Ii1IilI;
        Handler handler = this.II;
        if (actionMasked == 0) {
            if (this.f7708iLLL) {
                handler.removeCallbacks(l1i11iI);
            }
            this.f7706Li = true;
            this.f7713lLiLIli = false;
            this.f7699IL1LiliI = rawX;
            this.f7709ii111 = rawY;
            this.f7707i1LIiLLl = layoutParams.x;
            this.f7701IlLi = layoutParams.y;
            handler.removeCallbacks(l1i11iI2);
            handler.postDelayed(l1i11iI2, this.f7714lii1);
            return true;
        }
        if (actionMasked == 1) {
            if (this.f7706Li && !this.f7713lLiLIli) {
                if (this.f7708iLLL) {
                    this.f7708iLLL = false;
                    handler.removeCallbacks(l1i11iI);
                    if (!Ii.Ilil11ILI().lILlii1L()) {
                        Ii.Ilil11ILI().Iii1lill1();
                    }
                } else {
                    this.f7708iLLL = true;
                    handler.postDelayed(l1i11iI, this.f7698II1);
                }
            }
            this.f7706Li = false;
            handler.removeCallbacks(l1i11iI2);
            return true;
        }
        if (actionMasked == 2) {
            int i = rawX - this.f7699IL1LiliI;
            int i2 = rawY - this.f7709ii111;
            if (this.f7706Li) {
                if ((i2 * i2) + (i * i) > this.f7702L11I) {
                    this.f7706Li = false;
                    this.f7708iLLL = false;
                    handler.removeCallbacks(l1i11iI);
                    handler.removeCallbacks(l1i11iI2);
                }
            }
            if (!this.f7706Li) {
                boolean z = this.f7703LIIl;
                WindowManager windowManager = this.f7700IiiiL;
                DisplayMetrics displayMetrics = this.lLi1I;
                try {
                    if (z) {
                        layoutParams.y = Math.min(Math.max(this.f7701IlLi + i2, 0), (int) (displayMetrics.heightPixels * 0.8f));
                        windowManager.updateViewLayout(this, layoutParams);
                    } else {
                        layoutParams.x = Math.min(Math.max(this.f7707i1LIiLLl + i, 0), (int) (displayMetrics.widthPixels * 0.8f));
                        windowManager.updateViewLayout(this, layoutParams);
                    }
                } catch (Exception unused) {
                }
                L1i11iI l1i11iI3 = this.f7711lIllIIiI;
                handler.removeCallbacks(l1i11iI3);
                handler.postDelayed(l1i11iI3, 500L);
            }
        } else if (actionMasked == 3) {
            this.f7706Li = false;
            this.f7708iLLL = false;
            handler.removeCallbacks(l1i11iI);
            handler.removeCallbacks(l1i11iI2);
            return true;
        }
        return true;
    }

    public FloatView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.I1Ii1IilI = new L1i11iI(this, 0);
        this.f7704LLi = new L1i11iI(this, 1);
        this.f7711lIllIIiI = new L1i11iI(this, 2);
        this.f7710ilI11 = context;
        boolean zLl = liIli.ll(context);
        this.f7703LIIl = zLl;
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(context);
        this.lLi1I = displayMetricsIl1iLli;
        ImageView imageView = new ImageView(context);
        this.f7705LLl1LlLL = imageView;
        imageView.setImageResource(zLl ? R$drawable.panda_head_portrait : R$drawable.panda_head);
        addView(imageView, new RelativeLayout.LayoutParams(-2, -2));
        this.f7700IiiiL = (WindowManager) context.getSystemService("window");
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f7712lLL1L111l = layoutParams;
        layoutParams.type = liIli.lI();
        layoutParams.format = -3;
        layoutParams.flags = 16778024;
        if (Build.VERSION.SDK_INT >= 28) {
            layoutParams.layoutInDisplayCutoutMode = 1;
        }
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.gravity = 51;
        float f = context.getSharedPreferences("keymap_prefs", 0).getFloat("KEY_FLOATVIEW_SCALE", 0.8f);
        setScaleX(f);
        setScaleY(f);
        measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
        float f2 = context.getSharedPreferences("keymap_prefs", 0).getFloat(zLl ? "KEY_FLOATVIEW_PORTRAIT_POS" : "KEY_FLOATVIEW_LANDSCAPE_POS", zLl ? 0.25f : 0.4f);
        if (zLl) {
            layoutParams.x = (-getMeasuredWidth()) / 2;
            layoutParams.y = (int) ((displayMetricsIl1iLli.heightPixels * f2) - (getMeasuredHeight() / 2));
        } else {
            layoutParams.x = (int) ((displayMetricsIl1iLli.widthPixels * f2) - (getMeasuredWidth() / 2));
            layoutParams.y = (-getMeasuredHeight()) / 2;
        }
        setLayoutParams(layoutParams);
        int scaledTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.f7702L11I = scaledTouchSlop * scaledTouchSlop;
        this.II = new Handler(Looper.getMainLooper());
        this.f7714lii1 = ViewConfiguration.getLongPressTimeout() * 2;
        this.f7698II1 = ViewConfiguration.getDoubleTapTimeout();
    }
}
