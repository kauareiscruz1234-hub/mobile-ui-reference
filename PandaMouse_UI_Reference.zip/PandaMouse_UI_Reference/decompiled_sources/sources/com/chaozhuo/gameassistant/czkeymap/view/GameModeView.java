package com.chaozhuo.gameassistant.czkeymap.view;

import I1I1li.iilli;
import L11L.iIiI1;
import LILllili.I1lI111LL;
import LILllili.Il1iLli;
import LILllili.Ll1LIL1l;
import LILllili.ilI1;
import Ll11Ll.Ilil11ILI;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.ILl;
import androidx.appcompat.app.Iii;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chaozhuo.gameassistant.czkeymap.Ii;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.chaozhuo.gameassistant.czkeymap.R$style;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyMapConfig;
import com.chaozhuo.gameassistant.czkeymap.bean.ModeConfig;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import com.chaozhuo.gameassistant.czkeymap.view.GameModeView;
import java.util.Iterator;
import liIli.liIli;
import p067il1.ILLl;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class GameModeView extends LinearLayout {

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public static final /* synthetic */ int f7715L11I = 0;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public View f7716IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public RecyclerView f7717IiiiL;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public ShortKeyView f7718LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public Iii f7719LLl1LlLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public Ilil11ILI f7720ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public iLLLiIl1 f7721ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public ilI1 f7722lLL1L111l;
    public View lLi1I;

    public GameModeView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private int getCopyModeId() {
        Iterator<ModeConfig> it = ((li1) this.f7721ilI11).f7609liIli.modeList.iterator();
        int i = 0;
        while (it.hasNext()) {
            int i2 = it.next().mode;
            if (i2 > i) {
                i = i2;
            }
        }
        int i3 = i + 1;
        if (i3 < 100) {
            return 100;
        }
        return i3;
    }

    public static void liIli(GameModeView gameModeView) {
        KeyMapConfig keyMapConfig = ((li1) gameModeView.f7721ilI11).f7609liIli;
        ModeConfig curModeConfig = keyMapConfig.getCurModeConfig();
        int copyModeId = gameModeView.getCopyModeId();
        ModeConfig modeConfig = new ModeConfig(curModeConfig);
        modeConfig.mode = copyModeId;
        modeConfig.modeType = -1;
        modeConfig.modeName = iilli.Il1iLli(liIli.l1LLlI(gameModeView.getContext(), curModeConfig), " copy");
        keyMapConfig.modeList.add(modeConfig);
        ((li1) gameModeView.f7721ilI11).lILlii1L(modeConfig.mode);
        gameModeView.f7722lLL1L111l.notifyDataSetChanged();
        gameModeView.f7717IiiiL.lll11L(gameModeView.f7722lLL1L111l.getData().size() - 1);
        Ii.Ilil11ILI().ILl(gameModeView.getContext().getString(R$string.game_mode_copy_toast), 1500L);
    }

    public final void Iii1lill1(boolean z) {
        if (!z) {
            this.f7722lLL1L111l.setNewData(null);
            return;
        }
        this.f7722lLL1L111l.setNewData(((li1) this.f7721ilI11).f7609liIli.modeList);
        int i = ((li1) this.f7721ilI11).f7609liIli.currentMode;
        int i2 = 0;
        for (int i3 = 0; i3 < this.f7722lLL1L111l.getData().size(); i3++) {
            if (i == ((ModeConfig) this.f7722lLL1L111l.getItem(i3)).mode) {
                i2 = i3;
                break;
            }
        }
        this.f7717IiiiL.lll11L(i2);
        this.f7718LIIl.Iii1lill1(((li1) this.f7721ilI11).f7609liIli.switchModeKeycode);
    }

    public final void Ilil11ILI(int i) {
        IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(getContext(), R$style.AppTheme_AlertDialog);
        ((androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l).f3969Iii = getContext().getResources().getString(R$string.game_mode_remove, liIli.l1LLlI(getContext(), (ModeConfig) this.f7722lLL1L111l.getItem(i)));
        ilil11ILI.iilli(R$string.remove, new I1lI111LL(this, i, 0));
        ilil11ILI.IiI1l(R$string.dialog_cancel, new Il1iLli(1));
        liIli.Ii(ilil11ILI.iI1());
        Ii.Ilil11ILI().iIiI1();
    }

    public final void lILlii1L(final int i) {
        Context context = getContext();
        int i2 = R$style.AppTheme_AlertDialog;
        final EditText editText = new EditText(new ILLl(context, i2));
        editText.setSingleLine();
        editText.setHint(R$string.name_of_the_profile);
        editText.setText(liIli.l1LLlI(getContext(), (ModeConfig) this.f7722lLL1L111l.getItem(i)));
        editText.setSelectAllOnFocus(true);
        IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(getContext(), i2);
        int i3 = R$string.rename;
        ilil11ILI.IL(i3);
        ilil11ILI.iilli(i3, new DialogInterface.OnClickListener() { // from class: LILllili.lIIl
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i4) {
                EditText editText2 = editText;
                int i5 = i;
                int i6 = GameModeView.f7715L11I;
                GameModeView gameModeView = this.f2891ilI11;
                gameModeView.getClass();
                try {
                    if (TextUtils.isEmpty(editText2.getText().toString().trim())) {
                        return;
                    }
                    ((ModeConfig) gameModeView.f7722lLL1L111l.getItem(i5)).modeName = editText2.getText().toString().trim();
                    gameModeView.f7722lLL1L111l.notifyItemChanged(i5);
                } catch (Exception unused) {
                }
            }
        });
        ilil11ILI.IiI1l(R$string.dialog_cancel, new Il1iLli(1));
        ((androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l).f3968IiI1l = new III1.Ilil11ILI(this, 1);
        Iii iiiII1 = ilil11ILI.iI1();
        this.f7719LLl1LlLL = iiiII1;
        int iLI1Il = liIli.LI1Il(getContext(), 20.0f);
        int iLI1Il2 = liIli.LI1Il(getContext(), 20.0f);
        ILl iLl = iiiII1.f3959IL1LiliI;
        iLl.f3942iIiI1 = editText;
        iLl.f3943iL = 0;
        iLl.f3954lLliL = true;
        iLl.f3948il1 = iLI1Il;
        iLl.f3941iI1 = iLI1Il2;
        liIli.Ii(this.f7719LLl1LlLL);
        editText.requestFocus();
        Ii.Ilil11ILI().iIiI1();
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        LayoutInflater.from(getContext()).inflate(R$layout.game_mode_layout, this);
        View viewFindViewById = findViewById(R$id.id_bar_back);
        this.lLi1I = viewFindViewById;
        final int i = 0;
        viewFindViewById.setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ GameModeView f2878IiiiL;

            {
                this.f2878IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2878IiiiL.f7721ilI11).il1(32768);
                        break;
                    default:
                        GameModeView.liIli(this.f2878IiiiL);
                        break;
                }
            }
        });
        this.f7716IL1LiliI = findViewById(R$id.id_bar_title);
        this.f7717IiiiL = (RecyclerView) findViewById(R$id.game_mode_layout);
        this.f7722lLL1L111l = new ilI1(this);
        RecyclerView recyclerView = this.f7717IiiiL;
        getContext();
        recyclerView.setLayoutManager(new LinearLayoutManager());
        this.f7717IiiiL.setAdapter(this.f7722lLL1L111l);
        this.f7722lLL1L111l.setOnItemChildClickListener(new Ll1LIL1l(this));
        final int i2 = 1;
        findViewById(R$id.game_mode_add).setOnClickListener(new View.OnClickListener(this) { // from class: LILllili.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ GameModeView f2878IiiiL;

            {
                this.f2878IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i2) {
                    case 0:
                        ((com.chaozhuo.gameassistant.czkeymap.li1) this.f2878IiiiL.f7721ilI11).il1(32768);
                        break;
                    default:
                        GameModeView.liIli(this.f2878IiiiL);
                        break;
                }
            }
        });
        ShortKeyView shortKeyView = (ShortKeyView) findViewById(R$id.id_switch_mode_key);
        this.f7718LIIl = shortKeyView;
        shortKeyView.setOnShortKeyChangeListener(new Ll1LIL1l(this));
        Ilil11ILI ilil11ILI = new Ilil11ILI(getContext(), this);
        this.f7720ii111 = ilil11ILI;
        ilil11ILI.f3651iI1 = liIli.ll(getContext()) ? 1 : 2;
        this.f7716IL1LiliI.setOnTouchListener(new iIiI1(this, 4));
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7721ilI11 = illliil1;
    }

    public GameModeView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7719LLl1LlLL = null;
    }
}
