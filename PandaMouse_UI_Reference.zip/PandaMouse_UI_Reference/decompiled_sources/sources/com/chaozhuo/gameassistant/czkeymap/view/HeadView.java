package com.chaozhuo.gameassistant.czkeymap.view;

import Ll11Ll.Ilil11ILI;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import com.chaozhuo.gameassistant.czkeymap.Ii;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import liIli.liIli;
import p109llL.ILLl;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class HeadView extends LinearLayout implements View.OnClickListener {

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final Ilil11ILI f7723IiiiL;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public iLLLiIl1 f7724LLl1LlLL;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final Context f7725ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final DisplayMetrics f7726lLL1L111l;

    public HeadView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private CharSequence getKeymapSwitchTips() {
        SpannableString spannableString = new SpannableString("Press F10 or Drag   to bottom to toggle keymapping or type text.");
        Context context = this.f7725ilI11;
        boolean zLl = liIli.ll(context);
        Resources resources = context.getResources();
        int i = zLl ? R$drawable.panda_head_portrait : R$drawable.panda_head;
        Resources.Theme theme = context.getTheme();
        ThreadLocal threadLocal = ILLl.f33098liIli;
        Drawable drawable = resources.getDrawable(i, theme);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth() / 4, drawable.getIntrinsicHeight() / 4);
        spannableString.setSpan(new ImageSpan(drawable, 2), 18, 19, 18);
        return spannableString;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        int id = view.getId();
        if (id == R$id.btn_done) {
            Ii.Ilil11ILI().liIli();
            return;
        }
        if (id == R$id.btn_add) {
            ((li1) this.f7724LLl1LlLL).il1(4);
            return;
        }
        if (id == R$id.btn_settings) {
            ((li1) this.f7724LLl1LlLL).il1(1);
            return;
        }
        if (id == R$id.btn_mode) {
            ((li1) this.f7724LLl1LlLL).il1(2);
        } else if (id == R$id.btn_disable) {
            Ii.Ilil11ILI().Iii("switchKeymappingButton:false");
            Ii.Ilil11ILI().ILl(getKeymapSwitchTips(), 2000L);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        Ilil11ILI ilil11ILI;
        boolean zOnInterceptTouchEvent = super.onInterceptTouchEvent(motionEvent);
        if (zOnInterceptTouchEvent || (ilil11ILI = this.f7723IiiiL) == null) {
            return zOnInterceptTouchEvent;
        }
        View view = ilil11ILI.f3653iL;
        int i = ilil11ILI.f3647ILl;
        float rawX = motionEvent.getRawX();
        float rawY = motionEvent.getRawY();
        int action = motionEvent.getAction();
        boolean z = false;
        if (action == 0) {
            ilil11ILI.f3648Iii = false;
            ilil11ILI.f3656liIli = rawX;
            ilil11ILI.f3649Iii1lill1 = rawY;
            ilil11ILI.f3650Ilil11ILI = view.getX();
            ilil11ILI.f3655lILlii1L = view.getY();
            ilil11ILI.f3654il1 = liIli.Il1iLli(ilil11ILI.f3652iIiI1);
            return false;
        }
        if (action != 2) {
            return false;
        }
        if ((ilil11ILI.f3651iI1 & 1) != 0 && Math.abs(rawY - ilil11ILI.f3649Iii1lill1) > Math.abs(rawX - ilil11ILI.f3656liIli) && Math.abs(rawY - ilil11ILI.f3649Iii1lill1) > i) {
            z = true;
        }
        if ((ilil11ILI.f3651iI1 & 2) == 0 || Math.abs(rawX - ilil11ILI.f3656liIli) <= Math.abs(rawY - ilil11ILI.f3649Iii1lill1) || Math.abs(rawX - ilil11ILI.f3656liIli) <= i) {
            return z;
        }
        return true;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        Ilil11ILI ilil11ILI;
        boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
        if (zOnTouchEvent || (ilil11ILI = this.f7723IiiiL) == null) {
            return zOnTouchEvent;
        }
        ilil11ILI.liIli(motionEvent);
        return true;
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7724LLl1LlLL = illliil1;
    }

    public void setVisible(boolean z) {
        Point point;
        float measuredWidth;
        if (!z) {
            setVisibility(4);
            return;
        }
        setVisibility(0);
        Ii iiIlil11ILI = Ii.Ilil11ILI();
        FloatView floatView = iiIlil11ILI.f7526liIli;
        if (floatView == null) {
            point = null;
        } else {
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) floatView.getLayoutParams();
            point = new Point((iiIlil11ILI.f7526liIli.getWidth() / 2) + layoutParams.x, (iiIlil11ILI.f7526liIli.getHeight() / 2) + layoutParams.y);
        }
        if (point == null) {
            return;
        }
        boolean zLl = liIli.ll(this.f7725ilI11);
        DisplayMetrics displayMetrics = this.f7726lLL1L111l;
        if (zLl) {
            float measuredHeight = point.y - (getMeasuredHeight() / 2.0f);
            measuredWidth = measuredHeight >= 0.0f ? measuredHeight : 0.0f;
            float measuredHeight2 = (getMeasuredHeight() / 2.0f) + point.y;
            int i = displayMetrics.heightPixels;
            if (measuredHeight2 > i) {
                measuredWidth = i - (getMeasuredHeight() / 2.0f);
            }
            setY(measuredWidth);
            return;
        }
        float measuredWidth2 = point.x - (getMeasuredWidth() / 2.0f);
        measuredWidth = measuredWidth2 >= 0.0f ? measuredWidth2 : 0.0f;
        float measuredWidth3 = (getMeasuredWidth() / 2.0f) + point.x;
        int i2 = displayMetrics.widthPixels;
        if (measuredWidth3 > i2) {
            measuredWidth = i2 - (getMeasuredWidth() / 2.0f);
        }
        setX(measuredWidth);
    }

    public HeadView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7724LLl1LlLL = null;
        this.f7725ilI11 = context;
        boolean zLl = liIli.ll(context);
        this.f7726lLL1L111l = liIli.Il1iLli(context);
        LayoutInflater.from(context).inflate(R$layout.head_view_layout, this);
        setBackgroundResource(zLl ? R$drawable.head_view_bg_portrait : R$drawable.head_view_bg);
        setOrientation(zLl ? 1 : 0);
        findViewById(R$id.btn_done).setOnClickListener(this);
        findViewById(R$id.btn_disable).setOnClickListener(this);
        findViewById(R$id.btn_add).setOnClickListener(this);
        findViewById(R$id.btn_settings).setOnClickListener(this);
        findViewById(R$id.btn_mode).setOnClickListener(this);
        Ilil11ILI ilil11ILI = new Ilil11ILI(context, this);
        this.f7723IiiiL = ilil11ILI;
        ilil11ILI.f3651iI1 = zLl ? 1 : 2;
        measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
    }
}
