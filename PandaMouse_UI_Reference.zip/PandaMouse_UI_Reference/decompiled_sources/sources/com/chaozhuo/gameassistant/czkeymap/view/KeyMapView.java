package com.chaozhuo.gameassistant.czkeymap.view;

import Il1ii.iLLLiIl1;
import L1ii1iL1.il1;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyInfo;
import com.chaozhuo.gameassistant.czkeymap.li1;
import com.google.android.gms.auth.api.signin.internal.iL;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.UUID;
import liIli.liIli;
import p071ilI1LL.ILl;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeyMapView extends RelativeLayout {

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public static final /* synthetic */ int f7727II1 = 0;
    public final il1 II;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public final IdentityHashMap f7728IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final View f7729IiiiL;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public final iLLLiIl1 f7730L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public com.chaozhuo.gameassistant.czkeymap.iLLLiIl1 f7731LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public BaseView f7732LLl1LlLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public float f7733ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final Context f7734ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final View f7735lLL1L111l;
    public final ArrayList lLi1I;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public final iL f7736lii1;

    public KeyMapView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public static ArrayList Ilil11ILI(View view) {
        if (!(view instanceof ViewGroup)) {
            ArrayList arrayList = new ArrayList();
            if (view.getVisibility() == 0 && view.isFocusable()) {
                arrayList.add(view);
            }
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        ViewGroup viewGroup = (ViewGroup) view;
        if (viewGroup.getVisibility() == 0) {
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                View childAt = viewGroup.getChildAt(i);
                ArrayList arrayList3 = new ArrayList();
                arrayList3.addAll(Ilil11ILI(childAt));
                arrayList2.addAll(arrayList3);
            }
        }
        return arrayList2;
    }

    public final ArrayList ILl(String str) {
        ArrayList arrayList = new ArrayList();
        if (!TextUtils.isEmpty(str)) {
            ArrayList arrayList2 = this.lLi1I;
            int size = arrayList2.size();
            int i = 0;
            while (i < size) {
                Object obj = arrayList2.get(i);
                i++;
                BaseView baseView = (BaseView) obj;
                if ((baseView instanceof OrderKeyView) && TextUtils.equals(baseView.getSpecialClass(), str)) {
                    arrayList.add((OrderKeyView) baseView);
                }
            }
        }
        return arrayList;
    }

    public final BaseView Iii(int i) {
        KeyView keyView;
        BaseView baseView;
        CompassView compassView;
        SmartCancelView smartCancelView;
        MacroKeyView macroKeyView;
        ZoomKeyView zoomKeyView;
        OffCarView offCarView;
        DropView dropView;
        RadialMenuView radialMenuView;
        Context context = this.f7734ilI11;
        if (i == 0) {
            keyView = new KeyView(context);
        } else if (i == 1) {
            compassView = new CompassView(context);
        } else if (i == 20) {
            smartCancelView = new SmartCancelView(context);
            smartCancelView.f7656i1LIiLLl.type = 20;
            smartCancelView.f7661lLiLIli = false;
            smartCancelView.f7657iLLL = false;
        } else if (i == 28) {
            macroKeyView = new MacroKeyView(context);
            macroKeyView.f7656i1LIiLLl.type = 28;
        } else if (i == 36) {
            zoomKeyView = new ZoomKeyView(context);
        } else if (i == 40) {
            offCarView = new OffCarView(context);
            offCarView.f7656i1LIiLLl.type = 40;
            offCarView.f7661lLiLIli = false;
        } else if (i == 49) {
            dropView = new DropView(context);
            dropView.f7656i1LIiLLl.type = 49;
        } else if (i != 50) {
            baseView = null;
            switch (i) {
                case 8:
                    MouseView mouseView = new MouseView(context);
                    mouseView.f7656i1LIiLLl.type = 8;
                    ImageView imageView = new ImageView(context);
                    imageView.setBackgroundResource(R$drawable.btn_mouse);
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
                    layoutParams.addRule(13);
                    mouseView.f7646lIL.addView(imageView, layoutParams);
                    mouseView.f7655Li = false;
                    mouseView.f7661lLiLIli = false;
                    baseView = mouseView;
                    break;
                case 9:
                    FireView fireView = new FireView(context);
                    fireView.f7656i1LIiLLl.type = 9;
                    baseView = fireView;
                    break;
                case 10:
                    SightView sightView = new SightView(context);
                    sightView.f7656i1LIiLLl.type = 10;
                    baseView = sightView;
                    break;
                case 11:
                    CursorPosView cursorPosView = new CursorPosView(context);
                    cursorPosView.f7656i1LIiLLl.type = 11;
                    cursorPosView.f7653LIIl = null;
                    cursorPosView.f7654LLl1LlLL.setVisibility(8);
                    cursorPosView.f7655Li = false;
                    cursorPosView.f7661lLiLIli = false;
                    cursorPosView.f7657iLLL = false;
                    baseView = cursorPosView;
                    break;
                case 12:
                    SmartView smartView = new SmartView(context);
                    smartView.f7656i1LIiLLl.type = 12;
                    smartView.f7661lLiLIli = false;
                    baseView = smartView;
                    break;
                default:
                    switch (i) {
                        case 30:
                            VisualAngleView visualAngleView = new VisualAngleView(context);
                            visualAngleView.f7656i1LIiLLl.type = 30;
                            visualAngleView.f7661lLiLIli = true;
                            baseView = visualAngleView;
                            break;
                        case 31:
                            SmartBackpackView smartBackpackView = new SmartBackpackView(context);
                            smartBackpackView.f7656i1LIiLLl.type = 31;
                            smartBackpackView.f7661lLiLIli = false;
                            baseView = smartBackpackView;
                            break;
                        case 32:
                            MultiplyKeyView multiplyKeyView = new MultiplyKeyView(context);
                            multiplyKeyView.f7740lIL = (TextView) multiplyKeyView.findViewById(R$id.number_view);
                            multiplyKeyView.f7656i1LIiLLl.type = 32;
                            multiplyKeyView.setOperate(1);
                            multiplyKeyView.setTotalTime(200);
                            baseView = multiplyKeyView;
                            break;
                        case 33:
                            SwipeKeyView swipeKeyView = new SwipeKeyView(context);
                            swipeKeyView.f7656i1LIiLLl.type = 33;
                            baseView = swipeKeyView;
                            break;
                        case 34:
                            OrderKeyView orderKeyView = new OrderKeyView(context);
                            orderKeyView.f7741lIL = (TextView) orderKeyView.findViewById(R$id.number_view);
                            KeyInfo keyInfo = orderKeyView.f7656i1LIiLLl;
                            keyInfo.type = 34;
                            keyInfo.specialClass = UUID.randomUUID().toString();
                            baseView = orderKeyView;
                            break;
                    }
                    break;
            }
        } else {
            radialMenuView = new RadialMenuView(context);
            radialMenuView.f7656i1LIiLLl.type = 50;
        }
        if (baseView != null) {
            baseView = keyView;
            baseView = compassView;
            baseView = smartCancelView;
            baseView = macroKeyView;
            baseView = zoomKeyView;
            baseView = offCarView;
            baseView = dropView;
            baseView = radialMenuView;
            baseView.setController(this.f7731LIIl);
            baseView.setVisibility(4);
            addView(baseView);
            this.lLi1I.add(baseView);
        }
        baseView = keyView;
        baseView = compassView;
        baseView = smartCancelView;
        baseView = macroKeyView;
        baseView = zoomKeyView;
        baseView = offCarView;
        baseView = dropView;
        baseView = radialMenuView;
        return baseView;
    }

    public final BaseView Iii1lill1(KeyInfo keyInfo) {
        ArrayList arrayList = this.lLi1I;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            BaseView baseView = (BaseView) obj;
            if (baseView instanceof CompassView) {
                Iterator it = ((CompassView) baseView).f7664ill.values().iterator();
                while (it.hasNext()) {
                    if (((KeyInfo) it.next()) == keyInfo) {
                        return baseView;
                    }
                }
            } else if (baseView instanceof ZoomKeyView) {
                Iterator it2 = ((ZoomKeyView) baseView).f7803ill.values().iterator();
                while (it2.hasNext()) {
                    if (((KeyInfo) it2.next()) == keyInfo) {
                        return baseView;
                    }
                }
            } else if (baseView.getKeyInfo() == keyInfo) {
                return baseView;
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:45:0x0072 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:55:0x0021 A[SYNTHETIC] */
    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i) {
        float fSqrt;
        if (view == null) {
            return super.focusSearch(view, i);
        }
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        float f = iArr[0];
        float f2 = iArr[1];
        ArrayList arrayListIlil11ILI = Ilil11ILI(this);
        int size = arrayListIlil11ILI.size();
        View view2 = null;
        float f3 = Float.MAX_VALUE;
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayListIlil11ILI.get(i2);
            i2++;
            View view3 = (View) obj;
            if (view3 != view) {
                view3.getLocationOnScreen(iArr);
                float f4 = iArr[0];
                float f5 = iArr[1];
                if (i != 17) {
                    if (i != 33) {
                        if (i != 66) {
                            if (i == 130 && f5 > f2) {
                                float fAbs = Math.abs(f4 - f);
                                float fAbs2 = Math.abs(f5 - f2);
                                fSqrt = (float) Math.sqrt((fAbs2 * fAbs2) + (fAbs * fAbs));
                                if (fSqrt < f3) {
                                    view2 = view3;
                                    f3 = fSqrt;
                                }
                            }
                        } else if (f4 > f) {
                            float fAbs3 = Math.abs(f4 - f);
                            float fAbs4 = Math.abs(f5 - f2);
                            fSqrt = (float) Math.sqrt((fAbs4 * fAbs4) + (fAbs3 * fAbs3));
                            if (fSqrt < f3) {
                                view2 = view3;
                                f3 = fSqrt;
                            }
                        }
                    } else if (f5 < f2) {
                        float fAbs5 = Math.abs(f4 - f);
                        float fAbs6 = Math.abs(f5 - f2);
                        fSqrt = (float) Math.sqrt((fAbs6 * fAbs6) + (fAbs5 * fAbs5));
                        if (fSqrt < f3) {
                            view2 = view3;
                            f3 = fSqrt;
                        }
                    }
                } else if (f4 < f) {
                    float fAbs7 = Math.abs(f4 - f);
                    float fAbs8 = Math.abs(f5 - f2);
                    fSqrt = (float) Math.sqrt((fAbs8 * fAbs8) + (fAbs7 * fAbs7));
                    if (fSqrt < f3) {
                        view2 = view3;
                        f3 = fSqrt;
                    }
                }
            }
        }
        return view2 != null ? view2 : (ViewGroup) getParent();
    }

    public LILllili.iL getAlphaSeekbarListener() {
        return this.II;
    }

    public CharSequence getCursorPosTips() {
        Drawable drawableIi1;
        int i = R$string.cursor_pos_tips;
        Context context = this.f7734ilI11;
        String strReplace = context.getString(i).replace("%1$s", "￼");
        SpannableString spannableString = new SpannableString(strReplace);
        int iIndexOf = strReplace.indexOf("￼");
        if (iIndexOf < 0 || (drawableIi1 = liIli.ii1(context, R$drawable.keymap_icon_cursor_default)) == null) {
            return spannableString;
        }
        drawableIi1.setBounds(0, 0, drawableIi1.getIntrinsicWidth() / 2, drawableIi1.getIntrinsicHeight() / 2);
        spannableString.setSpan(new ImageSpan(drawableIi1, 2), iIndexOf, iIndexOf + 1, 18);
        return spannableString;
    }

    public BaseView getFocusedView() {
        return this.f7732LLl1LlLL;
    }

    public LILllili.iL getSizeSeekbarListener() {
        return this.f7736lii1;
    }

    public final BaseView lILlii1L(int i) {
        ArrayList arrayList = this.lLi1I;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            BaseView baseView = (BaseView) obj;
            if (baseView.getType() == i) {
                return baseView;
            }
        }
        return null;
    }

    public final void liIli() {
        BaseView baseView = this.f7732LLl1LlLL;
        if (baseView != null) {
            baseView.Ilil11ILI();
            this.f7732LLl1LlLL = null;
        }
    }

    @Override // android.view.ViewGroup
    public final void onViewRemoved(View view) {
        super.onViewRemoved(view);
        if (view instanceof BaseView) {
            BaseView baseView = (BaseView) view;
            if (this.f7732LLl1LlLL == baseView) {
                liIli();
            }
            ArrayList arrayList = this.lLi1I;
            if (arrayList.contains(baseView)) {
                arrayList.remove(baseView);
            }
        }
    }

    public void setAllViewShowMode(boolean z) {
        ArrayList arrayList = this.lLi1I;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            BaseView baseView = (BaseView) obj;
            if (z) {
                baseView.Iii1lill1();
                if (!ILl.Iii1lill1().f29731ilI11) {
                    baseView.setAlpha(0.0f);
                } else if (baseView instanceof CursorPosView) {
                    baseView.setAlpha(0.0f);
                } else if (baseView instanceof SightPosView) {
                    baseView.setAlpha((baseView.getArgs() & 1) == 0 ? ((li1) this.f7731LIIl).f7609liIli.transparent : 0.0f);
                } else if (baseView instanceof BaseStretchView) {
                    baseView.setAlpha(0.0f);
                } else {
                    baseView.setAlpha(((li1) this.f7731LIIl).f7609liIli.transparent);
                }
            } else {
                baseView.lILlii1L();
                baseView.setAlpha(1.0f);
            }
        }
    }

    public void setController(com.chaozhuo.gameassistant.czkeymap.iLLLiIl1 illliil1) {
        this.f7731LIIl = illliil1;
    }

    public void setFocusView(BaseView baseView) {
        if (this.f7732LLl1LlLL != baseView) {
            liIli();
            this.f7732LLl1LlLL = baseView;
        }
        com.chaozhuo.gameassistant.czkeymap.iLLLiIl1 illliil1 = this.f7731LIIl;
        if (illliil1 != null) {
            li1 li1Var = (li1) illliil1;
            li1Var.f7597ILLl.clear();
            li1Var.f7601Ilil11ILI = 0;
            li1Var.f7607lILlii1L = 0;
        }
        BaseView baseView2 = this.f7732LLl1LlLL;
        if (baseView2 != null) {
            baseView2.requestFocus();
        }
    }

    public KeyMapView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7731LIIl = null;
        this.lLi1I = new ArrayList();
        this.f7728IL1LiliI = new IdentityHashMap();
        this.f7733ii111 = 1.0f;
        this.f7730L11I = new iLLLiIl1(1);
        this.II = new il1(this, 8);
        this.f7736lii1 = new iL(this, 6);
        this.f7734ilI11 = context;
        LayoutInflater.from(context).inflate(R$layout.key_map_view, this);
        this.f7729IiiiL = findViewById(R$id.vertical_line);
        this.f7735lLL1L111l = findViewById(R$id.horizontal_line);
        findViewById(R$id.touch_view).setOnClickListener(new L11L.iL(this, 3));
    }
}
