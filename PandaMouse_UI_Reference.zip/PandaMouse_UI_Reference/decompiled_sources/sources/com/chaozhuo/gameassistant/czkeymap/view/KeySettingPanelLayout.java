package com.chaozhuo.gameassistant.czkeymap.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.chaozhuo.gameassistant.inject.input.ILl;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeySettingPanelLayout extends LinearLayout {
    public KeySettingPanelLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        if (getChildCount() == 0 || View.MeasureSpec.getMode(i2) == 0) {
            super.onMeasure(i, i2);
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getChildAt(0).getLayoutParams();
        layoutParams.height = -2;
        layoutParams.weight = 0.0f;
        int size = View.MeasureSpec.getSize(i2);
        super.onMeasure(i, View.MeasureSpec.makeMeasureSpec(size, Integer.MIN_VALUE));
        int iMin = Math.min(getMeasuredHeight(), size);
        layoutParams.height = 0;
        layoutParams.weight = 1.0f;
        super.onMeasure(i, View.MeasureSpec.makeMeasureSpec(iMin, ILl.f8205iL1));
    }
}
