package com.chaozhuo.gameassistant.czkeymap.view;

import L11L.iL;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$color;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.li1;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeyView extends BaseView {

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public static final /* synthetic */ int f7737IIiiI = 0;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public final ImageView f7738LLi;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public boolean f7739lIllIIiI;

    public KeyView(Context context) {
        super(context, null);
        LayoutInflater.from(this.f7659ilI11).inflate(getViewLayout(), this);
        this.f7650IiiiL = (ImageView) findViewById(R$id.btn_settings);
        this.f7660lLL1L111l = (ImageView) findViewById(R$id.btn_delete);
        this.f7653LIIl = (ImageView) findViewById(R$id.edit_state_bg);
        this.f7654LLl1LlLL = (TextView) findViewById(R$id.shortcut_key);
        ImageView imageView = (ImageView) findViewById(R$id.inner_view);
        this.f7738LLi = imageView;
        imageView.setOnClickListener(new iL(this, 4));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void IiI1l() {
        int color;
        int defaultForeground = getDefaultForeground();
        Context context = this.f7659ilI11;
        Drawable drawableIi1 = liIli.ii1(context, defaultForeground);
        ImageView imageView = this.f7738LLi;
        imageView.setForeground(drawableIi1);
        boolean zIsEmpty = TextUtils.isEmpty(getDefaultText());
        this.f7654LLl1LlLL.setText((this.f7648II1 || !zIsEmpty) ? getDefaultText() : "???");
        this.f7654LLl1LlLL.setTextColor(context.getColor((this.f7648II1 || !zIsEmpty) ? R.color.white : R$color.color_error));
        if (this.f7739lIllIIiI) {
            li1 li1Var = (li1) this.f7662lii1;
            int i = li1Var.f7609liIli.tint;
            if (i < 0) {
                i = 0;
            }
            int[] iArr = LL1.iL.f3003Iii1lill1;
            if (i > 5) {
                i = 5;
            }
            color = li1Var.f7600Iii1lill1.getColor(iArr[i]);
        } else {
            color = this.f7648II1 ? context.getColor(R$color.color_accent) : context.getColor(R$color.color_white);
        }
        imageView.setForegroundTintList(ColorStateList.valueOf(color));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Iii1lill1() {
        this.f7739lIllIIiI = true;
        super.Iii1lill1();
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Ilil11ILI() {
        super.Ilil11ILI();
        IiI1l();
    }

    public int getDefaultForeground() {
        return R$drawable.keymap_icon_default;
    }

    public CharSequence getDefaultText() {
        return this.f7656i1LIiLLl.keyName;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public View getInnerView() {
        return this.f7738LLi;
    }

    public int getTouchDefaultForeground() {
        return R$drawable.keymap_icon_touch_default;
    }

    public int getViewLayout() {
        return R$layout.key_view;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void lILlii1L() {
        this.f7739lIllIIiI = false;
        super.lILlii1L();
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void liIli() {
        this.f7739lIllIIiI = false;
        super.liIli();
        ((li1) this.f7662lii1).f7598ILl.setFocusView(this);
        IiI1l();
    }
}
