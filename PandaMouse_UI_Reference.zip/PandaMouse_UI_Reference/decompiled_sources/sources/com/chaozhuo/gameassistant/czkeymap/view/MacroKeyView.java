package com.chaozhuo.gameassistant.czkeymap.view;

import com.chaozhuo.gameassistant.czkeymap.R$drawable;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class MacroKeyView extends KeyView {
    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView
    public int getDefaultForeground() {
        return R$drawable.keymap_icon_macro_default;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView
    public int getTouchDefaultForeground() {
        return R$drawable.keymap_icon_touch_macro_default;
    }
}
