package com.chaozhuo.gameassistant.czkeymap.view;

import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$layout;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class MultiplyKeyView extends KeyView {

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public TextView f7740lIL;

    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void IiI1l() {
        super.IiI1l();
        int operate = getOperate() & 255;
        if (operate == 255) {
            operate = 1;
        }
        this.f7740lIL.setText(String.format("%dx", Integer.valueOf(operate)));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView
    public int getViewLayout() {
        return R$layout.number_key_view;
    }
}
