package com.chaozhuo.gameassistant.czkeymap.view;

import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.google.android.material.timepicker.TimeModel;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class OrderKeyView extends KeyView {

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public TextView f7741lIL;

    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void IiI1l() {
        super.IiI1l();
        this.f7741lIL.setText(String.format(TimeModel.NUMBER_FORMAT, Integer.valueOf(getOperate() + 1)));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView
    public int getViewLayout() {
        return R$layout.number_key_view;
    }

    public final void iilli(OrderKeyView orderKeyView) {
        setSpecialClass(orderKeyView.getSpecialClass());
        setArgs(orderKeyView.getArgs());
        setTotalTime(orderKeyView.getTotalTime());
        LI1Il(orderKeyView.getKeyCode(), orderKeyView.getModifier(), orderKeyView.getName());
    }
}
