package com.chaozhuo.gameassistant.czkeymap.view;

import L1LLiIII.Ilil11ILI;
import LILllili.Ii;
import LILllili.LI1lllLl;
import LILllili.i1L;
import LILllili.iI11;
import LILllili.iL;
import LILllili.iiiil;
import LILllili.l11l;
import LILllili.li1;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.Iii;
import androidx.appcompat.widget.AppCompatImageView;
import com.chaozhuo.gameassistant.convert.bean.CommandInfo;
import com.chaozhuo.gameassistant.czkeymap.R$color;
import com.chaozhuo.gameassistant.czkeymap.R$dimen;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyInfo;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyMapConfig;
import com.chaozhuo.gameassistant.czkeymap.bean.ModeConfig;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.view.SettingView;
import java.util.ArrayList;
import java.util.List;
import lL1IIi.Iii1lill1;
import liIli.liIli;
import p004IIlI.IiI1l;
import p016Il.lIIl;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SettingView extends RelativeLayout {

    /* JADX INFO: renamed from: Iil, reason: collision with root package name */
    public static int f7742Iil;

    /* JADX INFO: renamed from: Ll11Ll, reason: collision with root package name */
    public static Iii f7743Ll11Ll;

    /* JADX INFO: renamed from: I11l, reason: collision with root package name */
    public int f7744I11l;
    public ShortKeyView I1Ii1IilI;
    public final HeadView II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public final AppCompatImageView f7745II1;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public ShortKeyView f7746IIiiI;

    /* JADX INFO: renamed from: IIlI, reason: collision with root package name */
    public int f7747IIlI;
    public int IIlII;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public final AttributeSettingView f7748IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final boolean f7749IiiiL;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public ShortKeyView f7750IlLi;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public final KeyMapView f7751L11I;

    /* JADX INFO: renamed from: LIIillI, reason: collision with root package name */
    public KeyInfo f7752LIIillI;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public View f7753LIIl;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public int f7754LLIi;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public ShortKeyView f7755LLi;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public final RelativeLayout f7756LLl1LlLL;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public final View f7757Li;

    /* JADX INFO: renamed from: Ll1, reason: collision with root package name */
    public DisplayMetrics f7758Ll1;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public ShortKeyView f7759i1LIiLLl;

    /* JADX INFO: renamed from: i1iLIILl, reason: collision with root package name */
    public ModeConfig f7760i1iLIILl;

    /* JADX INFO: renamed from: i1li1l, reason: collision with root package name */
    public final TouchView f7761i1li1l;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public final RelativeLayout.LayoutParams f7762iLLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public final GameModeView f7763ii111;
    public final ImageView iiIL1liI;
    public boolean iiL;

    /* JADX INFO: renamed from: iil, reason: collision with root package name */
    public int f7764iil;
    public ShortKeyView iilL1Ll;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final Context f7765ilI11;

    /* JADX INFO: renamed from: ilI1LL, reason: collision with root package name */
    public int f7766ilI1LL;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public ShortKeyView f7767ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public int f7768ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public ShortKeyView f7769lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public ShortKeyView f7770lIllIIiI;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public iLLLiIl1 f7771lLL1L111l;

    /* JADX INFO: renamed from: lLLlLlL, reason: collision with root package name */
    public final lIIl f7772lLLlLlL;
    public final ExpandedPanelView lLi1I;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public li1 f7773lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public SwipeDrawLayout f7774lii1;

    /* JADX INFO: renamed from: lll, reason: collision with root package name */
    public int f7775lll;

    public SettingView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public static void ILl(View view, BaseView baseView) {
        if (view.findViewById(R$id.id_sight_mode_wrapper) == null) {
            return;
        }
        Switch r0 = (Switch) view.findViewById(R$id.id_fire_mode_switch);
        TextView textView = (TextView) view.findViewById(R$id.id_fire_mode_tip);
        View viewFindViewById = view.findViewById(R$id.id_seekbar_wrapper);
        CustomSeekBarView customSeekBarView = (CustomSeekBarView) view.findViewById(R$id.id_recoil_seekbar);
        if (r0 == null) {
            return;
        }
        r0.setOnCheckedChangeListener(null);
        r0.setChecked((baseView.getArgs2() & 8) != 0);
        r0.setOnCheckedChangeListener(new iiiil(baseView, textView, viewFindViewById));
        int args2 = (baseView.getArgs2() & 65280) >> 8;
        if (args2 == 0) {
            baseView.setArgs2((baseView.getArgs2() & (-65281)) | 12800);
            args2 = 50;
        }
        customSeekBarView.setOnSeekBarChangeListener(null);
        customSeekBarView.setProgressMin(1);
        customSeekBarView.setProgressMax(200);
        customSeekBarView.setProgress(args2);
        customSeekBarView.setOnSeekBarChangeListener(new Ilil11ILI(baseView, 9));
        ((ImageView) view.findViewById(R$id.id_recoil_info)).setOnClickListener(new Ii(2, view.getContext(), baseView));
    }

    public static void Iii(View view, BaseView baseView) {
        Switch r2;
        if (view.findViewById(R$id.id_touch_mode_wrapper) == null || (r2 = (Switch) view.findViewById(R$id.id_touch_mode_switch)) == null) {
            return;
        }
        r2.setOnCheckedChangeListener(null);
        r2.setChecked((baseView.getArgs2() & 1) != 0);
        r2.setOnCheckedChangeListener(new iI11(baseView, 1));
    }

    public static boolean iI1(int i, String str) {
        if ((65536 & i) == 0) {
            ArrayList arrayList = IiI1l.f597liIli;
            if ((str == null || !str.startsWith("com.dts.freefire")) && !IiI1l.liIli(str)) {
                return false;
            }
        } else if ((i & 131072) == 0) {
            return false;
        }
        return true;
    }

    public static void iIiI1(View view, BaseView baseView) {
        CustomSeekBarView customSeekBarView = (CustomSeekBarView) view.findViewById(R$id.resize_seekbar);
        if (customSeekBarView == null) {
            return;
        }
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(baseView.getContext());
        int iRound = Math.round(((((baseView.getRadiusRatio() * Math.max(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels)) * 2.0f) / baseView.getHeight()) - 0.5f) / 0.025f);
        if (iRound < 1) {
            iRound = 1;
        }
        if (iRound > 100) {
            iRound = 100;
        }
        customSeekBarView.setOnSeekBarChangeListener(null);
        customSeekBarView.setProgress(iRound);
        customSeekBarView.setOnSeekBarChangeListener(new L1i.Iii(baseView, 9));
    }

    public static void iL(View view, BaseView baseView) {
        if (view.findViewById(R$id.id_trigger_coordinate_wrapper) == null) {
            return;
        }
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(baseView.getContext());
        Switch r1 = (Switch) view.findViewById(R$id.id_trigger_mode_switch);
        View viewFindViewById = view.findViewById(R$id.id_xy_wrapper);
        EditText editText = (EditText) view.findViewById(R$id.id_click_x);
        EditText editText2 = (EditText) view.findViewById(R$id.id_click_y);
        ImageView imageView = (ImageView) view.findViewById(R$id.id_marker);
        if (r1 == null || viewFindViewById == null || editText == null || editText2 == null || imageView == null) {
            return;
        }
        I1lI111LL.Ilil11ILI ilil11ILI = new I1lI111LL.Ilil11ILI(imageView);
        boolean z = (baseView.getArgs2() & 2) != 0;
        r1.setOnCheckedChangeListener(null);
        r1.setChecked(z);
        viewFindViewById.setVisibility(z ? 0 : 4);
        r1.setOnCheckedChangeListener(new i1L(viewFindViewById, baseView));
        List<CommandInfo> listOptimizeCommands = CommandInfo.optimizeCommands(baseView.getCommands(), displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels);
        if (listOptimizeCommands.size() == 2) {
            Point point = listOptimizeCommands.get(1).points.get(0);
            editText.setText(String.valueOf(point.x));
            editText2.setText(String.valueOf(point.y));
        } else {
            editText.setText("");
            editText2.setText("");
        }
        LI1lllLl lI1lllLl = new LI1lllLl(editText, editText2, ilil11ILI, new l11l(editText, editText2, displayMetricsIl1iLli, baseView), 4);
        editText.setOnClickListener(lI1lllLl);
        editText2.setOnClickListener(lI1lllLl);
    }

    public static void il1(View view, BaseView baseView) {
        View viewFindViewById = view.findViewById(R$id.id_trigger_using_lmb_wrapper);
        if (viewFindViewById == null) {
            return;
        }
        viewFindViewById.setVisibility(0);
        ((TextView) view.findViewById(R$id.id_trigger_using_lmb_text)).setText(baseView.getType() == 9 ? R$string.keyview_setting_fire_using_lmb : R$string.keyview_setting_trigger_using_lmb);
        Switch r4 = (Switch) view.findViewById(R$id.id_trigger_using_lmb_switch);
        r4.setOnCheckedChangeListener(null);
        r4.setChecked(baseView.getKeyCode() == 311);
        r4.setOnCheckedChangeListener(new iI11(baseView, 2));
    }

    public static void lILlii1L(View view, BaseView baseView) {
        Switch r2 = (Switch) view.findViewById(R$id.id_random_mode_switch);
        if (r2 == null) {
            return;
        }
        r2.setOnCheckedChangeListener(null);
        r2.setChecked((baseView.getArgs2() & 4) != 0);
        r2.setOnCheckedChangeListener(new iI11(baseView, 0));
    }

    private void setTouchable(boolean z) {
        if (liIli.f33010ilI11) {
            liIli.Il("SettingView", "setTouchable: ", Boolean.valueOf(z));
        }
        WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) getLayoutParams();
        if (z) {
            layoutParams.flags = 16777504;
        } else {
            layoutParams.flags = 16777528;
        }
        try {
            ((WindowManager) this.f7765ilI11.getSystemService("window")).updateViewLayout(this, layoutParams);
        } catch (Exception unused) {
        }
    }

    public final void ILLl() {
        KeyMapConfig keyMapConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) this.f7771lLL1L111l).f7609liIli;
        ModeConfig curModeConfig = keyMapConfig.getCurModeConfig();
        KeyInfo keyInfoByType = curModeConfig.getKeyInfoByType(10);
        View view = this.f7757Li;
        if (keyInfoByType == null || iI1(keyInfoByType.args2, keyMapConfig.pkgName) || curModeConfig.sightArea.isEmpty() || ((com.chaozhuo.gameassistant.czkeymap.li1) this.f7771lLL1L111l).f7606il1) {
            view.setVisibility(8);
            return;
        }
        view.setVisibility(0);
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7765ilI11);
        if (liIli.f33010ilI11) {
            liIli.Il("SettingView", "screenMetrics: ", displayMetricsIl1iLli);
        }
        int iRound = Math.round(displayMetricsIl1iLli.widthPixels * curModeConfig.sightArea.left);
        RelativeLayout.LayoutParams layoutParams = this.f7762iLLL;
        layoutParams.setMarginStart(iRound);
        layoutParams.setMarginEnd(Math.round((1.0f - curModeConfig.sightArea.right) * displayMetricsIl1iLli.widthPixels));
        layoutParams.topMargin = Math.round(displayMetricsIl1iLli.heightPixels * curModeConfig.sightArea.top);
        layoutParams.bottomMargin = Math.round((1.0f - curModeConfig.sightArea.bottom) * displayMetricsIl1iLli.heightPixels);
        this.f7756LLl1LlLL.updateViewLayout(view, layoutParams);
    }

    public final void Iii1lill1() {
        setTouchable(true);
        int i = R$color.background_overlay;
        KeyMapView keyMapView = this.f7751L11I;
        keyMapView.setBackgroundResource(i);
        keyMapView.setAllViewShowMode(false);
        this.II.setVisible(true);
        ILLl();
        TouchView touchView = this.f7761i1li1l;
        touchView.f7799IiiiL.clear();
        touchView.invalidate();
    }

    public final void Ilil11ILI(View view) {
        if (view.getVisibility() != 0) {
            return;
        }
        if (this.f7749IiiiL) {
            Iii1lill1.lli11(view, 8, View.TRANSLATION_X, -view.getWidth());
        } else {
            Iii1lill1.lli11(view, 8, View.TRANSLATION_Y, -view.getHeight());
        }
    }

    public final void LI1Il(int i) {
        SwipeDrawLayout swipeDrawLayout;
        int i2 = this.f7768ill;
        if (i2 == i) {
            return;
        }
        AttributeSettingView attributeSettingView = this.f7748IL1LiliI;
        GameModeView gameModeView = this.f7763ii111;
        ExpandedPanelView expandedPanelView = this.lLi1I;
        if (i2 == 1) {
            attributeSettingView.liIli(false);
            Ilil11ILI(attributeSettingView);
        } else if (i2 == 2) {
            gameModeView.Iii1lill1(false);
            Ilil11ILI(gameModeView);
        } else if (i2 == 4) {
            expandedPanelView.getClass();
            Ilil11ILI(expandedPanelView);
        } else if (i2 == 8 && (swipeDrawLayout = this.f7774lii1) != null) {
            swipeDrawLayout.liIli(false);
        }
        this.f7768ill = i;
        KeyMapView keyMapView = this.f7751L11I;
        if (i == 1) {
            keyMapView.liIli();
            attributeSettingView.liIli(true);
            lLliL(attributeSettingView);
            return;
        }
        if (i == 2) {
            keyMapView.liIli();
            gameModeView.Iii1lill1(true);
            lLliL(gameModeView);
        } else if (i == 4) {
            keyMapView.liIli();
            expandedPanelView.f7687IiiiL.setText(expandedPanelView.getResources().getString(R$string.current_game_mode, liIli.l1LLlI(expandedPanelView.getContext(), ((com.chaozhuo.gameassistant.czkeymap.li1) expandedPanelView.f7689LIIl).f7609liIli.getCurModeConfig())));
            lLliL(expandedPanelView);
        } else {
            if (i != 8) {
                return;
            }
            keyMapView.liIli();
            if (this.f7774lii1 == null) {
                SwipeDrawLayout swipeDrawLayout2 = new SwipeDrawLayout(this.f7765ilI11, null);
                this.f7774lii1 = swipeDrawLayout2;
                swipeDrawLayout2.setController(this.f7771lLL1L111l);
                this.f7756LLl1LlLL.addView(this.f7774lii1, new RelativeLayout.LayoutParams(-1, -1));
            }
            this.f7774lii1.liIli(true);
        }
    }

    public iL getAlphaSeekbarListener() {
        return this.f7751L11I.getAlphaSeekbarListener();
    }

    public Rect getExpandedPanelRect() {
        ExpandedPanelView expandedPanelView = this.lLi1I;
        return new Rect((int) expandedPanelView.getX(), (int) expandedPanelView.getY(), expandedPanelView.getWidth() + ((int) expandedPanelView.getX()), expandedPanelView.getHeight() + ((int) expandedPanelView.getY()));
    }

    public BaseView getFocusedView() {
        return this.f7751L11I.getFocusedView();
    }

    public iL getSizeSeekbarListener() {
        return this.f7751L11I.getSizeSeekbarListener();
    }

    public final void lLliL(View view) {
        if (view.getVisibility() == 0) {
            return;
        }
        view.bringToFront();
        view.requestFocus();
        boolean z = this.f7749IiiiL;
        HeadView headView = this.II;
        Context context = this.f7765ilI11;
        if (z) {
            Iii1lill1.i1(view, View.TRANSLATION_X, -view.getWidth());
            DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(context);
            int dimensionPixelSize = context.getResources().getDimensionPixelSize(R$dimen.setting_view_height);
            float y = headView.getY();
            float f = dimensionPixelSize + y;
            int i = displayMetricsIl1iLli.heightPixels;
            if (f > i) {
                y = i - dimensionPixelSize;
            }
            view.setY(y);
            return;
        }
        Iii1lill1.i1(view, View.TRANSLATION_Y, -view.getHeight());
        DisplayMetrics displayMetricsIl1iLli2 = liIli.Il1iLli(context);
        int dimensionPixelSize2 = context.getResources().getDimensionPixelSize(R$dimen.setting_view_width);
        float x = headView.getX();
        float f2 = dimensionPixelSize2 + x;
        int i2 = displayMetricsIl1iLli2.widthPixels;
        if (f2 > i2) {
            x = i2 - dimensionPixelSize2;
        }
        view.setX(x);
    }

    public final void liIli() {
        setTouchable(false);
        KeyMapView keyMapView = this.f7751L11I;
        keyMapView.liIli();
        keyMapView.setBackground(null);
        keyMapView.setAllViewShowMode(true);
        LI1Il(32768);
        this.II.setVisible(false);
        ILLl();
        View view = this.f7753LIIl;
        if (view != null) {
            try {
                this.f7756LLl1LlLL.removeView(view);
            } catch (Exception unused) {
            }
            this.f7753LIIl = null;
        }
    }

    public void setAllViewShowMode(boolean z) {
        this.f7751L11I.setAllViewShowMode(z);
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7771lLL1L111l = illliil1;
        this.lLi1I.setController(illliil1);
        this.f7748IL1LiliI.setController(this.f7771lLL1L111l);
        this.II.setController(this.f7771lLL1L111l);
        this.f7763ii111.setController(this.f7771lLL1L111l);
        this.f7751L11I.setController(illliil1);
    }

    public void setFocusView(BaseView baseView) {
        this.f7751L11I.setFocusView(baseView);
    }

    public SettingView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7771lLL1L111l = null;
        this.f7768ill = 0;
        this.iiL = false;
        this.f7772lLLlLlL = new lIIl(this, 7);
        this.f7758Ll1 = new DisplayMetrics();
        this.f7747IIlI = 0;
        this.f7766ilI1LL = 0;
        this.f7765ilI11 = context;
        this.f7749IiiiL = liIli.ll(context);
        LayoutInflater.from(context).inflate(R$layout.setting_layout, this);
        measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
        this.f7756LLl1LlLL = (RelativeLayout) findViewById(R$id.id_setting_view_root);
        this.f7761i1li1l = (TouchView) findViewById(R$id.id_touch_view);
        this.lLi1I = (ExpandedPanelView) findViewById(R$id.expanded_panel);
        this.f7748IL1LiliI = (AttributeSettingView) findViewById(R$id.view_attribute_panel);
        this.f7763ii111 = (GameModeView) findViewById(R$id.game_mode_view);
        this.f7751L11I = (KeyMapView) findViewById(R$id.key_map_view);
        this.II = (HeadView) findViewById(R$id.head_view);
        View viewFindViewById = findViewById(R$id.key_setting_sight_area);
        this.f7757Li = viewFindViewById;
        this.f7762iLLL = (RelativeLayout.LayoutParams) viewFindViewById.getLayoutParams();
        final int i2 = 0;
        viewFindViewById.findViewById(R$id.id_drag_left).setOnTouchListener(new View.OnTouchListener(this) { // from class: LILllili.Liii1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingView f2820IiiiL;

            {
                this.f2820IiiiL = this;
            }

            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int i3 = i2;
                SettingView settingView = this.f2820IiiiL;
                switch (i3) {
                    case 0:
                        androidx.appcompat.app.Iii iii2 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX = (int) motionEvent.getRawX();
                        int rawY = (int) motionEvent.getRawY();
                        int actionMasked = motionEvent.getActionMasked();
                        if (actionMasked == 0) {
                            settingView.f7744I11l = rawX;
                            settingView.f7764iil = rawY;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginStart();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig;
                            settingView.f7752LIIillI = curModeConfig.getKeyInfoByType(10);
                        } else if (actionMasked == 1) {
                            settingView.f7760i1iLIILl.sightArea.left = (settingView.f7762iLLL.getMarginStart() * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked == 2) {
                            int i4 = (settingView.f7775lll + rawX) - settingView.f7744I11l;
                            if (i4 < 0) {
                                i4 = 0;
                            }
                            KeyInfo keyInfo = settingView.f7752LIIillI;
                            if (keyInfo != null && !keyInfo.keyPosList.isEmpty()) {
                                float f = (settingView.f7752LIIillI.keyPosList.get(0).x * settingView.f7758Ll1.widthPixels) - 100.0f;
                                if (i4 > f) {
                                    i4 = (int) f;
                                }
                            }
                            settingView.f7762iLLL.setMarginStart(i4);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 1:
                        androidx.appcompat.app.Iii iii3 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX2 = (int) motionEvent.getRawX();
                        int rawY2 = (int) motionEvent.getRawY();
                        int actionMasked2 = motionEvent.getActionMasked();
                        if (actionMasked2 == 0) {
                            settingView.f7744I11l = rawX2;
                            settingView.f7764iil = rawY2;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginEnd();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig2 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig2;
                            settingView.f7752LIIillI = curModeConfig2.getKeyInfoByType(10);
                        } else if (actionMasked2 == 1) {
                            settingView.f7760i1iLIILl.sightArea.right = ((settingView.f7758Ll1.widthPixels - settingView.f7762iLLL.getMarginEnd()) * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked2 == 2) {
                            int i5 = (settingView.f7775lll - rawX2) + settingView.f7744I11l;
                            if (i5 < 0) {
                                i5 = 0;
                            }
                            KeyInfo keyInfo2 = settingView.f7752LIIillI;
                            if (keyInfo2 != null && !keyInfo2.keyPosList.isEmpty()) {
                                float f2 = settingView.f7752LIIillI.keyPosList.get(0).x;
                                float f3 = settingView.f7758Ll1.widthPixels;
                                float f4 = (f3 - (f2 * f3)) - 100.0f;
                                if (i5 > f4) {
                                    i5 = (int) f4;
                                }
                            }
                            settingView.f7762iLLL.setMarginEnd(i5);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 2:
                        androidx.appcompat.app.Iii iii4 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX3 = (int) motionEvent.getRawX();
                        int rawY3 = (int) motionEvent.getRawY();
                        int actionMasked3 = motionEvent.getActionMasked();
                        if (actionMasked3 == 0) {
                            settingView.f7744I11l = rawX3;
                            settingView.f7764iil = rawY3;
                            settingView.f7775lll = settingView.f7762iLLL.topMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig3 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig3;
                            settingView.f7752LIIillI = curModeConfig3.getKeyInfoByType(10);
                        } else if (actionMasked3 == 1) {
                            settingView.f7760i1iLIILl.sightArea.top = (settingView.f7762iLLL.topMargin * 1.0f) / settingView.f7758Ll1.heightPixels;
                        } else if (actionMasked3 == 2) {
                            int i6 = (settingView.f7775lll + rawY3) - settingView.f7764iil;
                            if (i6 < 0) {
                                i6 = 0;
                            }
                            KeyInfo keyInfo3 = settingView.f7752LIIillI;
                            if (keyInfo3 != null && !keyInfo3.keyPosList.isEmpty()) {
                                float f5 = (settingView.f7752LIIillI.keyPosList.get(0).y * settingView.f7758Ll1.heightPixels) - 50.0f;
                                if (i6 > f5) {
                                    i6 = (int) f5;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams = settingView.f7762iLLL;
                            layoutParams.topMargin = i6;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams);
                        }
                        break;
                    default:
                        androidx.appcompat.app.Iii iii5 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX4 = (int) motionEvent.getRawX();
                        int rawY4 = (int) motionEvent.getRawY();
                        int actionMasked4 = motionEvent.getActionMasked();
                        if (actionMasked4 == 0) {
                            settingView.f7744I11l = rawX4;
                            settingView.f7764iil = rawY4;
                            settingView.f7775lll = settingView.f7762iLLL.bottomMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig4 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig4;
                            settingView.f7752LIIillI = curModeConfig4.getKeyInfoByType(10);
                        } else if (actionMasked4 == 1) {
                            RectF rectF = settingView.f7760i1iLIILl.sightArea;
                            int i7 = settingView.f7758Ll1.heightPixels;
                            rectF.bottom = ((i7 - settingView.f7762iLLL.bottomMargin) * 1.0f) / i7;
                        } else if (actionMasked4 == 2) {
                            int i8 = (settingView.f7775lll - rawY4) + settingView.f7764iil;
                            if (i8 < 0) {
                                i8 = 0;
                            }
                            KeyInfo keyInfo4 = settingView.f7752LIIillI;
                            if (keyInfo4 != null && !keyInfo4.keyPosList.isEmpty()) {
                                float f6 = settingView.f7752LIIillI.keyPosList.get(0).y;
                                float f7 = settingView.f7758Ll1.heightPixels;
                                float f8 = (f7 - (f6 * f7)) - 50.0f;
                                if (i8 > f8) {
                                    i8 = (int) f8;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams2 = settingView.f7762iLLL;
                            layoutParams2.bottomMargin = i8;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams2);
                        }
                        break;
                }
                return true;
            }
        });
        final int i3 = 1;
        viewFindViewById.findViewById(R$id.id_drag_right).setOnTouchListener(new View.OnTouchListener(this) { // from class: LILllili.Liii1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingView f2820IiiiL;

            {
                this.f2820IiiiL = this;
            }

            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int i4 = i3;
                SettingView settingView = this.f2820IiiiL;
                switch (i4) {
                    case 0:
                        androidx.appcompat.app.Iii iii2 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX = (int) motionEvent.getRawX();
                        int rawY = (int) motionEvent.getRawY();
                        int actionMasked = motionEvent.getActionMasked();
                        if (actionMasked == 0) {
                            settingView.f7744I11l = rawX;
                            settingView.f7764iil = rawY;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginStart();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig;
                            settingView.f7752LIIillI = curModeConfig.getKeyInfoByType(10);
                        } else if (actionMasked == 1) {
                            settingView.f7760i1iLIILl.sightArea.left = (settingView.f7762iLLL.getMarginStart() * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked == 2) {
                            int i5 = (settingView.f7775lll + rawX) - settingView.f7744I11l;
                            if (i5 < 0) {
                                i5 = 0;
                            }
                            KeyInfo keyInfo = settingView.f7752LIIillI;
                            if (keyInfo != null && !keyInfo.keyPosList.isEmpty()) {
                                float f = (settingView.f7752LIIillI.keyPosList.get(0).x * settingView.f7758Ll1.widthPixels) - 100.0f;
                                if (i5 > f) {
                                    i5 = (int) f;
                                }
                            }
                            settingView.f7762iLLL.setMarginStart(i5);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 1:
                        androidx.appcompat.app.Iii iii3 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX2 = (int) motionEvent.getRawX();
                        int rawY2 = (int) motionEvent.getRawY();
                        int actionMasked2 = motionEvent.getActionMasked();
                        if (actionMasked2 == 0) {
                            settingView.f7744I11l = rawX2;
                            settingView.f7764iil = rawY2;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginEnd();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig2 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig2;
                            settingView.f7752LIIillI = curModeConfig2.getKeyInfoByType(10);
                        } else if (actionMasked2 == 1) {
                            settingView.f7760i1iLIILl.sightArea.right = ((settingView.f7758Ll1.widthPixels - settingView.f7762iLLL.getMarginEnd()) * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked2 == 2) {
                            int i6 = (settingView.f7775lll - rawX2) + settingView.f7744I11l;
                            if (i6 < 0) {
                                i6 = 0;
                            }
                            KeyInfo keyInfo2 = settingView.f7752LIIillI;
                            if (keyInfo2 != null && !keyInfo2.keyPosList.isEmpty()) {
                                float f2 = settingView.f7752LIIillI.keyPosList.get(0).x;
                                float f3 = settingView.f7758Ll1.widthPixels;
                                float f4 = (f3 - (f2 * f3)) - 100.0f;
                                if (i6 > f4) {
                                    i6 = (int) f4;
                                }
                            }
                            settingView.f7762iLLL.setMarginEnd(i6);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 2:
                        androidx.appcompat.app.Iii iii4 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX3 = (int) motionEvent.getRawX();
                        int rawY3 = (int) motionEvent.getRawY();
                        int actionMasked3 = motionEvent.getActionMasked();
                        if (actionMasked3 == 0) {
                            settingView.f7744I11l = rawX3;
                            settingView.f7764iil = rawY3;
                            settingView.f7775lll = settingView.f7762iLLL.topMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig3 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig3;
                            settingView.f7752LIIillI = curModeConfig3.getKeyInfoByType(10);
                        } else if (actionMasked3 == 1) {
                            settingView.f7760i1iLIILl.sightArea.top = (settingView.f7762iLLL.topMargin * 1.0f) / settingView.f7758Ll1.heightPixels;
                        } else if (actionMasked3 == 2) {
                            int i7 = (settingView.f7775lll + rawY3) - settingView.f7764iil;
                            if (i7 < 0) {
                                i7 = 0;
                            }
                            KeyInfo keyInfo3 = settingView.f7752LIIillI;
                            if (keyInfo3 != null && !keyInfo3.keyPosList.isEmpty()) {
                                float f5 = (settingView.f7752LIIillI.keyPosList.get(0).y * settingView.f7758Ll1.heightPixels) - 50.0f;
                                if (i7 > f5) {
                                    i7 = (int) f5;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams = settingView.f7762iLLL;
                            layoutParams.topMargin = i7;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams);
                        }
                        break;
                    default:
                        androidx.appcompat.app.Iii iii5 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX4 = (int) motionEvent.getRawX();
                        int rawY4 = (int) motionEvent.getRawY();
                        int actionMasked4 = motionEvent.getActionMasked();
                        if (actionMasked4 == 0) {
                            settingView.f7744I11l = rawX4;
                            settingView.f7764iil = rawY4;
                            settingView.f7775lll = settingView.f7762iLLL.bottomMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig4 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig4;
                            settingView.f7752LIIillI = curModeConfig4.getKeyInfoByType(10);
                        } else if (actionMasked4 == 1) {
                            RectF rectF = settingView.f7760i1iLIILl.sightArea;
                            int i8 = settingView.f7758Ll1.heightPixels;
                            rectF.bottom = ((i8 - settingView.f7762iLLL.bottomMargin) * 1.0f) / i8;
                        } else if (actionMasked4 == 2) {
                            int i9 = (settingView.f7775lll - rawY4) + settingView.f7764iil;
                            if (i9 < 0) {
                                i9 = 0;
                            }
                            KeyInfo keyInfo4 = settingView.f7752LIIillI;
                            if (keyInfo4 != null && !keyInfo4.keyPosList.isEmpty()) {
                                float f6 = settingView.f7752LIIillI.keyPosList.get(0).y;
                                float f7 = settingView.f7758Ll1.heightPixels;
                                float f8 = (f7 - (f6 * f7)) - 50.0f;
                                if (i9 > f8) {
                                    i9 = (int) f8;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams2 = settingView.f7762iLLL;
                            layoutParams2.bottomMargin = i9;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams2);
                        }
                        break;
                }
                return true;
            }
        });
        final int i4 = 2;
        viewFindViewById.findViewById(R$id.id_drag_top).setOnTouchListener(new View.OnTouchListener(this) { // from class: LILllili.Liii1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingView f2820IiiiL;

            {
                this.f2820IiiiL = this;
            }

            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int i5 = i4;
                SettingView settingView = this.f2820IiiiL;
                switch (i5) {
                    case 0:
                        androidx.appcompat.app.Iii iii2 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX = (int) motionEvent.getRawX();
                        int rawY = (int) motionEvent.getRawY();
                        int actionMasked = motionEvent.getActionMasked();
                        if (actionMasked == 0) {
                            settingView.f7744I11l = rawX;
                            settingView.f7764iil = rawY;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginStart();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig;
                            settingView.f7752LIIillI = curModeConfig.getKeyInfoByType(10);
                        } else if (actionMasked == 1) {
                            settingView.f7760i1iLIILl.sightArea.left = (settingView.f7762iLLL.getMarginStart() * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked == 2) {
                            int i6 = (settingView.f7775lll + rawX) - settingView.f7744I11l;
                            if (i6 < 0) {
                                i6 = 0;
                            }
                            KeyInfo keyInfo = settingView.f7752LIIillI;
                            if (keyInfo != null && !keyInfo.keyPosList.isEmpty()) {
                                float f = (settingView.f7752LIIillI.keyPosList.get(0).x * settingView.f7758Ll1.widthPixels) - 100.0f;
                                if (i6 > f) {
                                    i6 = (int) f;
                                }
                            }
                            settingView.f7762iLLL.setMarginStart(i6);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 1:
                        androidx.appcompat.app.Iii iii3 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX2 = (int) motionEvent.getRawX();
                        int rawY2 = (int) motionEvent.getRawY();
                        int actionMasked2 = motionEvent.getActionMasked();
                        if (actionMasked2 == 0) {
                            settingView.f7744I11l = rawX2;
                            settingView.f7764iil = rawY2;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginEnd();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig2 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig2;
                            settingView.f7752LIIillI = curModeConfig2.getKeyInfoByType(10);
                        } else if (actionMasked2 == 1) {
                            settingView.f7760i1iLIILl.sightArea.right = ((settingView.f7758Ll1.widthPixels - settingView.f7762iLLL.getMarginEnd()) * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked2 == 2) {
                            int i7 = (settingView.f7775lll - rawX2) + settingView.f7744I11l;
                            if (i7 < 0) {
                                i7 = 0;
                            }
                            KeyInfo keyInfo2 = settingView.f7752LIIillI;
                            if (keyInfo2 != null && !keyInfo2.keyPosList.isEmpty()) {
                                float f2 = settingView.f7752LIIillI.keyPosList.get(0).x;
                                float f3 = settingView.f7758Ll1.widthPixels;
                                float f4 = (f3 - (f2 * f3)) - 100.0f;
                                if (i7 > f4) {
                                    i7 = (int) f4;
                                }
                            }
                            settingView.f7762iLLL.setMarginEnd(i7);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 2:
                        androidx.appcompat.app.Iii iii4 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX3 = (int) motionEvent.getRawX();
                        int rawY3 = (int) motionEvent.getRawY();
                        int actionMasked3 = motionEvent.getActionMasked();
                        if (actionMasked3 == 0) {
                            settingView.f7744I11l = rawX3;
                            settingView.f7764iil = rawY3;
                            settingView.f7775lll = settingView.f7762iLLL.topMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig3 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig3;
                            settingView.f7752LIIillI = curModeConfig3.getKeyInfoByType(10);
                        } else if (actionMasked3 == 1) {
                            settingView.f7760i1iLIILl.sightArea.top = (settingView.f7762iLLL.topMargin * 1.0f) / settingView.f7758Ll1.heightPixels;
                        } else if (actionMasked3 == 2) {
                            int i8 = (settingView.f7775lll + rawY3) - settingView.f7764iil;
                            if (i8 < 0) {
                                i8 = 0;
                            }
                            KeyInfo keyInfo3 = settingView.f7752LIIillI;
                            if (keyInfo3 != null && !keyInfo3.keyPosList.isEmpty()) {
                                float f5 = (settingView.f7752LIIillI.keyPosList.get(0).y * settingView.f7758Ll1.heightPixels) - 50.0f;
                                if (i8 > f5) {
                                    i8 = (int) f5;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams = settingView.f7762iLLL;
                            layoutParams.topMargin = i8;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams);
                        }
                        break;
                    default:
                        androidx.appcompat.app.Iii iii5 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX4 = (int) motionEvent.getRawX();
                        int rawY4 = (int) motionEvent.getRawY();
                        int actionMasked4 = motionEvent.getActionMasked();
                        if (actionMasked4 == 0) {
                            settingView.f7744I11l = rawX4;
                            settingView.f7764iil = rawY4;
                            settingView.f7775lll = settingView.f7762iLLL.bottomMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig4 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig4;
                            settingView.f7752LIIillI = curModeConfig4.getKeyInfoByType(10);
                        } else if (actionMasked4 == 1) {
                            RectF rectF = settingView.f7760i1iLIILl.sightArea;
                            int i9 = settingView.f7758Ll1.heightPixels;
                            rectF.bottom = ((i9 - settingView.f7762iLLL.bottomMargin) * 1.0f) / i9;
                        } else if (actionMasked4 == 2) {
                            int i10 = (settingView.f7775lll - rawY4) + settingView.f7764iil;
                            if (i10 < 0) {
                                i10 = 0;
                            }
                            KeyInfo keyInfo4 = settingView.f7752LIIillI;
                            if (keyInfo4 != null && !keyInfo4.keyPosList.isEmpty()) {
                                float f6 = settingView.f7752LIIillI.keyPosList.get(0).y;
                                float f7 = settingView.f7758Ll1.heightPixels;
                                float f8 = (f7 - (f6 * f7)) - 50.0f;
                                if (i10 > f8) {
                                    i10 = (int) f8;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams2 = settingView.f7762iLLL;
                            layoutParams2.bottomMargin = i10;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams2);
                        }
                        break;
                }
                return true;
            }
        });
        final int i5 = 3;
        viewFindViewById.findViewById(R$id.id_drag_bottom).setOnTouchListener(new View.OnTouchListener(this) { // from class: LILllili.Liii1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingView f2820IiiiL;

            {
                this.f2820IiiiL = this;
            }

            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int i6 = i5;
                SettingView settingView = this.f2820IiiiL;
                switch (i6) {
                    case 0:
                        androidx.appcompat.app.Iii iii2 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX = (int) motionEvent.getRawX();
                        int rawY = (int) motionEvent.getRawY();
                        int actionMasked = motionEvent.getActionMasked();
                        if (actionMasked == 0) {
                            settingView.f7744I11l = rawX;
                            settingView.f7764iil = rawY;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginStart();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig;
                            settingView.f7752LIIillI = curModeConfig.getKeyInfoByType(10);
                        } else if (actionMasked == 1) {
                            settingView.f7760i1iLIILl.sightArea.left = (settingView.f7762iLLL.getMarginStart() * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked == 2) {
                            int i7 = (settingView.f7775lll + rawX) - settingView.f7744I11l;
                            if (i7 < 0) {
                                i7 = 0;
                            }
                            KeyInfo keyInfo = settingView.f7752LIIillI;
                            if (keyInfo != null && !keyInfo.keyPosList.isEmpty()) {
                                float f = (settingView.f7752LIIillI.keyPosList.get(0).x * settingView.f7758Ll1.widthPixels) - 100.0f;
                                if (i7 > f) {
                                    i7 = (int) f;
                                }
                            }
                            settingView.f7762iLLL.setMarginStart(i7);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 1:
                        androidx.appcompat.app.Iii iii3 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX2 = (int) motionEvent.getRawX();
                        int rawY2 = (int) motionEvent.getRawY();
                        int actionMasked2 = motionEvent.getActionMasked();
                        if (actionMasked2 == 0) {
                            settingView.f7744I11l = rawX2;
                            settingView.f7764iil = rawY2;
                            settingView.f7775lll = settingView.f7762iLLL.getMarginEnd();
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig2 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig2;
                            settingView.f7752LIIillI = curModeConfig2.getKeyInfoByType(10);
                        } else if (actionMasked2 == 1) {
                            settingView.f7760i1iLIILl.sightArea.right = ((settingView.f7758Ll1.widthPixels - settingView.f7762iLLL.getMarginEnd()) * 1.0f) / settingView.f7758Ll1.widthPixels;
                        } else if (actionMasked2 == 2) {
                            int i8 = (settingView.f7775lll - rawX2) + settingView.f7744I11l;
                            if (i8 < 0) {
                                i8 = 0;
                            }
                            KeyInfo keyInfo2 = settingView.f7752LIIillI;
                            if (keyInfo2 != null && !keyInfo2.keyPosList.isEmpty()) {
                                float f2 = settingView.f7752LIIillI.keyPosList.get(0).x;
                                float f3 = settingView.f7758Ll1.widthPixels;
                                float f4 = (f3 - (f2 * f3)) - 100.0f;
                                if (i8 > f4) {
                                    i8 = (int) f4;
                                }
                            }
                            settingView.f7762iLLL.setMarginEnd(i8);
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, settingView.f7762iLLL);
                        }
                        break;
                    case 2:
                        androidx.appcompat.app.Iii iii4 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX3 = (int) motionEvent.getRawX();
                        int rawY3 = (int) motionEvent.getRawY();
                        int actionMasked3 = motionEvent.getActionMasked();
                        if (actionMasked3 == 0) {
                            settingView.f7744I11l = rawX3;
                            settingView.f7764iil = rawY3;
                            settingView.f7775lll = settingView.f7762iLLL.topMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig3 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig3;
                            settingView.f7752LIIillI = curModeConfig3.getKeyInfoByType(10);
                        } else if (actionMasked3 == 1) {
                            settingView.f7760i1iLIILl.sightArea.top = (settingView.f7762iLLL.topMargin * 1.0f) / settingView.f7758Ll1.heightPixels;
                        } else if (actionMasked3 == 2) {
                            int i9 = (settingView.f7775lll + rawY3) - settingView.f7764iil;
                            if (i9 < 0) {
                                i9 = 0;
                            }
                            KeyInfo keyInfo3 = settingView.f7752LIIillI;
                            if (keyInfo3 != null && !keyInfo3.keyPosList.isEmpty()) {
                                float f5 = (settingView.f7752LIIillI.keyPosList.get(0).y * settingView.f7758Ll1.heightPixels) - 50.0f;
                                if (i9 > f5) {
                                    i9 = (int) f5;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams = settingView.f7762iLLL;
                            layoutParams.topMargin = i9;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams);
                        }
                        break;
                    default:
                        androidx.appcompat.app.Iii iii5 = SettingView.f7743Ll11Ll;
                        settingView.getClass();
                        int rawX4 = (int) motionEvent.getRawX();
                        int rawY4 = (int) motionEvent.getRawY();
                        int actionMasked4 = motionEvent.getActionMasked();
                        if (actionMasked4 == 0) {
                            settingView.f7744I11l = rawX4;
                            settingView.f7764iil = rawY4;
                            settingView.f7775lll = settingView.f7762iLLL.bottomMargin;
                            settingView.f7758Ll1 = liIli.liIli.Il1iLli(settingView.f7765ilI11);
                            ModeConfig curModeConfig4 = ((com.chaozhuo.gameassistant.czkeymap.li1) settingView.f7771lLL1L111l).f7609liIli.getCurModeConfig();
                            settingView.f7760i1iLIILl = curModeConfig4;
                            settingView.f7752LIIillI = curModeConfig4.getKeyInfoByType(10);
                        } else if (actionMasked4 == 1) {
                            RectF rectF = settingView.f7760i1iLIILl.sightArea;
                            int i10 = settingView.f7758Ll1.heightPixels;
                            rectF.bottom = ((i10 - settingView.f7762iLLL.bottomMargin) * 1.0f) / i10;
                        } else if (actionMasked4 == 2) {
                            int i11 = (settingView.f7775lll - rawY4) + settingView.f7764iil;
                            if (i11 < 0) {
                                i11 = 0;
                            }
                            KeyInfo keyInfo4 = settingView.f7752LIIillI;
                            if (keyInfo4 != null && !keyInfo4.keyPosList.isEmpty()) {
                                float f6 = settingView.f7752LIIillI.keyPosList.get(0).y;
                                float f7 = settingView.f7758Ll1.heightPixels;
                                float f8 = (f7 - (f6 * f7)) - 50.0f;
                                if (i11 > f8) {
                                    i11 = (int) f8;
                                }
                            }
                            RelativeLayout.LayoutParams layoutParams2 = settingView.f7762iLLL;
                            layoutParams2.bottomMargin = i11;
                            settingView.f7756LLl1LlLL.updateViewLayout(settingView.f7757Li, layoutParams2);
                        }
                        break;
                }
                return true;
            }
        });
        this.f7745II1 = (AppCompatImageView) findViewById(R$id.id_crosshair);
        this.iiIL1liI = (ImageView) findViewById(R$id.id_cursor_view);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.type = liIli.lI();
        layoutParams.format = -3;
        layoutParams.flags = 16777528;
        layoutParams.width = -1;
        layoutParams.height = -1;
        if (Build.VERSION.SDK_INT >= 28) {
            layoutParams.layoutInDisplayCutoutMode = 1;
        }
        layoutParams.gravity = 49;
        setLayoutParams(layoutParams);
        setSystemUiVisibility(5894);
    }
}
