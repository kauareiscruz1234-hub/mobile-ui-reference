package com.chaozhuo.gameassistant.czkeymap.view;

import L1iL.ILl;
import LILllili.L1l;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.chaozhuo.gameassistant.czkeymap.R$styleable;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ShortKeyView extends RelativeLayout implements View.OnClickListener, View.OnLongClickListener {

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public final int f7776IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final TextView f7777IiiiL;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public int f7778L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public L1l f7779LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public AnimatorSet f7780LLl1LlLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public String f7781ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final TextView f7782ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public boolean f7783lLL1L111l;
    public final int lLi1I;

    public ShortKeyView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final void Iii1lill1(int i) {
        this.f7783lLL1L111l = false;
        String strLlL = i == 0 ? "Null" : liIli.llL(i, 0);
        this.f7781ii111 = strLlL;
        this.f7778L11I = i;
        TextView textView = this.f7782ilI11;
        textView.setText(strLlL);
        textView.setWidth(liIli(this.f7781ii111));
        this.f7777IiiiL.setAlpha(1.0f);
    }

    public final boolean Ilil11ILI(KeyEvent keyEvent) {
        if (liIli.f33010ilI11) {
            liIli.Il("ShortKeyView", "onKeyEvent event: ", keyEvent, ", mIsInputMode: ", Boolean.valueOf(this.f7783lLL1L111l));
        }
        if (!this.f7783lLL1L111l) {
            return false;
        }
        if (keyEvent.getAction() == 0) {
            lILlii1L(keyEvent.getKeyCode());
            L1l l1l = this.f7779LIIl;
            if (l1l != null) {
                l1l.lILlii1L(this.f7778L11I);
            }
        }
        return true;
    }

    public int getKeycode() {
        return this.f7778L11I;
    }

    public TextView getTitleView() {
        return this.f7777IiiiL;
    }

    public final void lILlii1L(int i) {
        AnimatorSet animatorSet = this.f7780LLl1LlLL;
        if (animatorSet == null || !animatorSet.isRunning()) {
            this.f7783lLL1L111l = !this.f7783lLL1L111l;
            String strLlL = i == 0 ? "Null" : liIli.llL(i, 0);
            this.f7781ii111 = strLlL;
            this.f7778L11I = i;
            boolean z = this.f7783lLL1L111l;
            TextView textView = this.f7782ilI11;
            if (z) {
                textView.setText(R$string.short_key_fire_mode_input);
            } else {
                textView.setText(strLlL);
            }
            int iLiIli = liIli(textView.getText().toString());
            int width = getWidth();
            float f = 1.0f;
            float f2 = 0.0f;
            if (!this.f7783lLL1L111l) {
                width = iLiIli;
                iLiIli = width;
                f2 = 1.0f;
                f = 0.0f;
            }
            AnimatorSet animatorSet2 = new AnimatorSet();
            animatorSet2.playTogether(ObjectAnimator.ofInt(textView, "width", iLiIli, width), ObjectAnimator.ofFloat(this.f7777IiiiL, "alpha", f, f2));
            animatorSet2.setDuration(356L);
            animatorSet2.addListener(new ILl(this, 1));
            animatorSet2.start();
            this.f7780LLl1LlLL = animatorSet2;
        }
    }

    public final int liIli(String str) {
        TextView textView = this.f7782ilI11;
        return Math.min(Math.max(textView.getPaddingRight() + textView.getPaddingLeft() + ((int) textView.getPaint().measureText(str)), this.lLi1I), this.f7776IL1LiliI);
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        lILlii1L(this.f7778L11I);
    }

    @Override // android.view.View.OnLongClickListener
    public final boolean onLongClick(View view) {
        AnimatorSet animatorSet = this.f7780LLl1LlLL;
        if ((animatorSet != null && animatorSet.isRunning()) || !this.f7783lLL1L111l) {
            return false;
        }
        lILlii1L(0);
        L1l l1l = this.f7779LIIl;
        if (l1l == null) {
            return true;
        }
        l1l.lILlii1L(this.f7778L11I);
        return true;
    }

    public void setOnShortKeyChangeListener(L1l l1l) {
        this.f7779LIIl = l1l;
    }

    public ShortKeyView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7783lLL1L111l = false;
        this.f7778L11I = 0;
        LayoutInflater.from(context).inflate(R$layout.short_key_fire_view, this);
        TextView textView = (TextView) findViewById(R$id.short_key);
        this.f7782ilI11 = textView;
        textView.setOnClickListener(this);
        textView.setOnLongClickListener(this);
        TextView textView2 = (TextView) findViewById(R$id.short_title);
        this.f7777IiiiL = textView2;
        this.lLi1I = liIli.LI1Il(context, 48.0f);
        this.f7776IL1LiliI = liIli.LI1Il(context, 88.0f);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ShortKeyView);
            textView2.setText(typedArrayObtainStyledAttributes.getString(R$styleable.ShortKeyView_short_title));
            int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.ShortKeyView_short_title_size, 0);
            if (dimensionPixelSize > 0) {
                textView2.setTextSize(0, dimensionPixelSize);
            }
            int color = typedArrayObtainStyledAttributes.getColor(R$styleable.ShortKeyView_short_title_color, -1);
            if (color != -1) {
                textView2.setTextColor(color);
            }
            textView2.setTypeface(typedArrayObtainStyledAttributes.getBoolean(R$styleable.ShortKeyView_short_title_style_bold, true) ? Typeface.DEFAULT_BOLD : Typeface.defaultFromStyle(0));
            typedArrayObtainStyledAttributes.recycle();
        }
    }
}
