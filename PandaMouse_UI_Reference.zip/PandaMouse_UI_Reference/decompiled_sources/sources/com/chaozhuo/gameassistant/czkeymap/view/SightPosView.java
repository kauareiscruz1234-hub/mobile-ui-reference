package com.chaozhuo.gameassistant.czkeymap.view;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SightPosView extends BaseStretchView {
    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseStretchView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Iii1lill1() {
        super.Iii1lill1();
        this.f7647lIllIIiI.setVisibility(8);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseStretchView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void lILlii1L() {
        super.lILlii1L();
        this.f7647lIllIIiI.setVisibility(0);
    }

    public void setGyroMode(boolean z) {
        throw null;
    }
}
