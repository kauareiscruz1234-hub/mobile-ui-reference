package com.chaozhuo.gameassistant.czkeymap.view;

import ILIl.Il1iLli;
import LILllili.IIiIII1L;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.iI1;
import com.airbnb.lottie.iL;
import com.chaozhuo.gameassistant.convert.bean.PathInfo;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import java.util.HashMap;
import java.util.List;
import p020Ili.ilI1;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SwipeDrawLayout extends RelativeLayout implements IIiIII1L {

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final SwipeDrawView f7784IiiiL;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final LottieAnimationView f7785ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public iLLLiIl1 f7786lLL1L111l;

    public SwipeDrawLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public final void liIli(boolean z) {
        SwipeDrawView swipeDrawView = this.f7784IiiiL;
        if (z) {
            setVisibility(0);
            LottieAnimationView lottieAnimationView = this.f7785ilI11;
            lottieAnimationView.setVisibility(0);
            lottieAnimationView.lLi1I.lILlii1L();
            lottieAnimationView.lILlii1L();
            swipeDrawView.setEnabled(true);
            swipeDrawView.setEditState(true);
            return;
        }
        swipeDrawView.setEnabled(false);
        List<PathInfo> paths = swipeDrawView.getPaths();
        swipeDrawView.f7795ilI11.clear();
        swipeDrawView.invalidate();
        setVisibility(8);
        if (paths.size() >= 5) {
            BaseView baseViewIlil11ILI = ((li1) this.f7786lLL1L111l).Ilil11ILI(33, (int) paths.get(0).offsetX, (int) paths.get(0).offsetY, false);
            if (baseViewIlil11ILI != null) {
                baseViewIlil11ILI.setPath(paths);
            }
        }
    }

    public void setController(iLLLiIl1 illliil1) {
        this.f7786lLL1L111l = illliil1;
    }

    public SwipeDrawLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        LayoutInflater.from(context).inflate(R$layout.swipe_draw_layout, this);
        this.f7785ilI11 = (LottieAnimationView) findViewById(R$id.swipe_animation);
        SwipeDrawView swipeDrawView = (SwipeDrawView) findViewById(R$id.swipe_draw_view);
        this.f7784IiiiL = swipeDrawView;
        swipeDrawView.setOnDrawViewStateCallback(this);
        Context context2 = getContext();
        int i2 = 2;
        iL iLVar = new iL(new ilI1(this, 9), i2);
        HashMap map = iI1.f7334liIli;
        iI1.liIli("swipe.json", new Il1iLli(i2, context2.getApplicationContext(), "swipe.json")).Iii1lill1(iLVar);
    }
}
