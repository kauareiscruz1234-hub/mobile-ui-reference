package com.chaozhuo.gameassistant.czkeymap.view;

import LILllili.IIiIII1L;
import android.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.airbnb.lottie.Il1iLli;
import com.airbnb.lottie.LottieAnimationView;
import com.chaozhuo.gameassistant.convert.bean.PathInfo;
import com.chaozhuo.gameassistant.czkeymap.R$color;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.iLLLiIl1;
import com.chaozhuo.gameassistant.czkeymap.li1;
import java.util.ArrayList;
import java.util.List;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SwipeDrawView extends View {
    public final int II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public float f7787II1;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public Bitmap f7788IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final Paint f7789IiiiL;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public IIiIII1L f7790L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public boolean f7791LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public long f7792LLl1LlLL;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public float f7793Li;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public Bitmap f7794ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final ArrayList f7795ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final int f7796lLL1L111l;
    public boolean lLi1I;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public Bitmap f7797lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public final int f7798lii1;

    public SwipeDrawView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private Bitmap getStateBitmap() {
        if (this.f7791LIIl) {
            Bitmap bitmap = this.f7794ii111;
            if (bitmap == null || bitmap.isRecycled()) {
                this.f7794ii111 = BitmapFactory.decodeResource(getContext().getResources(), R$drawable.img_key_arrow_hover);
            }
            return this.f7794ii111;
        }
        Bitmap bitmap2 = this.f7788IL1LiliI;
        if (bitmap2 == null || bitmap2.isRecycled()) {
            this.f7788IL1LiliI = BitmapFactory.decodeResource(getContext().getResources(), R$drawable.img_key_arrow_normal);
        }
        return this.f7788IL1LiliI;
    }

    public List<PathInfo> getPaths() {
        return new ArrayList(this.f7795ilI11);
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        char c;
        Paint paint = this.f7789IiiiL;
        paint.setFlags(1);
        paint.setColor(this.f7791LIIl ? this.II : this.f7798lii1);
        paint.setStrokeWidth(this.f7796lLL1L111l);
        paint.setStyle(Paint.Style.STROKE);
        ArrayList arrayList = this.f7795ilI11;
        if (arrayList.size() <= 0) {
            return;
        }
        Bitmap bitmap = this.f7797lLiLIli;
        if (bitmap != null) {
            bitmap.recycle();
            this.f7797lLiLIli = null;
        }
        if (this.lLi1I && !this.f7791LIIl && arrayList.size() > 1) {
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add((PathInfo) arrayList.get(0));
            PathInfo pathInfo = new PathInfo();
            for (int i = 1; i < arrayList.size(); i++) {
                pathInfo.offsetX += ((PathInfo) arrayList.get(i)).offsetX;
                pathInfo.offsetY += ((PathInfo) arrayList.get(i)).offsetY;
                pathInfo.delay += ((PathInfo) arrayList.get(i)).delay;
            }
            arrayList2.add(pathInfo);
            arrayList = arrayList2;
        }
        float f = ((PathInfo) arrayList.get(0)).offsetX;
        float f2 = ((PathInfo) arrayList.get(0)).offsetY;
        for (int i2 = 1; i2 < arrayList.size(); i2++) {
            PathInfo pathInfo2 = (PathInfo) arrayList.get(i2);
            Path path = new Path();
            path.moveTo(f, f2);
            path.quadTo(f, f2, pathInfo2.offsetX + f, pathInfo2.offsetY + f2);
            canvas.drawPath(path, paint);
            f += pathInfo2.offsetX;
            f2 += pathInfo2.offsetY;
        }
        if (arrayList.size() < 2) {
            return;
        }
        float f3 = 0.0f;
        float f4 = 0.0f;
        for (int size = arrayList.size() - Math.min(arrayList.size() - 1, 5); size < arrayList.size(); size++) {
            f4 += ((PathInfo) arrayList.get(size)).offsetX;
            f3 += ((PathInfo) arrayList.get(size)).offsetY;
        }
        float degrees = (float) Math.toDegrees(Math.atan2(f3, f4));
        if (liIli.f33010ilI11) {
            c = 0;
            liIli.Il("SwipeDrawView", "calcArrowDegree offsetX=", Float.valueOf(f4), ", offsetY=", Float.valueOf(f3), ", degrees=", Float.valueOf(degrees));
        } else {
            c = 0;
        }
        Bitmap stateBitmap = getStateBitmap();
        float width = f - (stateBitmap.getWidth() / 2);
        float height = f2 - (stateBitmap.getHeight() / 2);
        if (liIli.f33010ilI11) {
            Integer numValueOf = Integer.valueOf(stateBitmap.getWidth());
            Integer numValueOf2 = Integer.valueOf(stateBitmap.getHeight());
            Float fValueOf = Float.valueOf(degrees);
            Object[] objArr = new Object[6];
            objArr[c] = " Width:";
            objArr[1] = numValueOf;
            objArr[2] = " Height:";
            objArr[3] = numValueOf2;
            objArr[4] = " angle:";
            objArr[5] = fValueOf;
            liIli.Il("SwipeDrawView", objArr);
        }
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(stateBitmap, 0, 0, stateBitmap.getWidth(), stateBitmap.getHeight(), matrix, true);
        this.f7797lLiLIli = bitmapCreateBitmap;
        canvas.drawBitmap(bitmapCreateBitmap, width, height, new Paint(1));
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0061  */
    /* JADX WARN: Code duplicated, block: B:16:0x0065  */
    /* JADX WARN: Code duplicated, block: B:18:0x0071  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        IIiIII1L iIiIII1L;
        IIiIII1L iIiIII1L2;
        iLLLiIl1 illliil1;
        int action = motionEvent.getAction();
        ArrayList arrayList = this.f7795ilI11;
        if (action == 0) {
            this.f7792LLl1LlLL = SystemClock.uptimeMillis();
            arrayList.clear();
            this.f7787II1 = motionEvent.getX(0);
            this.f7793Li = motionEvent.getY(0);
            arrayList.add(new PathInfo(this.f7787II1, this.f7793Li, 0L));
            invalidate();
            IIiIII1L iIiIII1L3 = this.f7790L11I;
            if (iIiIII1L3 != null) {
                LottieAnimationView lottieAnimationView = ((SwipeDrawLayout) iIiIII1L3).f7785ilI11;
                Il1iLli il1iLli = lottieAnimationView.lLi1I;
                il1iLli.f7293LIIl.clear();
                il1iLli.f7297lLL1L111l.cancel();
                lottieAnimationView.lILlii1L();
                lottieAnimationView.setVisibility(8);
            }
        } else if (action == 1) {
            iIiIII1L2 = this.f7790L11I;
            if (iIiIII1L2 != null) {
                motionEvent.getX(0);
                motionEvent.getY(0);
                illliil1 = ((SwipeDrawLayout) iIiIII1L2).f7786lLL1L111l;
                if (illliil1 != null) {
                    ((li1) illliil1).il1(32768);
                }
            }
        } else if (action == 2) {
            long jUptimeMillis = SystemClock.uptimeMillis() - this.f7792LLl1LlLL;
            if (liIli.f33010ilI11) {
                liIli.Il("SwipeDrawView", "onEvent delay:", Long.valueOf(jUptimeMillis));
            }
            this.f7792LLl1LlLL = SystemClock.uptimeMillis();
            PathInfo pathInfo = new PathInfo(motionEvent.getX(0) - this.f7787II1, motionEvent.getY(0) - this.f7793Li, jUptimeMillis);
            this.f7787II1 = motionEvent.getX(0);
            this.f7793Li = motionEvent.getY(0);
            arrayList.add(pathInfo);
            invalidate();
        } else if (action == 3) {
            iIiIII1L2 = this.f7790L11I;
            if (iIiIII1L2 != null) {
                motionEvent.getX(0);
                motionEvent.getY(0);
                illliil1 = ((SwipeDrawLayout) iIiIII1L2).f7786lLL1L111l;
                if (illliil1 != null) {
                    ((li1) illliil1).il1(32768);
                }
            }
        }
        int i = (action & 65280) >> 8;
        if ((motionEvent.getAction() & 255) == 6 && i == 0 && (iIiIII1L = this.f7790L11I) != null) {
            motionEvent.getX(0);
            motionEvent.getY(0);
            iLLLiIl1 illliil2 = ((SwipeDrawLayout) iIiIII1L).f7786lLL1L111l;
            if (illliil2 != null) {
                ((li1) illliil2).il1(32768);
            }
        }
        return true;
    }

    public void setEditState(boolean z) {
        if (this.f7791LIIl == z) {
            return;
        }
        this.f7791LIIl = z;
        invalidate();
    }

    public void setHoldMode(boolean z) {
        if (this.lLi1I == z) {
            return;
        }
        this.lLi1I = z;
        invalidate();
    }

    public void setOnDrawViewStateCallback(IIiIII1L iIiIII1L) {
        this.f7790L11I = iIiIII1L;
    }

    public SwipeDrawView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7795ilI11 = new ArrayList();
        this.f7792LLl1LlLL = 0L;
        this.f7791LIIl = false;
        this.lLi1I = false;
        this.f7788IL1LiliI = null;
        this.f7794ii111 = null;
        this.f7789IiiiL = new Paint(1);
        this.f7796lLL1L111l = liIli.LI1Il(context, 1.0f);
        this.II = context.getColor(R$color.color_accent);
        this.f7798lii1 = context.getColor(R.color.white);
    }
}
