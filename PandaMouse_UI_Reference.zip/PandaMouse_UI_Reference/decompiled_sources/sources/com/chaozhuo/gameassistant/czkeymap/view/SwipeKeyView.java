package com.chaozhuo.gameassistant.czkeymap.view;

import com.chaozhuo.gameassistant.czkeymap.li1;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SwipeKeyView extends KeyView {
    @Override // com.chaozhuo.gameassistant.czkeymap.view.KeyView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void IiI1l() {
        super.IiI1l();
        ((li1) this.f7662lii1).lLliL(this, this.f7648II1);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Iii() {
        ((li1) this.f7662lii1).lLliL(this, this.f7648II1);
    }

    @Override // android.view.View
    public void setAlpha(float f) {
        super.setAlpha(f);
        ((li1) this.f7662lii1).lLliL(this, this.f7648II1);
    }
}
