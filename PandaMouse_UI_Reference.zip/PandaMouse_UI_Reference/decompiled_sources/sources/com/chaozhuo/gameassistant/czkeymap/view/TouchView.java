package com.chaozhuo.gameassistant.czkeymap.view;

import LILllili.L1ii1iL1;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.chaozhuo.gameassistant.inject.input.ILl;
import java.util.ArrayList;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class TouchView extends View {

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final ArrayList f7799IiiiL;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final Paint f7800ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public final int f7801lLL1L111l;

    public TouchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private int getRandomColor() {
        return new int[]{-65536, -16711936, -16776961, ILl.f8215iiIiilI, -16711681, -65281}[(int) (Math.random() * ((double) 6))];
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0044  */
    /* JADX WARN: Code duplicated, block: B:24:0x0052  */
    /* JADX WARN: Code duplicated, block: B:27:0x0060 A[LOOP:2: B:22:0x004c->B:27:0x0060, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:28:0x0063  */
    /* JADX WARN: Code duplicated, block: B:30:0x0066  */
    /* JADX WARN: Code duplicated, block: B:32:0x007d  */
    /* JADX WARN: Code duplicated, block: B:37:0x008d  */
    /* JADX WARN: Code duplicated, block: B:47:0x005c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:50:0x009d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:52:0x008a A[SYNTHETIC] */
    public final void liIli(MotionEvent motionEvent) {
        int i;
        float x;
        float y;
        int pointerId;
        int randomColor;
        int size;
        int i2;
        L1ii1iL1 l1ii1iL1;
        int pointerId2;
        int actionMasked = motionEvent.getActionMasked();
        int pointerCount = motionEvent.getPointerCount();
        ArrayList arrayList = this.f7799IiiiL;
        if (actionMasked == 0) {
            for (i = 0; i < pointerCount; i++) {
                x = motionEvent.getX(i);
                y = motionEvent.getY(i);
                pointerId = motionEvent.getPointerId(i);
                randomColor = getRandomColor();
                size = arrayList.size();
                i2 = 0;
                do {
                    if (i2 < size) {
                        l1ii1iL1 = null;
                        break;
                    } else {
                        Object obj = arrayList.get(i2);
                        i2++;
                        l1ii1iL1 = (L1ii1iL1) obj;
                    }
                } while (l1ii1iL1.f2802Ilil11ILI != pointerId);
                if (l1ii1iL1 == null) {
                    L1ii1iL1 l1ii1iL2 = new L1ii1iL1();
                    l1ii1iL2.f2804liIli = x;
                    l1ii1iL2.f2801Iii1lill1 = y;
                    l1ii1iL2.f2802Ilil11ILI = pointerId;
                    l1ii1iL2.f2803lILlii1L = randomColor;
                    arrayList.add(l1ii1iL2);
                }
            }
        } else if (actionMasked == 1) {
            pointerId2 = motionEvent.getPointerId(motionEvent.getActionIndex());
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                if (((L1ii1iL1) arrayList.get(i3)).f2802Ilil11ILI == pointerId2) {
                    arrayList.remove(i3);
                    break;
                }
            }
        } else if (actionMasked == 2) {
            for (int i4 = 0; i4 < pointerCount; i4++) {
                float x2 = motionEvent.getX(i4);
                float y2 = motionEvent.getY(i4);
                int pointerId3 = motionEvent.getPointerId(i4);
                int size2 = arrayList.size();
                int i5 = 0;
                while (i5 < size2) {
                    Object obj2 = arrayList.get(i5);
                    i5++;
                    L1ii1iL1 l1ii1iL3 = (L1ii1iL1) obj2;
                    if (l1ii1iL3.f2802Ilil11ILI == pointerId3) {
                        l1ii1iL3.f2804liIli = x2;
                        l1ii1iL3.f2801Iii1lill1 = y2;
                        break;
                    }
                }
            }
        } else if (actionMasked == 5) {
            while (i < pointerCount) {
                x = motionEvent.getX(i);
                y = motionEvent.getY(i);
                pointerId = motionEvent.getPointerId(i);
                randomColor = getRandomColor();
                size = arrayList.size();
                i2 = 0;
                do {
                    if (i2 < size) {
                        l1ii1iL1 = null;
                        break;
                    } else {
                        Object obj3 = arrayList.get(i2);
                        i2++;
                        l1ii1iL1 = (L1ii1iL1) obj3;
                    }
                } while (l1ii1iL1.f2802Ilil11ILI != pointerId);
                if (l1ii1iL1 == null) {
                    L1ii1iL1 l1ii1iL4 = new L1ii1iL1();
                    l1ii1iL4.f2804liIli = x;
                    l1ii1iL4.f2801Iii1lill1 = y;
                    l1ii1iL4.f2802Ilil11ILI = pointerId;
                    l1ii1iL4.f2803lILlii1L = randomColor;
                    arrayList.add(l1ii1iL4);
                }
            }
        } else if (actionMasked == 6) {
            pointerId2 = motionEvent.getPointerId(motionEvent.getActionIndex());
            while (i3 < arrayList.size()) {
                if (((L1ii1iL1) arrayList.get(i3)).f2802Ilil11ILI == pointerId2) {
                    arrayList.remove(i3);
                    break;
                }
            }
        }
        invalidate();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f7799IiiiL;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            L1ii1iL1 l1ii1iL1 = (L1ii1iL1) obj;
            int i2 = l1ii1iL1.f2803lILlii1L;
            Paint paint = this.f7800ilI11;
            paint.setColor(i2);
            canvas.drawCircle(l1ii1iL1.f2804liIli, l1ii1iL1.f2801Iii1lill1, this.f7801lLL1L111l, paint);
        }
    }

    public TouchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7800ilI11 = new Paint();
        this.f7799IiiiL = new ArrayList();
        this.f7801lLL1L111l = liIli.LI1Il(context, 12.0f);
    }
}
