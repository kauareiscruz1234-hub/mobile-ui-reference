package com.chaozhuo.gameassistant.czkeymap.view;

import L11L.iL;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.R$color;
import com.chaozhuo.gameassistant.czkeymap.R$drawable;
import com.chaozhuo.gameassistant.czkeymap.R$id;
import com.chaozhuo.gameassistant.czkeymap.R$layout;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyInfo;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyPosInfo;
import com.chaozhuo.gameassistant.czkeymap.li1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lL1IIi.Iii1lill1;
import liIli.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ZoomKeyView extends BaseStretchView implements View.OnClickListener {
    public static final /* synthetic */ int iiIL1liI = 0;
    public final HashMap IIlII;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public int f7802LLIi;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public final HashMap f7803ill;

    public ZoomKeyView(Context context) {
        super(context);
        HashMap map = new HashMap(2);
        this.f7803ill = map;
        HashMap map2 = new HashMap(2);
        this.IIlII = map2;
        this.f7802LLIi = -1;
        String string = UUID.randomUUID().toString();
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.type = 36;
        keyInfo.specialClass = string;
        keyInfo.keyPosList.add(new KeyPosInfo());
        map.put(36, keyInfo);
        KeyInfo keyInfo2 = new KeyInfo();
        keyInfo2.type = 37;
        keyInfo2.specialClass = string;
        keyInfo2.keyPosList.add(new KeyPosInfo());
        map.put(37, keyInfo2);
        this.f7656i1LIiLLl.type = 36;
        this.f7646lIL.setBackgroundResource(R$drawable.zoom_bg);
        LayoutInflater.from(context).inflate(R$layout.zoom_view, this.f7646lIL);
        TextView textView = (TextView) findViewById(R$id.zoom_in);
        TextView textView2 = (TextView) findViewById(R$id.zoom_out);
        textView.setOnClickListener(this);
        textView2.setOnClickListener(this);
        map2.put(36, textView);
        map2.put(37, textView2);
        this.f7647lIllIIiI.setVisibility(0);
        this.f7647lIllIIiI.setOnClickListener(new iL(this, 5));
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void ILl() {
        DisplayMetrics displayMetricsIl1iLli = liIli.Il1iLli(this.f7659ilI11);
        for (KeyInfo keyInfo : this.f7803ill.values()) {
            keyInfo.keyPosList.clear();
            KeyPosInfo keyPosInfo = new KeyPosInfo();
            keyInfo.keyPosList.add(keyPosInfo);
            keyPosInfo.x = (getWidth() / 2.0f) + getX();
            float height = (getHeight() / 2.0f) + getY();
            keyPosInfo.x /= displayMetricsIl1iLli.widthPixels;
            keyPosInfo.y = height / displayMetricsIl1iLli.heightPixels;
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void IiI1l() {
        for (Map.Entry entry : this.f7803ill.entrySet()) {
            Integer num = (Integer) entry.getKey();
            int iIntValue = num.intValue();
            KeyInfo keyInfo = (KeyInfo) entry.getValue();
            TextView textView = (TextView) this.IIlII.get(num);
            boolean zIsEmpty = TextUtils.isEmpty(keyInfo.keyName);
            textView.setText((iIntValue == this.f7802LLIi || !zIsEmpty) ? keyInfo.keyName : "???");
            int i = (iIntValue == this.f7802LLIi || !zIsEmpty) ? R.color.white : R$color.color_error;
            Context context = this.f7659ilI11;
            textView.setTextColor(context.getColor(i));
            ((View) textView.getParent()).setForegroundTintList(ColorStateList.valueOf(context.getColor(iIntValue == this.f7802LLIi ? R$color.color_accent : R$color.color_white)));
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseStretchView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Iii1lill1() {
        super.Iii1lill1();
        this.f7647lIllIIiI.setVisibility(8);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void Ilil11ILI() {
        setFocusedId(-1);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void LI1Il(int i, int i2, String str) {
        HashMap map = this.f7803ill;
        for (Integer num : map.keySet()) {
            if (this.f7802LLIi == num.intValue()) {
                ((TextView) this.IIlII.get(num)).setText(str);
                KeyInfo keyInfo = (KeyInfo) map.get(num);
                keyInfo.modifier = i2;
                keyInfo.keyCode = i;
                break;
            }
        }
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public KeyInfo getKeyInfo() {
        return (KeyInfo) this.f7803ill.get(Integer.valueOf(this.f7802LLIi));
    }

    public List<KeyInfo> getKeyInfoList() {
        ArrayList arrayList = new ArrayList(2);
        arrayList.addAll(this.f7803ill.values());
        return arrayList;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public float getRadiusRatio() {
        for (KeyInfo keyInfo : this.f7803ill.values()) {
            if (keyInfo != null) {
                return keyInfo.radiusRatio;
            }
        }
        return 0.0f;
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public int getTotalTime() {
        for (KeyInfo keyInfo : this.f7803ill.values()) {
            if (keyInfo != null) {
                return keyInfo.totalTime;
            }
        }
        return 0;
    }

    public final void iilli(KeyInfo keyInfo, String str, int i, int i2) {
        HashMap map = this.f7803ill;
        for (Integer num : map.keySet()) {
            num.getClass();
            if (((KeyInfo) map.get(num)) == keyInfo) {
                ((TextView) this.IIlII.get(num)).setText(str);
                keyInfo.keyName = str;
                keyInfo.keyCode = i;
                keyInfo.modifier = i2;
                break;
            }
        }
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void il1(String str) {
        for (Integer num : this.f7803ill.keySet()) {
            num.getClass();
            TextView textView = (TextView) this.IIlII.get(num);
            if (TextUtils.equals(textView.getText(), str)) {
                Iii1lill1.lI(textView);
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseStretchView, com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void lILlii1L() {
        super.lILlii1L();
        this.f7647lIllIIiI.setVisibility(0);
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public final void liIli() {
        ((li1) this.f7662lii1).f7598ILl.setFocusView(this);
        IiI1l();
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        bringToFront();
        HashMap map = this.IIlII;
        for (Integer num : map.keySet()) {
            int iIntValue = num.intValue();
            if (map.get(num) == view) {
                setFocusedId(iIntValue);
                break;
            }
        }
        liIli();
    }

    public void setFocusedId(int i) {
        this.f7802LLIi = i;
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setKeyInfo(KeyInfo keyInfo) {
        int i = keyInfo.type;
        ((TextView) this.IIlII.get(Integer.valueOf(i))).setText(keyInfo.keyName);
        this.f7803ill.put(Integer.valueOf(i), keyInfo);
        if (TextUtils.isEmpty(getSpecialClass())) {
            setSpecialClass(keyInfo.specialClass);
        }
        IiI1l();
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setRadiusRatio(float f) {
        for (KeyInfo keyInfo : this.f7803ill.values()) {
            if (keyInfo != null) {
                keyInfo.radiusRatio = f;
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.czkeymap.view.BaseView
    public void setTotalTime(int i) {
        for (KeyInfo keyInfo : this.f7803ill.values()) {
            if (keyInfo != null) {
                keyInfo.totalTime = i;
            }
        }
    }
}
