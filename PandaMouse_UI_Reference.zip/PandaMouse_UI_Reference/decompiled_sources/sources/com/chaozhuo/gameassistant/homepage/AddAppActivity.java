package com.chaozhuo.gameassistant.homepage;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.IlLi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.XApp;
import com.chaozhuo.gameassistant.homepage.adapter.ListAppAdapter;
import com.github.ybq.android.spinkit.SpinKitView;
import com.panda.mouse.R;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class AddAppActivity extends BaseActivity {

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public static final /* synthetic */ int f7828LLi = 0;
    public EditText II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public RecyclerView f7829II1;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public SpinKitView f7830IlLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public ListAppAdapter f7831Li;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public ImageView f7835lii1;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public final ArrayList f7834lLiLIli = new ArrayList();

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public final ArrayList f7833iLLL = new ArrayList();

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public final Il1ii.iLLLiIl1 f7832i1LIiLLl = new Il1ii.iLLLiIl1(3);
    public androidx.appcompat.app.Iii I1Ii1IilI = null;

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_add_app);
        final int i = 0;
        ((ImageView) findViewById(R.id.image_back)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.IiI1l

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ AddAppActivity f7901IiiiL;

            {
                this.f7901IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                AddAppActivity addAppActivity = this.f7901IiiiL;
                switch (i2) {
                    case 0:
                        int i3 = AddAppActivity.f7828LLi;
                        addAppActivity.finish();
                        break;
                    case 1:
                        int i4 = AddAppActivity.f7828LLi;
                        addAppActivity.finish();
                        break;
                    default:
                        addAppActivity.II.setText("");
                        break;
                }
            }
        });
        final int i2 = 1;
        ((TextView) findViewById(R.id.text_title)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.IiI1l

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ AddAppActivity f7901IiiiL;

            {
                this.f7901IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                AddAppActivity addAppActivity = this.f7901IiiiL;
                switch (i3) {
                    case 0:
                        int i4 = AddAppActivity.f7828LLi;
                        addAppActivity.finish();
                        break;
                    case 1:
                        int i5 = AddAppActivity.f7828LLi;
                        addAppActivity.finish();
                        break;
                    default:
                        addAppActivity.II.setText("");
                        break;
                }
            }
        });
        EditText editText = (EditText) findViewById(R.id.id_edittext);
        this.II = editText;
        editText.setHint(R.string.add_app_list_tip_pmp);
        this.f7835lii1 = (ImageView) findViewById(R.id.id_clear);
        this.f7829II1 = (RecyclerView) findViewById(R.id.recycler_view);
        this.f7831Li = new ListAppAdapter(this.f7834lLiLIli);
        this.f7829II1.setLayoutManager(new LinearLayoutManager());
        this.f7829II1.setAdapter(this.f7831Li);
        this.f7831Li.setOnItemChildClickListener(new iilli(this, 0));
        final int i3 = 2;
        this.f7835lii1.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.IiI1l

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ AddAppActivity f7901IiiiL;

            {
                this.f7901IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                AddAppActivity addAppActivity = this.f7901IiiiL;
                switch (i4) {
                    case 0:
                        int i5 = AddAppActivity.f7828LLi;
                        addAppActivity.finish();
                        break;
                    case 1:
                        int i6 = AddAppActivity.f7828LLi;
                        addAppActivity.finish();
                        break;
                    default:
                        addAppActivity.II.setText("");
                        break;
                }
            }
        });
        this.II.addTextChangedListener(new IlLi(this, 1));
        this.f7830IlLi = (SpinKitView) findViewById(R.id.id_spin_kit);
        BaseActivity.Il1iLli(findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_root_layout));
        try {
            if (XApp.f7417IiiiL.getPackageManager().getPermissionInfo("com.android.permission.GET_INSTALLED_APPS", 0) != null && iLLLiIl1.iIiI1.liIli(this, "com.android.permission.GET_INSTALLED_APPS") != 0) {
                iLLLiIl1.iIiI1.iI1(this, new String[]{"com.android.permission.GET_INSTALLED_APPS"}, 10);
                return;
            }
        } catch (Exception unused) {
        }
        new L1i11iI(this, 0).execute(new Void[0]);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 10) {
            if ((iArr.length > 0 && iArr[0] == 0) || iLLLiIl1.iIiI1.liIli(this, "com.android.permission.GET_INSTALLED_APPS") == 0) {
                new L1i11iI(this, 0).execute(new Void[0]);
                return;
            }
            IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(this);
            androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
            ilil11ILI2.f3983lILlii1L = "Permission Request";
            ilil11ILI2.f3969Iii = "Get Installed Apps permission is required to add game to play.";
            ilil11ILI2.f3966ILLl = false;
            ilil11ILI.iilli(R.string.permission_grant, new Il1iLli(this, 0));
            androidx.appcompat.app.Iii iiiII1 = ilil11ILI.iI1();
            this.I1Ii1IilI = iiiII1;
            iiiII1.show();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        super.onResume();
        if (this.I1Ii1IilI != null) {
            if (iLLLiIl1.iIiI1.liIli(this, "com.android.permission.GET_INSTALLED_APPS") != 0) {
                this.I1Ii1IilI.show();
            } else {
                this.I1Ii1IilI = null;
                new L1i11iI(this, 0).execute(new Void[0]);
            }
        }
    }
}
