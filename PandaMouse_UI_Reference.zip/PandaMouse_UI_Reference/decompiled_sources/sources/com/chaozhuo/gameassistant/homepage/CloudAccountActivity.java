package com.chaozhuo.gameassistant.homepage;

import android.accounts.Account;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.ProductDetails;
import com.chaozhuo.gameassistant.BaseActivity;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthCredential;
import com.panda.mouse.R;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class CloudAccountActivity extends BaseActivity {

    /* JADX INFO: renamed from: i1li1l, reason: collision with root package name */
    public static final int[] f7836i1li1l = {R.string.pro_plus_benefit_unlock_macro, R.string.pro_plus_benefit_cloud_sync, R.string.pro_plus_benefit_support, R.string.pro_plus_benefit_more};
    public TextView I1Ii1IilI;
    public TextView II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public TextView f7837II1;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public iILliI1I1.ILl f7838IIiiI;
    public boolean IIlII;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public TextView f7839IlLi;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public boolean f7840LLIi;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public TextView f7841LLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public TextView f7842Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public TextView f7843i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public TextView f7844iLLL;
    public boolean iiIL1liI;
    public boolean iiL;
    public ProductDetails.SubscriptionOfferDetails iilL1Ll;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public ProductDetails f7845ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public ProductDetails.SubscriptionOfferDetails f7846ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public ProductDetails f7847lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public final int[] f7848lIllIIiI = {R.id.benefit_remove_ads, R.id.benefit_cloud_sync, R.id.benefit_button_label, R.id.benefit_support, R.id.benefit_more};

    /* JADX INFO: renamed from: lLLlLlL, reason: collision with root package name */
    public String f7849lLLlLlL;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public TextView f7850lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public TextView f7851lii1;

    public static ProductDetails.SubscriptionOfferDetails IL(CloudAccountActivity cloudAccountActivity, ProductDetails productDetails) {
        if (productDetails.getSubscriptionOfferDetails() == null) {
            return null;
        }
        for (ProductDetails.SubscriptionOfferDetails subscriptionOfferDetails : productDetails.getSubscriptionOfferDetails()) {
            if (subscriptionOfferDetails.getOfferId() == null && subscriptionOfferDetails.getPricingPhases() != null && !subscriptionOfferDetails.getPricingPhases().getPricingPhaseList().isEmpty()) {
                return subscriptionOfferDetails;
            }
        }
        return null;
    }

    public final void L1i11iI() {
        iILliI1I1.ILl iLl = this.f7838IIiiI;
        if (iLl != null) {
            iLl.ILl(BillingClient.ProductType.SUBS, Arrays.asList("product_id_cloud_sync_monthly", "product_id_cloud_sync_yearly"));
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0024  */
    public final void Ll1LIL1l() {
        boolean zLl11Ll;
        boolean z;
        boolean zII;
        int i;
        FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
        boolean z2 = false;
        boolean z3 = firebaseUser != null;
        com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
        boolean zIlil11ILI = i1lI111LL.Ilil11ILI();
        if (zIlil11ILI) {
            z = true;
        } else {
            try {
                zLl11Ll = i1lI111LL.Iii1lill1().Ll11Ll();
            } catch (Exception unused) {
                zLl11Ll = false;
            }
            if (zLl11Ll) {
                z = true;
            } else {
                z = false;
            }
        }
        this.f7841LLi.setText(zIlil11ILI ? R.string.pro_plus_status_active : R.string.pro_plus_status_inactive);
        try {
            zII = i1lI111LL.Iii1lill1().iI();
            while (true) {
                int[] iArr = this.f7848lIllIIiI;
                if (i >= iArr.length) {
                    break;
                }
                TextView textView = (TextView) findViewById(iArr[i]);
                if (i >= 4) {
                    textView.setVisibility(8);
                } else {
                    textView.setVisibility(0);
                    int[] iArr2 = f7836i1li1l;
                    boolean z4 = zIlil11ILI || (zII && iArr2[i] == R.string.pro_plus_benefit_unlock_macro);
                    StringBuilder sb = new StringBuilder();
                    sb.append(z4 ? "✓  " : "○  ");
                    sb.append(getString(iArr2[i]));
                    textView.setText(sb.toString());
                    textView.setTextColor(getColor(z4 ? R.color.text_primary : R.color.text_secondary));
                }
                i++;
            }
        } catch (Exception unused2) {
            zII = false;
        }
        i = 0;
        this.II.setText(z3 ? firebaseUser.getEmail() : getString(R.string.not_signed_in));
        if (!z3) {
            this.f7851lii1.setText(R.string.pro_plus_account_sign_in_description);
        } else if (zIlil11ILI) {
            this.f7851lii1.setText(R.string.cloud_subscription_active);
        } else {
            this.f7851lii1.setText(R.string.cloud_subscription_required);
        }
        this.f7837II1.setVisibility(z3 ? 8 : 0);
        this.f7843i1LIiLLl.setVisibility(z3 ? 0 : 8);
        this.f7842Li.setVisibility(zIlil11ILI ? 8 : 0);
        this.f7850lLiLIli.setVisibility(zIlil11ILI ? 8 : 0);
        this.f7844iLLL.setVisibility(zIlil11ILI ? 8 : 0);
        this.f7842Li.setEnabled((zIlil11ILI || this.iilL1Ll == null) ? false : true);
        TextView textView2 = this.f7850lLiLIli;
        if (!zIlil11ILI && this.f7846ill != null) {
            z2 = true;
        }
        textView2.setEnabled(z2);
        this.I1Ii1IilI.setText(this.iiL ? R.string.cloud_deleting_account : R.string.cloud_delete_account);
        this.I1Ii1IilI.setEnabled(true ^ this.iiL);
        if (this.IIlII && z3 && z) {
            setResult(-1);
            finish();
        }
    }

    public final void ii1(Exception exc, String str, boolean z) {
        this.iiL = false;
        if (liIli.liIli.f33010ilI11) {
            liIli.liIli.LI1lllLl("CloudAccountActivity", "Delete ", str, " failed: ", exc);
        }
        if (z && (exc instanceof FirebaseAuthRecentLoginRequiredException)) {
            this.iiIL1liI = true;
            Toast.makeText(this, R.string.cloud_delete_reauthenticate, 1).show();
            iILliI1I1.iL.f28422Ilil11ILI.getClass();
            iILliI1I1.iL.Ilil11ILI(this);
        } else {
            Toast.makeText(this, R.string.cloud_delete_failed, 1).show();
        }
        Ll1LIL1l();
    }

    public final void l1LLlI() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        new AlertDialog.Builder(this, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_confirm).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.delete_action, new Ll1LIL1l(this, 1)).show();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 10) {
            iILliI1I1.iL iLVar = iILliI1I1.iL.f28422Ilil11ILI;
            lIIl liil = new lIIl(this, 1);
            iLVar.getClass();
            TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
            taskCompletionSource.getTask().addOnCompleteListener(liil);
            if (intent == null) {
                taskCompletionSource.setException(new IllegalStateException("Google sign-in was cancelled"));
                return;
            }
            try {
                GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) iLIllLlI.Liii1.L1ii1iL1(intent).getResult(ApiException.class);
                if (googleSignInAccount != null && !TextUtils.isEmpty(googleSignInAccount.getIdToken())) {
                    iLVar.f28424liIli.ILl(new GoogleAuthCredential(googleSignInAccount.getIdToken(), null)).addOnSuccessListener(new iILliI1I1.Iii(taskCompletionSource)).addOnFailureListener(new iILliI1I1.Iii(taskCompletionSource));
                    return;
                }
                taskCompletionSource.setException(new IllegalStateException("Google account token is unavailable"));
            } catch (Exception e) {
                taskCompletionSource.setException(e);
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_cloud_account);
        final int i = 0;
        this.IIlII = getIntent().getBooleanExtra("cloud_action", false);
        findViewById(R.id.image_back).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                int i3 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i2) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i3)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        this.II = (TextView) findViewById(R.id.text_account_status);
        TextView textView = (TextView) findViewById(R.id.text_cloud_info);
        this.f7851lii1 = textView;
        final int i2 = 1;
        textView.post(new Ilil11ILI(this, i2));
        this.f7837II1 = (TextView) findViewById(R.id.button_sign_in);
        this.f7842Li = (TextView) findViewById(R.id.button_subscribe_monthly);
        this.f7850lLiLIli = (TextView) findViewById(R.id.button_subscribe_yearly);
        this.f7844iLLL = (TextView) findViewById(R.id.text_subscription_terms);
        this.f7843i1LIiLLl = (TextView) findViewById(R.id.button_sign_out);
        this.f7839IlLi = (TextView) findViewById(R.id.button_manage_subscription);
        this.I1Ii1IilI = (TextView) findViewById(R.id.button_delete_account);
        this.f7841LLi = (TextView) findViewById(R.id.text_pro_plus_status);
        TextView textView2 = this.I1Ii1IilI;
        textView2.setPaintFlags(textView2.getPaintFlags() | 8);
        this.f7837II1.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                int i4 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i3) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i4)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        final int i3 = 2;
        this.f7843i1LIiLLl.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                int i5 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i4) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i5)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        final int i4 = 3;
        this.I1Ii1IilI.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                int i6 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i5) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i6)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        final int i5 = 4;
        this.f7839IlLi.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i6 = i5;
                int i7 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i6) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i7)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        final int i6 = 5;
        this.f7842Li.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i7 = i6;
                int i8 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i7) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i8)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        final int i7 = 6;
        this.f7850lLiLIli.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.l1LLlI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ CloudAccountActivity f7987IiiiL;

            {
                this.f7987IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i8 = i7;
                int i9 = 0;
                CloudAccountActivity cloudAccountActivity = this.f7987IiiiL;
                switch (i8) {
                    case 0:
                        int[] iArr = CloudAccountActivity.f7836i1li1l;
                        cloudAccountActivity.finish();
                        break;
                    case 1:
                        int[] iArr2 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.getClass();
                        iILliI1I1.iL.Ilil11ILI(cloudAccountActivity);
                        break;
                    case 2:
                        int[] iArr3 = CloudAccountActivity.f7836i1li1l;
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        GoogleSignInOptions googleSignInOptions = GoogleSignInOptions.DEFAULT_SIGN_IN;
                        new HashSet();
                        new HashMap();
                        com.google.android.gms.common.internal.iLLLiIl1.il1(googleSignInOptions);
                        HashSet hashSet = new HashSet(googleSignInOptions.zad());
                        boolean zZag = googleSignInOptions.zag();
                        boolean zZah = googleSignInOptions.zah();
                        boolean zZaf = googleSignInOptions.zaf();
                        String strZai = googleSignInOptions.zai();
                        Account accountZae = googleSignInOptions.zae();
                        String strZaj = googleSignInOptions.zaj();
                        Map mapZam = GoogleSignInOptions.zam(googleSignInOptions.zak());
                        String strZal = googleSignInOptions.zal();
                        if (hashSet.contains(GoogleSignInOptions.zae)) {
                            Scope scope = GoogleSignInOptions.zad;
                            if (hashSet.contains(scope)) {
                                hashSet.remove(scope);
                            }
                        }
                        if (zZaf && (accountZae == null || !hashSet.isEmpty())) {
                            hashSet.add(GoogleSignInOptions.zac);
                        }
                        new com.google.android.gms.auth.api.signin.liIli(cloudAccountActivity, Lili1I.liIli.f3594liIli, new GoogleSignInOptions(3, new ArrayList(hashSet), accountZae, zZaf, zZag, zZah, strZai, strZaj, mapZam, strZal, null), new l1iILl1.Iii(18)).lILlii1L();
                        cloudAccountActivity.Ll1LIL1l();
                        break;
                    case 3:
                        int[] iArr4 = CloudAccountActivity.f7836i1li1l;
                        if (!cloudAccountActivity.isFinishing() && !cloudAccountActivity.isDestroyed()) {
                            FirebaseUser firebaseUser = iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.f25981Iii;
                            if (firebaseUser != null) {
                                cloudAccountActivity.f7849lLLlLlL = firebaseUser.getUid();
                                cloudAccountActivity.l1LLlI();
                            } else {
                                new AlertDialog.Builder(cloudAccountActivity, 2131951627).setTitle(R.string.cloud_delete_account).setMessage(R.string.cloud_delete_sign_in_required).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton(R.string.sign_in_with_google, new Ll1LIL1l(cloudAccountActivity, i9)).show();
                            }
                            break;
                        }
                        break;
                    case 4:
                        cloudAccountActivity.f7840LLIi = true;
                        Uri uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=" + cloudAccountActivity.getPackageName());
                        try {
                            cloudAccountActivity.startActivity(new Intent("android.intent.action.VIEW", uri).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException | SecurityException unused) {
                            try {
                                cloudAccountActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.VIEW", uri).addCategory("android.intent.category.BROWSABLE"), null));
                                return;
                            } catch (ActivityNotFoundException | SecurityException e) {
                                cloudAccountActivity.f7840LLIi = false;
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("CloudAccountActivity", "Unable to open subscription management: " + e);
                                    return;
                                }
                                return;
                            }
                        }
                        break;
                    case 5:
                        iILliI1I1.ILl iLl = cloudAccountActivity.f7838IIiiI;
                        if (iLl != null) {
                            iLl.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7847lIL, cloudAccountActivity.iilL1Ll);
                        }
                        break;
                    default:
                        iILliI1I1.ILl iLl2 = cloudAccountActivity.f7838IIiiI;
                        if (iLl2 != null) {
                            iLl2.lILlii1L(cloudAccountActivity, cloudAccountActivity.f7845ilL, cloudAccountActivity.f7846ill);
                        }
                        break;
                }
            }
        });
        this.f7838IIiiI = new iILliI1I1.ILl(new I1lI111LL(this));
        Ll1LIL1l();
        BaseActivity.Il1iLli(findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_root_layout));
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onDestroy() {
        iILliI1I1.ILl iLl = this.f7838IIiiI;
        if (iLl != null) {
            iLl.Iii1lill1();
            this.f7838IIiiI = null;
        }
        super.onDestroy();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        super.onResume();
        if (this.f7840LLIi) {
            this.f7840LLIi = false;
            L1i11iI();
        }
        Ll1LIL1l();
    }
}
