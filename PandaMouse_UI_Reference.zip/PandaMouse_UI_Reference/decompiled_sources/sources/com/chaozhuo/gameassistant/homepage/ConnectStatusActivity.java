package com.chaozhuo.gameassistant.homepage;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.view.InputDevice;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.homepage.widget.DotDeviceItemView;
import com.panda.mouse.R;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ConnectStatusActivity extends BaseActivity implements com.chaozhuo.gameassistant.czkeymap.iL {

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public static final /* synthetic */ int f7852lii1 = 0;
    public LinearLayout II;

    @Override // com.chaozhuo.gameassistant.czkeymap.iL
    public final void ILl() {
        this.II.removeAllViewsInLayout();
        ArrayList arrayList = com.chaozhuo.gameassistant.czkeymap.il1.liIli().f7571IiiiL;
        if (arrayList.isEmpty()) {
            DotDeviceItemView dotDeviceItemView = new DotDeviceItemView(this);
            dotDeviceItemView.setDevicesName(getString(R.string.connect_no_peripherals));
            dotDeviceItemView.setDeviceNameColor(getColor(R.color.text_primary));
            dotDeviceItemView.liIli(getColor(R.color.color_error));
            this.II.addView(dotDeviceItemView);
            return;
        }
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            DotDeviceItemView dotDeviceItemView2 = new DotDeviceItemView(this);
            dotDeviceItemView2.setDevicesName(((InputDevice) obj).getName());
            dotDeviceItemView2.setDeviceNameColor(getColor(R.color.text_primary));
            dotDeviceItemView2.liIli(getColor(R.color.color_accent));
            this.II.addView(dotDeviceItemView2);
        }
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_connect_status);
        final int i = 0;
        findViewById(R.id.image_back).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.ilI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ConnectStatusActivity f7981IiiiL;

            {
                this.f7981IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                ConnectStatusActivity connectStatusActivity = this.f7981IiiiL;
                switch (i2) {
                    case 0:
                        int i3 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.finish();
                        break;
                    case 1:
                        int i4 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.finish();
                        break;
                    default:
                        int i5 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.getClass();
                        Intent intent = new Intent();
                        intent.setAction("android.settings.BLUETOOTH_SETTINGS");
                        intent.setFlags(268435456);
                        try {
                            connectStatusActivity.startActivity(intent);
                        } catch (Exception unused) {
                            return;
                        }
                        break;
                }
            }
        });
        final int i2 = 1;
        findViewById(R.id.text_title).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.ilI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ConnectStatusActivity f7981IiiiL;

            {
                this.f7981IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                ConnectStatusActivity connectStatusActivity = this.f7981IiiiL;
                switch (i3) {
                    case 0:
                        int i4 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.finish();
                        break;
                    case 1:
                        int i5 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.finish();
                        break;
                    default:
                        int i6 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.getClass();
                        Intent intent = new Intent();
                        intent.setAction("android.settings.BLUETOOTH_SETTINGS");
                        intent.setFlags(268435456);
                        try {
                            connectStatusActivity.startActivity(intent);
                        } catch (Exception unused) {
                            return;
                        }
                        break;
                }
            }
        });
        final int i3 = 2;
        ((TextView) findViewById(R.id.text_bluetooth_setting)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.ilI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ConnectStatusActivity f7981IiiiL;

            {
                this.f7981IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                ConnectStatusActivity connectStatusActivity = this.f7981IiiiL;
                switch (i4) {
                    case 0:
                        int i5 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.finish();
                        break;
                    case 1:
                        int i6 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.finish();
                        break;
                    default:
                        int i7 = ConnectStatusActivity.f7852lii1;
                        connectStatusActivity.getClass();
                        Intent intent = new Intent();
                        intent.setAction("android.settings.BLUETOOTH_SETTINGS");
                        intent.setFlags(268435456);
                        try {
                            connectStatusActivity.startActivity(intent);
                        } catch (Exception unused) {
                            return;
                        }
                        break;
                }
            }
        });
        this.II = (LinearLayout) findViewById(R.id.dot_list_view);
        TextView textView = (TextView) findViewById(R.id.text_mapping_lab_tip);
        SpannableString spannableString = new SpannableString(textView.getText());
        int iIndexOf = spannableString.toString().indexOf("Panda Mapping Lab");
        if (iIndexOf >= 0) {
            spannableString.setSpan(new iLLLiIl1(this), iIndexOf, iIndexOf + 17, 33);
            textView.setText(spannableString);
            textView.setMovementMethod(LinkMovementMethod.getInstance());
        }
        com.chaozhuo.gameassistant.czkeymap.il1.liIli().f7572ilI11.add(this);
        ILl();
        BaseActivity.Il1iLli(findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_root_layout));
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        com.chaozhuo.gameassistant.czkeymap.il1.liIli().f7572ilI11.remove(this);
    }
}
