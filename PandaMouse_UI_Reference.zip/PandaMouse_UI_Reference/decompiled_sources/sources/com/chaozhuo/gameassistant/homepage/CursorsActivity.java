package com.chaozhuo.gameassistant.homepage;

import LILllili.l11l;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.core.view.l11lLIL;
import androidx.gridlayout.widget.GridLayout;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.czkeymap.bean.CursorInfo;
import com.chaozhuo.gameassistant.czkeymap.view.CustomSeekBarView;
import com.panda.mouse.R;
import java.io.File;
import java.io.InputStream;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class CursorsActivity extends BaseActivity {
    public static final /* synthetic */ int iiL = 0;
    public ImageView I1Ii1IilI;
    public int II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public CursorInfo f7853II1;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public ImageView f7854IIiiI;
    public float IIlII;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public ImageView f7855IlLi;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public float f7856LLIi;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public CustomSeekBarView f7857LLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public ImageView f7858Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public View f7859i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public View f7860iLLL;
    public boolean iiIL1liI = false;
    public float iilL1Ll;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public int f7861ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public float f7862ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public ImageView f7863lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public View f7864lIllIIiI;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public View f7865lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public GridLayout f7866lii1;

    public final Bitmap IL(Uri uri, int i) throws Throwable {
        InputStream inputStreamOpenInputStream;
        InputStream inputStream = null;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            options.inSampleSize = 1;
            InputStream inputStreamOpenInputStream2 = getContentResolver().openInputStream(uri);
            try {
                BitmapFactory.decodeStream(inputStreamOpenInputStream2, null, options);
                llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream2);
                options.inJustDecodeBounds = false;
                try {
                    int i2 = 1;
                    while (true) {
                        int i3 = i2 * 2;
                        if (Math.max(options.outWidth, options.outHeight) / i3 >= Math.max(1, i)) {
                            i2 = i3;
                        } else {
                            options.inSampleSize = i2;
                            inputStreamOpenInputStream = getContentResolver().openInputStream(uri);
                            try {
                                Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpenInputStream, null, options);
                                llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
                                return bitmapDecodeStream;
                            } catch (Exception e) {
                                e = e;
                                inputStreamOpenInputStream2 = null;
                            } catch (Throwable th) {
                                th = th;
                                llL1i.Iii1lill1.lILlii1L(inputStream);
                                llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
                                throw th;
                            }
                        }
                        inputStreamOpenInputStream = null;
                        inputStreamOpenInputStream2 = null;
                        try {
                            if (liIli.liIli.f33010ilI11) {
                                liIli.liIli.LI1lllLl("CursorsActivity", "decodeSampledBitmap: error=", e);
                            }
                            llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream2);
                            llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
                            return null;
                        } catch (Throwable th2) {
                            th = th2;
                            inputStream = inputStreamOpenInputStream2;
                            llL1i.Iii1lill1.lILlii1L(inputStream);
                            llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
                            throw th;
                        }
                    }
                } catch (Exception e2) {
                    e = e2;
                    inputStreamOpenInputStream = null;
                    inputStreamOpenInputStream2 = null;
                } catch (Throwable th3) {
                    th = th3;
                    inputStreamOpenInputStream = null;
                    llL1i.Iii1lill1.lILlii1L(inputStream);
                    llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
                    throw th;
                }
            } catch (Exception e3) {
                e = e3;
                inputStreamOpenInputStream = null;
            } catch (Throwable th4) {
                th = th4;
                inputStreamOpenInputStream = null;
                inputStream = inputStreamOpenInputStream2;
                llL1i.Iii1lill1.lILlii1L(inputStream);
                llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
        } catch (Throwable th5) {
            th = th5;
        }
    }

    public final void L1i11iI() {
        View viewFindViewById = findViewById(R.id.id_grid_scroll);
        int width = (viewFindViewById.getWidth() - viewFindViewById.getPaddingLeft()) - viewFindViewById.getPaddingRight();
        if (width <= 0) {
            View viewFindViewById2 = findViewById(R.id.id_root_layout);
            width = (viewFindViewById2.getWidth() - viewFindViewById2.getPaddingLeft()) - viewFindViewById2.getPaddingRight();
        }
        if (width <= 0) {
            width = getResources().getDisplayMetrics().widthPixels;
        }
        int iMax = Math.max(1, width / liIli.liIli.LI1Il(this, 120.0f));
        int size = this.f7853II1.mCursors.size() / iMax;
        if (this.f7853II1.mCursors.size() % iMax != 0) {
            size++;
        }
        int i = width / iMax;
        this.f7866lii1.removeAllViews();
        this.f7866lii1.setRowCount(size);
        this.f7866lii1.setColumnCount(iMax);
        int i2 = 0;
        while (i2 < this.f7853II1.mCursors.size()) {
            CursorInfo.CursorItem cursorItem = this.f7853II1.mCursors.get(i2);
            boolean z = i2 == this.f7853II1.mCurrentItem;
            View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_cursor, (ViewGroup) null);
            ImageView imageView = (ImageView) viewInflate.findViewById(R.id.id_cursor);
            final ImageView imageView2 = (ImageView) viewInflate.findViewById(R.id.id_edit_cursor);
            final ImageView imageView3 = (ImageView) viewInflate.findViewById(R.id.id_remove_cursor);
            imageView2.setVisibility(this.iiIL1liI ? 0 : 4);
            imageView3.setVisibility(this.iiIL1liI ? 0 : 4);
            if (cursorItem.mType == CursorInfo.TYPE_PRESET) {
                imageView.setImageResource(getResources().getIdentifier(cursorItem.mPath, "drawable", getPackageName()));
                imageView3.setVisibility(8);
                imageView2.setVisibility(8);
            } else {
                imageView.setImageURI(Uri.fromFile(new File(cursorItem.mPath)));
                imageView3.setTag(Integer.valueOf(i2));
                final int i3 = 0;
                imageView3.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.ll1Li

                    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                    public final /* synthetic */ CursorsActivity f8016IiiiL;

                    {
                        this.f8016IiiiL = this;
                    }

                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        int i4 = i3;
                        ImageView imageView4 = imageView3;
                        CursorsActivity cursorsActivity = this.f8016IiiiL;
                        switch (i4) {
                            case 0:
                                int i5 = CursorsActivity.iiL;
                                int iIntValue = ((Integer) imageView4.getTag()).intValue();
                                CursorInfo cursorInfo = cursorsActivity.f7853II1;
                                int i6 = cursorInfo.mCurrentItem;
                                if (i6 >= iIntValue) {
                                    cursorInfo.mCurrentItem = i6 - 1;
                                }
                                try {
                                    File file = new File(cursorInfo.mCursors.remove(iIntValue).mPath);
                                    if (file.exists()) {
                                        file.delete();
                                    }
                                    break;
                                } catch (Exception unused) {
                                }
                                cursorsActivity.L1i11iI();
                                try {
                                    com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.Iii1lill1().ilI11(cursorsActivity.f7853II1);
                                } catch (Exception unused2) {
                                    return;
                                }
                                break;
                            default:
                                int i7 = CursorsActivity.iiL;
                                cursorsActivity.getClass();
                                cursorsActivity.ii1(((Integer) imageView4.getTag()).intValue());
                                break;
                        }
                    }
                });
                imageView2.setTag(Integer.valueOf(i2));
                final int i4 = 1;
                imageView2.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.ll1Li

                    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                    public final /* synthetic */ CursorsActivity f8016IiiiL;

                    {
                        this.f8016IiiiL = this;
                    }

                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        int i5 = i4;
                        ImageView imageView4 = imageView2;
                        CursorsActivity cursorsActivity = this.f8016IiiiL;
                        switch (i5) {
                            case 0:
                                int i6 = CursorsActivity.iiL;
                                int iIntValue = ((Integer) imageView4.getTag()).intValue();
                                CursorInfo cursorInfo = cursorsActivity.f7853II1;
                                int i7 = cursorInfo.mCurrentItem;
                                if (i7 >= iIntValue) {
                                    cursorInfo.mCurrentItem = i7 - 1;
                                }
                                try {
                                    File file = new File(cursorInfo.mCursors.remove(iIntValue).mPath);
                                    if (file.exists()) {
                                        file.delete();
                                    }
                                    break;
                                } catch (Exception unused) {
                                }
                                cursorsActivity.L1i11iI();
                                try {
                                    com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.Iii1lill1().ilI11(cursorsActivity.f7853II1);
                                } catch (Exception unused2) {
                                    return;
                                }
                                break;
                            default:
                                int i8 = CursorsActivity.iiL;
                                cursorsActivity.getClass();
                                cursorsActivity.ii1(((Integer) imageView4.getTag()).intValue());
                                break;
                        }
                    }
                });
            }
            imageView.setSelected(z);
            imageView.setTag(Integer.valueOf(i2));
            imageView.setOnClickListener(new lL(this, 1));
            GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
            ((ViewGroup.MarginLayoutParams) layoutParams).width = i;
            ((ViewGroup.MarginLayoutParams) layoutParams).height = i;
            this.f7866lii1.addView(viewInflate, layoutParams);
            i2++;
        }
    }

    /* JADX WARN: Code duplicated, block: B:22:0x00ce  */
    public final void ii1(int i) {
        final float f;
        int iRound;
        final float f2;
        int i2;
        if (i < 0 || i >= this.f7853II1.mCursors.size()) {
            return;
        }
        this.f7865lLiLIli.setVisibility(0);
        this.f7861ilL = i;
        CursorInfo.CursorItem cursorItem = this.f7853II1.mCursors.get(i);
        this.f7855IlLi.setImageURI(Uri.fromFile(new File(cursorItem.mPath)));
        this.I1Ii1IilI.setImageURI(Uri.fromFile(new File(cursorItem.mPath)));
        this.f7857LLi.setOnSeekBarChangeListener(null);
        if (TextUtils.isEmpty(cursorItem.mAdjustedPath)) {
            f = 0.0f;
            iRound = 33;
            f2 = 0.0f;
        } else {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            options.inSampleSize = 1;
            BitmapFactory.decodeFile(cursorItem.mAdjustedPath, options);
            int i3 = options.outWidth;
            if (i3 <= 0 || (i2 = options.outHeight) <= 0) {
                f = 0.0f;
                iRound = 33;
                f2 = 0.0f;
            } else {
                float f3 = i3;
                float width = (1.0f * f3) / this.f7855IlLi.getWidth();
                iRound = Math.round((width - 0.5f) / 0.015f);
                if (iRound < 1) {
                    iRound = 1;
                }
                if (iRound > 100) {
                    iRound = 100;
                }
                f = cursorItem.mHotSpotX / f3;
                float f4 = cursorItem.mHotSpotY;
                f2 = f4 / i2;
                if (liIli.liIli.f33010ilI11) {
                    liIli.liIli.Il("CursorsActivity", "enterEditMode: ", Float.valueOf(f4), ", ", Integer.valueOf(i2), ", ", Float.valueOf(f2));
                }
                this.f7855IlLi.setScaleX(width);
                this.f7855IlLi.setScaleY(width);
                this.I1Ii1IilI.setScaleX(width);
                this.I1Ii1IilI.setScaleY(width);
            }
        }
        this.f7857LLi.setProgress(iRound);
        this.f7857LLi.setOnSeekBarChangeListener(new com.google.android.gms.auth.api.signin.internal.iL(this, 15));
        this.f7854IIiiI.setImageURI(Uri.fromFile(new File(cursorItem.mPath)));
        View view = this.f7860iLLL;
        view.setOnHoverListener(new II1llI(view, this.f7855IlLi));
        View view2 = this.f7859i1LIiLLl;
        view2.setOnHoverListener(new II1llI(view2, this.I1Ii1IilI));
        LiLLli.liIli.f3480liIli.post(new Runnable() { // from class: com.chaozhuo.gameassistant.homepage.llL
            @Override // java.lang.Runnable
            public final void run() {
                CursorsActivity cursorsActivity = this.f8020ilI11;
                float width2 = f * ((cursorsActivity.f7864lIllIIiI.getWidth() - cursorsActivity.f7863lIL.getWidth()) - 1);
                float height = f2 * ((cursorsActivity.f7864lIllIIiI.getHeight() - cursorsActivity.f7863lIL.getHeight()) - 1);
                if (liIli.liIli.f33010ilI11) {
                    liIli.liIli.Il("CursorsActivity", "enterEditMode: ", Float.valueOf(height));
                }
                cursorsActivity.f7863lIL.setX(width2);
                cursorsActivity.f7863lIL.setY(height);
            }
        });
        this.f7863lIL.setOnTouchListener(new lLliL(this, 1));
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1 && i2 == -1) {
            p090lLI1.iIiI1.f32587liIli.when(new li1(0, this, intent)).done(new liIli(this, 3));
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.activity.ComponentActivity, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) throws IllegalAccessException {
        super.onConfigurationChanged(configuration);
        int i = this.II;
        int i2 = configuration.orientation;
        if (i != i2) {
            this.II = i2;
            L1i11iI();
        }
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        CursorInfo cursorInfoIiLlllI;
        super.onCreate(bundle);
        setContentView(R.layout.activity_cursors);
        lL lLVar = new lL(this, 0);
        findViewById(R.id.image_back).setOnClickListener(lLVar);
        findViewById(R.id.text_title).setOnClickListener(lLVar);
        ImageView imageView = (ImageView) findViewById(R.id.id_add);
        this.f7858Li = imageView;
        imageView.setOnClickListener(new lL(this, 2));
        this.f7866lii1 = (GridLayout) findViewById(R.id.id_gridlayout);
        this.II = getResources().getConfiguration().orientation;
        try {
            cursorInfoIiLlllI = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.Iii1lill1().iiLlllI();
        } catch (Exception unused) {
            cursorInfoIiLlllI = null;
        }
        this.f7853II1 = cursorInfoIiLlllI;
        if (cursorInfoIiLlllI == null) {
            finish();
            return;
        }
        L1i11iI();
        this.f7865lLiLIli = findViewById(R.id.id_editor);
        this.f7860iLLL = findViewById(R.id.id_white_wrapper);
        this.f7859i1LIiLLl = findViewById(R.id.id_black_wrapper);
        this.f7855IlLi = (ImageView) findViewById(R.id.id_cursor_white);
        this.I1Ii1IilI = (ImageView) findViewById(R.id.id_cursor_black);
        this.f7857LLi = (CustomSeekBarView) findViewById(R.id.size_seekbar);
        this.f7864lIllIIiI = findViewById(R.id.id_large_wrapper);
        this.f7854IIiiI = (ImageView) findViewById(R.id.id_cursor_large);
        this.f7863lIL = (ImageView) findViewById(R.id.id_cursor_hotspot);
        findViewById(R.id.image_back2).setOnClickListener(new lL(this, 3));
        findViewById(R.id.text_title2).setOnClickListener(new lL(this, 4));
        findViewById(R.id.id_confirm).setOnClickListener(new lL(this, 5));
        this.f7865lLiLIli.setVisibility(4);
        this.f7861ilL = -1;
        View viewFindViewById = findViewById(R.id.id_root_layout);
        l11l l11lVar = new l11l(this, findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_toolbar_layout2), viewFindViewById);
        WeakHashMap weakHashMap = l11lLIL.f5681liIli;
        androidx.core.view.IlII.Ilil11ILI(viewFindViewById, l11lVar);
    }
}
