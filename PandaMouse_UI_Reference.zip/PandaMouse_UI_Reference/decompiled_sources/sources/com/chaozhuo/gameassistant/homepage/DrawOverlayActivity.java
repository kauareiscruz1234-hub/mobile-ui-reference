package com.chaozhuo.gameassistant.homepage;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.XApp;
import com.chaozhuo.gameassistant.czkeymap.R$string;
import com.panda.mouse.R;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class DrawOverlayActivity extends BaseActivity implements View.OnClickListener {

    /* JADX INFO: renamed from: Ll1, reason: collision with root package name */
    public static boolean f7867Ll1 = false;

    /* JADX INFO: renamed from: iil, reason: collision with root package name */
    public static boolean f7868iil = false;

    /* JADX INFO: renamed from: lll, reason: collision with root package name */
    public static boolean f7869lll = false;
    public View I1Ii1IilI;
    public View II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public View f7871II1;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public View f7872IIiiI;
    public View IIlII;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public View f7873IlLi;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public View f7874LLIi;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public View f7875LLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public View f7876Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public View f7877i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public View f7879iLLL;
    public View iiIL1liI;
    public View iiL;
    public View iilL1Ll;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public View f7880ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public View f7881ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public View f7882lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public View f7883lIllIIiI;

    /* JADX INFO: renamed from: lLLlLlL, reason: collision with root package name */
    public View f7884lLLlLlL;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public View f7885lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public View f7886lii1;

    /* JADX INFO: renamed from: i1li1l, reason: collision with root package name */
    public boolean f7878i1li1l = false;

    /* JADX INFO: renamed from: I11l, reason: collision with root package name */
    public final il1 f7870I11l = new il1(this, 2);

    public final void IL() {
        new Handler().postDelayed(new Ilil11ILI(this, 3), 500L);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int i = 1;
        switch (view.getId()) {
            case R.id.btn_activate /* 2131296406 */:
                startActivity(new Intent(this, (Class<?>) ActivationActivity.class));
                break;
            case R.id.btn_adb_input /* 2131296407 */:
                ImageView imageView = new ImageView(this);
                imageView.setLayoutParams(new ViewGroup.LayoutParams(liIli.liIli.LI1Il(XApp.f7417IiiiL, 260.0f), liIli.liIli.LI1Il(XApp.f7417IiiiL, 342.0f)));
                imageView.setImageResource(R.drawable.xiaomi_usb);
                IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(this, 2131951627);
                ilil11ILI.IL(R.string.xiaomi_adbinput_title);
                ilil11ILI.Il1iLli("Enable", new Il1iLli(this, i));
                androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
                ilil11ILI2.f3973L1i11iI = imageView;
                ilil11ILI2.f3979ii1 = 0;
                ilil11ILI.iI1().show();
                break;
            case R.id.btn_draw_overlay /* 2131296415 */:
                p049iL1.iL iLVar = p049iL1.iL.f28845iIiI1;
                if (iLVar.f28848Iii1lill1) {
                    int i2 = iLVar.f28847Iii;
                    if (i2 == 5) {
                        lLLli11iI.ILl.Ii(this);
                    } else if (i2 == 6) {
                        lLLli11iI.ILl.lli11(this);
                    } else if (i2 == 7) {
                        lLLli11iI.ILl.i1(this);
                    } else if (i2 == 8) {
                        lLLli11iI.ILl.LI1lllLl(this);
                    } else if (!lLLli11iI.ILl.LI1lllLl(this) && !lLLli11iI.ILl.i1(this) && !lLLli11iI.ILl.lli11(this) && !lLLli11iI.ILl.Ii(this)) {
                        if (liIli.liIli.f33010ilI11) {
                            liIli.liIli.LI1lllLl("PermissionUtils", "this is a special MIUI rom version, its version code ", Integer.valueOf(i2));
                        }
                    }
                } else if (iLVar.f28849Ilil11ILI) {
                    try {
                        Intent intent = new Intent("com.meizu.safe.security.SHOW_APPSEC");
                        intent.setClassName("com.meizu.safe", "com.meizu.safe.security.AppSecActivity");
                        intent.putExtra("packageName", getPackageName());
                        startActivityForResult(intent, -1);
                    } catch (Exception e) {
                        if (liIli.liIli.f33010ilI11) {
                            liIli.liIli.LI1lllLl("PermissionUtils", "applyMeizuPermission: ", e);
                        }
                        Toast.makeText(this, R$string.please_enable_overlay, 0).show();
                    }
                }
                Intent intent2 = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
                intent2.setData(Uri.parse("package:" + getPackageName()));
                try {
                    startActivityForResult(intent2, -1);
                } catch (Exception e2) {
                    if (liIli.liIli.f33010ilI11) {
                        liIli.liIli.LI1lllLl("PermissionUtils", "requestDrawOverlaysPermission: ", e2);
                    }
                    Toast.makeText(this, R$string.please_enable_overlay, 0).show();
                    return;
                }
                break;
            case R.id.btn_usage_stats /* 2131296435 */:
                try {
                    Intent intent3 = new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS");
                    intent3.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent3);
                } catch (Exception e3) {
                    e3.printStackTrace();
                    return;
                }
                break;
            case R.id.text_adb_input_skip /* 2131297262 */:
                findViewById(R.id.permission_window).setVisibility(4);
                this.iiIL1liI.setVisibility(0);
                break;
            case R.id.text_cannot_find_cancel /* 2131297266 */:
                findViewById(R.id.permission_window).setVisibility(0);
                this.f7873IlLi.setVisibility(4);
                break;
            case R.id.text_draw_overlay_skip /* 2131297272 */:
                findViewById(R.id.permission_window).setVisibility(4);
                this.f7872IIiiI.setVisibility(0);
                break;
            case R.id.text_skip_adb_input_cancel /* 2131297283 */:
                findViewById(R.id.permission_window).setVisibility(0);
                this.iiIL1liI.setVisibility(4);
                break;
            case R.id.text_skip_adb_input_ok /* 2131297284 */:
                f7867Ll1 = true;
                findViewById(R.id.permission_window).setVisibility(0);
                this.iiIL1liI.setVisibility(4);
                IL();
                break;
            case R.id.text_skip_cancel /* 2131297285 */:
                findViewById(R.id.permission_window).setVisibility(0);
                this.f7872IIiiI.setVisibility(4);
                break;
            case R.id.text_skip_not_find /* 2131297286 */:
                f7868iil = true;
                findViewById(R.id.permission_window).setVisibility(0);
                this.f7873IlLi.setVisibility(4);
                IL();
                break;
            case R.id.text_skip_overlay /* 2131297287 */:
                f7869lll = true;
                findViewById(R.id.permission_window).setVisibility(0);
                this.f7872IIiiI.setVisibility(4);
                IL();
                break;
            case R.id.text_usage_stats_skip /* 2131297291 */:
                findViewById(R.id.permission_window).setVisibility(4);
                this.f7873IlLi.setVisibility(0);
                break;
        }
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        iilli().Iii(1);
        super.onCreate(bundle);
        boolean zLiii1 = false;
        setFinishOnTouchOutside(false);
        setContentView(R.layout.activity_draw_overlay);
        this.II = findViewById(R.id.btn_draw_overlay);
        this.f7886lii1 = findViewById(R.id.floating_widgets_ok);
        this.II.setOnClickListener(this);
        this.f7871II1 = findViewById(R.id.btn_usage_stats);
        this.f7876Li = findViewById(R.id.usage_stats_ok);
        this.f7871II1.setOnClickListener(this);
        this.f7885lLiLIli = findViewById(R.id.btn_activate);
        this.f7879iLLL = findViewById(R.id.activate_ok);
        this.f7885lLiLIli.setOnClickListener(this);
        this.f7873IlLi = findViewById(R.id.layout_cannot_find_battery);
        View viewFindViewById = findViewById(R.id.text_usage_stats_skip);
        this.f7877i1LIiLLl = viewFindViewById;
        viewFindViewById.setOnClickListener(this);
        View viewFindViewById2 = findViewById(R.id.text_skip_not_find);
        this.I1Ii1IilI = viewFindViewById2;
        viewFindViewById2.setOnClickListener(this);
        View viewFindViewById3 = findViewById(R.id.text_cannot_find_cancel);
        this.f7875LLi = viewFindViewById3;
        viewFindViewById3.setOnClickListener(this);
        View viewFindViewById4 = findViewById(R.id.text_skip_overlay);
        this.f7882lIL = viewFindViewById4;
        viewFindViewById4.setOnClickListener(this);
        View viewFindViewById5 = findViewById(R.id.text_skip_cancel);
        this.f7880ilL = viewFindViewById5;
        viewFindViewById5.setOnClickListener(this);
        View viewFindViewById6 = findViewById(R.id.text_draw_overlay_skip);
        this.f7883lIllIIiI = viewFindViewById6;
        viewFindViewById6.setOnClickListener(this);
        this.f7872IIiiI = findViewById(R.id.layout_skip_overlay);
        this.iilL1Ll = findViewById(R.id.adb_input_wrapper);
        View viewFindViewById7 = findViewById(R.id.btn_adb_input);
        this.f7881ill = viewFindViewById7;
        viewFindViewById7.setOnClickListener(this);
        this.IIlII = findViewById(R.id.adb_input_ok);
        View viewFindViewById8 = findViewById(R.id.text_adb_input_skip);
        this.f7874LLIi = viewFindViewById8;
        viewFindViewById8.setOnClickListener(this);
        this.iiIL1liI = findViewById(R.id.layout_skip_adb_input);
        View viewFindViewById9 = findViewById(R.id.text_skip_adb_input_ok);
        this.iiL = viewFindViewById9;
        viewFindViewById9.setOnClickListener(this);
        View viewFindViewById10 = findViewById(R.id.text_skip_adb_input_cancel);
        this.f7884lLLlLlL = viewFindViewById10;
        viewFindViewById10.setOnClickListener(this);
        this.iilL1Ll.setVisibility(lLLli11iI.ILl.Il1iLli() == -1 ? 8 : 0);
        com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
        try {
            zLiii1 = i1lI111LL.Iii1lill1().Liii1();
        } catch (Exception unused) {
        }
        this.f7878i1li1l = zLiii1;
        try {
            i1lI111LL.Iii1lill1().lLLL1Il(this.f7870I11l);
        } catch (Exception unused2) {
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
        try {
            i1lI111LL.Iii1lill1().lIIiI(this.f7870I11l);
        } catch (Exception unused) {
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        super.onResume();
        IL();
    }
}
