package com.chaozhuo.gameassistant.homepage;

import LILllili.ii1l1l;
import android.R;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bytedance.sdk.component.pglcrypt.PglCryptUtils;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.convert.bean.HighlightRecordCommand;
import com.chaozhuo.gameassistant.czkeymap.bean.KeyMapConfig;
import com.chaozhuo.gameassistant.homepage.adapter.ListAppAdapter;
import com.google.android.gms.internal.ads.Lllll11;
import com.google.android.gms.internal.measurement.iIi1il;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Source;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.Callable;
import org.jdeferred.DoneCallback;
import org.json.JSONObject;
import p047iIiii.ilI1LL;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class KeymapsActivity extends BaseActivity {

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public static boolean f7913LLi;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public static String f7914lIllIIiI;
    public ProgressDialog I1Ii1IilI;
    public int II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public RecyclerView f7915II1;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public ilI1LL f7916IlLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public ListAppAdapter f7917Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public int f7918i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public File f7919iLLL;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public ilI1LL f7920lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public long f7921lii1;

    public static boolean Ll1LIL1l(ilI1LL ili1ll) {
        return ili1ll != null && "com.panda.mappinglab".equals(ili1ll.f28717liIli);
    }

    public final void I1lI111LL(ilI1LL ili1ll, final String str, final String str2) {
        final String strIii;
        final String string;
        String str3;
        KeyMapConfig keyMapConfigIIlI;
        if ("draft".equals(str)) {
            try {
                keyMapConfigIIlI = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.Iii1lill1().IIlI(ili1ll.f28717liIli);
            } catch (Exception unused) {
                keyMapConfigIIlI = null;
            }
            if (keyMapConfigIIlI == null || !TextUtils.equals(keyMapConfigIIlI.pkgName, ili1ll.f28717liIli) || keyMapConfigIIlI.isEmptyConfig()) {
                Toast.makeText(this, "No keymap to upload as draft.", 0).show();
                return;
            }
            com.google.gson.ILl iLl = new com.google.gson.ILl();
            KeyMapConfig keyMapConfig = (KeyMapConfig) iLl.Ilil11ILI(KeyMapConfig.class, iLl.Iii(keyMapConfigIIlI));
            keyMapConfig.pkgName = str2;
            strIii = iLl.Iii(keyMapConfig);
        } else {
            strIii = null;
        }
        DisplayMetrics displayMetricsIl1iLli = liIli.liIli.Il1iLli(this);
        final int iMax = Math.max(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels);
        final int iMin = Math.min(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels);
        if (Ll1LIL1l(ili1ll)) {
            string = str2;
        } else {
            string = TextUtils.isEmpty(ili1ll.f28715Ilil11ILI) ? ili1ll.f28717liIli : ili1ll.f28715Ilil11ILI.toString();
        }
        L1i11iI();
        if ("draft".equals(str)) {
            str3 = "Uploading keymap draft...";
        } else {
            str3 = "published".equals(str) ? "Publishing keymap..." : "Disabling published keymap...";
        }
        this.I1Ii1IilI = ProgressDialog.show(this, null, str3, true, false);
        p090lLI1.iIiI1.f32587liIli.when(new Callable() { // from class: com.chaozhuo.gameassistant.homepage.Ii
            @Override // java.util.concurrent.Callable
            public final Object call() throws Throwable {
                String strOptString;
                int i = iMax;
                int i2 = iMin;
                String str4 = KeymapsActivity.f7914lIllIIiI;
                String str5 = str;
                boolean zEquals = "draft".equals(str5);
                if (str4 != null && !str4.isEmpty()) {
                    String str6 = str2;
                    if (!str6.isEmpty() && (zEquals || "published".equals(str5) || "disabled".equals(str5))) {
                        String str7 = string;
                        String str8 = strIii;
                        if (!zEquals || (str7 != null && !str7.isEmpty() && str8 != null && !str8.isEmpty())) {
                            try {
                                JSONObject jSONObject = new JSONObject();
                                jSONObject.put("appId", "panda_mouse_pro");
                                jSONObject.put("gamePackageName", str6);
                                jSONObject.put("screenWidth", i);
                                jSONObject.put("screenHeight", i2);
                                jSONObject.put("status", str5);
                                if (zEquals) {
                                    jSONObject.put("gameName", str7);
                                    jSONObject.put("config", new JSONObject(str8));
                                }
                                jSONObject.put("timestamp", System.currentTimeMillis());
                                p063iil.lli11.lIIl(i, i2, "admin ".concat(str5), str6, null, HighlightRecordCommand.ACTION_START);
                                p013Iil.lI lIVarLlL = p063iil.lli11.llL("/v1/game-keymaps/admin/upsert", jSONObject.toString(), str4);
                                String str9 = (String) lIVarLlL.f1575lILlii1L;
                                int i3 = lIVarLlL.f1574Ilil11ILI;
                                p063iil.lli11.I1lI111LL("admin ".concat(str5), lIVarLlL);
                                if (str9 == null) {
                                    return new p013Iil.Liii1(lIVarLlL.f1573Iii1lill1 ? "network error" : "server returned no response", false, i3 == 401);
                                }
                                JSONObject jSONObject2 = new JSONObject(str9);
                                if (i3 >= 200 && i3 < 300 && jSONObject2.optBoolean("success", false)) {
                                    return new p013Iil.Liii1(null, true, false);
                                }
                                JSONObject jSONObjectOptJSONObject = jSONObject2.optJSONObject("error");
                                if (jSONObjectOptJSONObject == null) {
                                    strOptString = "server returned HTTP " + i3;
                                } else {
                                    strOptString = jSONObjectOptJSONObject.optString(PglCryptUtils.KEY_MESSAGE, "server returned HTTP " + i3);
                                }
                                return new p013Iil.Liii1(strOptString, false, i3 == 401);
                            } catch (Exception e) {
                                if (liIli.liIli.f33010ilI11) {
                                    liIli.liIli.LI1lllLl("PandaApiHttpClient", "admin ", str5, " request failed: ", e.getClass().getSimpleName());
                                }
                                return new p013Iil.Liii1("invalid server response", false, false);
                            }
                        }
                    }
                }
                return new p013Iil.Liii1("invalid local request", false, false);
            }
        }).done(new ILl(this, str, 1));
    }

    public final void IL(final ilI1LL ili1ll, final boolean z) {
        final EditText editText;
        String strLILlii1L;
        boolean zLl1LIL1l = Ll1LIL1l(ili1ll);
        String string = TextUtils.isEmpty(ili1ll.f28715Ilil11ILI) ? ili1ll.f28717liIli : ili1ll.f28715Ilil11ILI.toString();
        if (zLl1LIL1l) {
            editText = new EditText(this);
            editText.setSingleLine(true);
            editText.setHint("Target package name");
            editText.setInputType(17);
        } else {
            editText = null;
        }
        IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(this, 2131951627);
        androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
        ilil11ILI2.f3983lILlii1L = z ? "Restore from draft" : "Restore keymap";
        if (zLl1LIL1l) {
            strLILlii1L = p080l11l.iI1.Ilil11ILI(new StringBuilder("Restore the "), z ? "server draft" : "published keymap", " for the package entered below and overwrite the Mapping Lab local keymap?");
        } else {
            strLILlii1L = p080l11l.iI1.lILlii1L(new StringBuilder("Restore the "), z ? "server draft" : "published keymap", " for ", string, " and overwrite its local keymap?");
        }
        ilil11ILI2.f3969Iii = strLILlii1L;
        ilil11ILI.Il1iLli("Restore", new DialogInterface.OnClickListener() { // from class: com.chaozhuo.gameassistant.homepage.ilI
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                boolean z2 = KeymapsActivity.f7913LLi;
                final KeymapsActivity keymapsActivity = this.f7979ilI11;
                final ilI1LL ili1ll2 = ili1ll;
                final String strIi1 = keymapsActivity.ii1(ili1ll2, editText);
                if (strIi1 != null) {
                    DisplayMetrics displayMetricsIl1iLli = liIli.liIli.Il1iLli(keymapsActivity);
                    final int iMax = Math.max(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels);
                    final int iMin = Math.min(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels);
                    keymapsActivity.L1i11iI();
                    final boolean z3 = z;
                    keymapsActivity.I1Ii1IilI = ProgressDialog.show(keymapsActivity, null, z3 ? "Restoring keymap draft..." : "Restoring published keymap...", true, false);
                    p090lLI1.iIiI1.f32587liIli.when(new Callable() { // from class: com.chaozhuo.gameassistant.homepage.Liii1
                        @Override // java.util.concurrent.Callable
                        public final Object call() {
                            boolean z4 = KeymapsActivity.f7913LLi;
                            boolean z5 = z3;
                            String str = strIi1;
                            int i2 = iMax;
                            int i3 = iMin;
                            return z5 ? p063iil.lli11.iilli(i2, i3, str, "draft") : p063iil.lli11.iilli(i2, i3, str, null);
                        }
                    }).done(new DoneCallback() { // from class: com.chaozhuo.gameassistant.homepage.l1LLI
                        @Override // org.jdeferred.DoneCallback
                        public final void onDone(Object obj) {
                            KeyMapConfig keyMapConfigIIlI;
                            String str;
                            String str2 = strIi1;
                            ilI1LL ili1ll3 = ili1ll2;
                            p013Iil.l1LLI l1lli = (p013Iil.l1LLI) obj;
                            boolean z4 = KeymapsActivity.f7913LLi;
                            KeymapsActivity keymapsActivity2 = keymapsActivity;
                            keymapsActivity2.L1i11iI();
                            boolean z5 = z3;
                            if (l1lli != null) {
                                String str3 = l1lli.f1572liIli;
                                int i2 = l1lli.f1571Ilil11ILI;
                                if (!l1lli.f1570Iii1lill1) {
                                    if (i2 < 200 || i2 >= 300) {
                                        StringBuilder sb = new StringBuilder("Failed to restore ");
                                        sb.append(z5 ? "keymap draft" : "published keymap");
                                        sb.append(": server returned HTTP ");
                                        sb.append(i2);
                                        sb.append(".");
                                        Toast.makeText(keymapsActivity2, sb.toString(), 0).show();
                                        return;
                                    }
                                    if (TextUtils.isEmpty(str3)) {
                                        Toast.makeText(keymapsActivity2, z5 ? "No matching keymap draft was found." : "No matching published keymap was found.", 0).show();
                                        return;
                                    }
                                    try {
                                        KeyMapConfig keyMapConfig = (KeyMapConfig) new com.google.gson.ILl().Ilil11ILI(KeyMapConfig.class, str3);
                                        if (keyMapConfig != null && TextUtils.equals(keyMapConfig.pkgName, str2) && !keyMapConfig.isEmptyConfig()) {
                                            keyMapConfig.ensureValid();
                                            keyMapConfig.pkgName = ili1ll3.f28717liIli;
                                            com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
                                            try {
                                                i1lI111LL.Iii1lill1().lIL(keyMapConfig);
                                            } catch (Exception unused) {
                                            }
                                            try {
                                                keyMapConfigIIlI = i1lI111LL.Iii1lill1().IIlI(ili1ll3.f28717liIli);
                                            } catch (Exception unused2) {
                                                keyMapConfigIIlI = null;
                                            }
                                            if (keyMapConfig.equals(keyMapConfigIIlI)) {
                                                str = z5 ? "Keymap draft restored and saved locally." : "Published keymap restored and saved locally.";
                                            } else {
                                                str = "Failed to save the restored keymap locally.";
                                            }
                                            Toast.makeText(keymapsActivity2, str, 0).show();
                                            return;
                                        }
                                        StringBuilder sb2 = new StringBuilder("Failed to restore ");
                                        sb2.append(z5 ? "keymap draft" : "published keymap");
                                        sb2.append(": invalid server data.");
                                        Toast.makeText(keymapsActivity2, sb2.toString(), 0).show();
                                        return;
                                    } catch (Throwable unused3) {
                                        StringBuilder sb3 = new StringBuilder("Failed to restore ");
                                        sb3.append(z5 ? "keymap draft" : "published keymap");
                                        sb3.append(": invalid server data.");
                                        Toast.makeText(keymapsActivity2, sb3.toString(), 0).show();
                                        return;
                                    }
                                }
                            }
                            StringBuilder sb4 = new StringBuilder("Failed to restore ");
                            sb4.append(z5 ? "keymap draft" : "published keymap");
                            sb4.append(": network error.");
                            Toast.makeText(keymapsActivity2, sb4.toString(), 0).show();
                        }
                    });
                }
            }
        });
        ilil11ILI.IiI1l(R.string.cancel, null);
        if (editText != null) {
            ilil11ILI2.f3973L1i11iI = editText;
            ilil11ILI2.f3979ii1 = 0;
        }
        ilil11ILI.ii1();
    }

    public final void L1i11iI() {
        ProgressDialog progressDialog = this.I1Ii1IilI;
        if (progressDialog != null && progressDialog.isShowing()) {
            this.I1Ii1IilI.dismiss();
        }
        this.I1Ii1IilI = null;
    }

    public final void iLLLiIl1(ilI1LL ili1ll, String str) {
        String strLLliL;
        EditText editText;
        String str2;
        String str3;
        boolean zEquals = "draft".equals(str);
        boolean zEquals2 = "published".equals(str);
        boolean zLl1LIL1l = Ll1LIL1l(ili1ll);
        String string = TextUtils.isEmpty(ili1ll.f28715Ilil11ILI) ? ili1ll.f28717liIli : ili1ll.f28715Ilil11ILI.toString();
        if (zLl1LIL1l) {
            if ("draft".equals(str)) {
                strLLliL = "Upload the Mapping Lab local keymap as a server draft for the package entered below? This will replace the existing server draft. The published keymap will not be affected.";
            } else {
                strLLliL = "published".equals(str) ? "Publish the server draft for the package entered below and replace its current published keymap?" : "Disable the published keymap for the package entered below? The server draft will be kept.";
            }
        } else if (zEquals) {
            strLLliL = Lllll11.lLliL("Upload the local keymap for ", string, " as a server draft? This will replace the existing server draft. The published keymap will not be affected.");
        } else {
            strLLliL = zEquals2 ? Lllll11.lLliL("Publish the server draft for ", string, " and replace its current published keymap?") : Lllll11.lLliL("Disable the published keymap for ", string, "? The server draft will be kept.");
        }
        if (zLl1LIL1l) {
            editText = new EditText(this);
            editText.setSingleLine(true);
            editText.setHint("Target package name");
            editText.setInputType(17);
        } else {
            editText = null;
        }
        IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(this, 2131951627);
        androidx.appcompat.app.Ilil11ILI ilil11ILI2 = (androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l;
        if ("draft".equals(str)) {
            str2 = "Upload draft";
        } else {
            str2 = "published".equals(str) ? "Publish keymap" : "Disable keymap";
        }
        ilil11ILI2.f3983lILlii1L = str2;
        ilil11ILI2.f3969Iii = strLLliL;
        if (zEquals) {
            str3 = "Upload";
        } else {
            str3 = zEquals2 ? "Publish" : "Disable";
        }
        ilil11ILI.Il1iLli(str3, new ii1l1l(this, ili1ll, editText, str));
        ilil11ILI.IiI1l(R.string.cancel, null);
        if (editText != null) {
            ilil11ILI2.f3973L1i11iI = editText;
            ilil11ILI2.f3979ii1 = 0;
        }
        ilil11ILI.ii1();
    }

    public final String ii1(ilI1LL ili1ll, EditText editText) {
        if (!Ll1LIL1l(ili1ll)) {
            return ili1ll.f28717liIli;
        }
        String strTrim = editText == null ? "" : editText.getText().toString().trim();
        if (!TextUtils.isEmpty(strTrim)) {
            return strTrim;
        }
        Toast.makeText(this, "Target package name is required.", 0).show();
        return null;
    }

    public final File ilI1(ilI1LL ili1ll) throws Throwable {
        KeyMapConfig keyMapConfigIIlI;
        try {
            keyMapConfigIIlI = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.Iii1lill1().IIlI(ili1ll.f28717liIli);
        } catch (Exception unused) {
            keyMapConfigIIlI = null;
        }
        if (keyMapConfigIIlI != null && TextUtils.equals(keyMapConfigIIlI.pkgName, ili1ll.f28717liIli) && !keyMapConfigIIlI.isEmptyConfig()) {
            try {
                String strIii = new com.google.gson.ILl().Iii(keyMapConfigIIlI);
                if (!TextUtils.isEmpty(strIii)) {
                    String str = "pmp_" + (TextUtils.isEmpty(ili1ll.f28715Ilil11ILI) ? ili1ll.f28717liIli : ili1ll.f28715Ilil11ILI.toString()) + ".json";
                    File file = new File(getExternalFilesDir(null), "keymaps");
                    if (!file.exists()) {
                        file.mkdirs();
                    }
                    File file2 = new File(file, str);
                    if (file2.exists()) {
                        file2.delete();
                    }
                    llL1i.Iii1lill1.iLi1(file2, strIii.getBytes(StandardCharsets.UTF_8));
                    return file2;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public final void l1LLlI(String str) {
        try {
            final KeyMapConfig keyMapConfig = (KeyMapConfig) new com.google.gson.ILl().Ilil11ILI(KeyMapConfig.class, str);
            final int i = 0;
            if (keyMapConfig != null && !TextUtils.isEmpty(keyMapConfig.pkgName) && !keyMapConfig.isEmptyConfig()) {
                keyMapConfig.ensureValid();
                final int i2 = 1;
                if (TextUtils.equals(this.f7920lLiLIli.f28717liIli, keyMapConfig.pkgName)) {
                    IL1.Ilil11ILI ilil11ILI = new IL1.Ilil11ILI(this, 2131951627);
                    ((androidx.appcompat.app.Ilil11ILI) ilil11ILI.f675lLL1L111l).f3969Iii = getString(com.panda.mouse.R.string.import_title, this.f7920lLiLIli.f28715Ilil11ILI);
                    ilil11ILI.iilli(com.panda.mouse.R.string.import_ok, new DialogInterface.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1

                        /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                        public final /* synthetic */ KeymapsActivity f7958IiiiL;

                        {
                            this.f7958IiiiL = this;
                        }

                        @Override // android.content.DialogInterface.OnClickListener
                        public final void onClick(DialogInterface dialogInterface, int i3) {
                            int i4 = i;
                            com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
                            KeyMapConfig keyMapConfig2 = keyMapConfig;
                            KeymapsActivity keymapsActivity = this.f7958IiiiL;
                            switch (i4) {
                                case 0:
                                    boolean z = KeymapsActivity.f7913LLi;
                                    try {
                                        i1lI111LL.Iii1lill1().lIL(keyMapConfig2);
                                        break;
                                    } catch (Exception unused) {
                                    }
                                    Toast.makeText(keymapsActivity, "Game keymap is imported successfully!", 0).show();
                                    break;
                                default:
                                    keyMapConfig2.pkgName = keymapsActivity.f7920lLiLIli.f28717liIli;
                                    try {
                                        i1lI111LL.Iii1lill1().lIL(keyMapConfig2);
                                        break;
                                    } catch (Exception unused2) {
                                    }
                                    Toast.makeText(keymapsActivity, "Game keymap is imported successfully!", 0).show();
                                    break;
                            }
                        }
                    });
                    ilil11ILI.IiI1l(com.panda.mouse.R.string.dialog_cancel, null);
                    ilil11ILI.ii1();
                    return;
                }
                IL1.Ilil11ILI ilil11ILI2 = new IL1.Ilil11ILI(this, 2131951627);
                ilil11ILI2.ILLl(com.panda.mouse.R.string.import_override_title);
                ilil11ILI2.iilli(com.panda.mouse.R.string.import_ok, new DialogInterface.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1

                    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
                    public final /* synthetic */ KeymapsActivity f7958IiiiL;

                    {
                        this.f7958IiiiL = this;
                    }

                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i3) {
                        int i4 = i2;
                        com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
                        KeyMapConfig keyMapConfig2 = keyMapConfig;
                        KeymapsActivity keymapsActivity = this.f7958IiiiL;
                        switch (i4) {
                            case 0:
                                boolean z = KeymapsActivity.f7913LLi;
                                try {
                                    i1lI111LL.Iii1lill1().lIL(keyMapConfig2);
                                    break;
                                } catch (Exception unused) {
                                }
                                Toast.makeText(keymapsActivity, "Game keymap is imported successfully!", 0).show();
                                break;
                            default:
                                keyMapConfig2.pkgName = keymapsActivity.f7920lLiLIli.f28717liIli;
                                try {
                                    i1lI111LL.Iii1lill1().lIL(keyMapConfig2);
                                    break;
                                } catch (Exception unused2) {
                                }
                                Toast.makeText(keymapsActivity, "Game keymap is imported successfully!", 0).show();
                                break;
                        }
                    }
                });
                ilil11ILI2.IiI1l(com.panda.mouse.R.string.dialog_cancel, null);
                ilil11ILI2.ii1();
                return;
            }
            Toast.makeText(this, "Imported keymap json is invalid!", 0).show();
        } catch (Throwable unused) {
        }
    }

    /* JADX WARN: Code duplicated, block: B:60:0x01f2  */
    public final void lIIl(int i, ilI1LL ili1ll) throws Throwable {
        boolean zIL1i1iil;
        Task task;
        Task taskContinueWith;
        boolean zLl11Ll = false;
        if (i == 1) {
            File fileIlI1 = ilI1(ili1ll);
            if (fileIlI1 == null) {
                Toast.makeText(this, com.panda.mouse.R.string.toast_keymap_not_exist, 0).show();
                return;
            }
            L1i11iI();
            this.I1Ii1IilI = ProgressDialog.show(this, null, getString(com.panda.mouse.R.string.cloud_uploading), true, false);
            try {
                FileInputStream fileInputStream = new FileInputStream(fileIlI1);
                try {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] bArr = new byte[100];
                    while (true) {
                        int i2 = fileInputStream.read(bArr, 0, 100);
                        if (i2 <= 0) {
                            String str = new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8);
                            fileInputStream.close();
                            DisplayMetrics displayMetricsIl1iLli = liIli.liIli.Il1iLli(this);
                            iILliI1I1.iL.f28422Ilil11ILI.lILlii1L(Math.max(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels), Math.min(displayMetricsIl1iLli.widthPixels, displayMetricsIl1iLli.heightPixels), ili1ll.f28717liIli, str).addOnCompleteListener(new lli11(this, 1));
                            return;
                        }
                        byteArrayOutputStream.write(bArr, 0, i2);
                        L1i11iI();
                        Toast.makeText(this, com.panda.mouse.R.string.cloud_upload_failed, 0).show();
                        return;
                    }
                } catch (Throwable th) {
                    try {
                        fileInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } catch (Exception unused) {
                L1i11iI();
                Toast.makeText(this, com.panda.mouse.R.string.cloud_upload_failed, 0).show();
                return;
            }
        }
        L1i11iI();
        this.I1Ii1IilI = ProgressDialog.show(this, null, getString(com.panda.mouse.R.string.cloud_restoring), true, false);
        iILliI1I1.iL iLVar = iILliI1I1.iL.f28422Ilil11ILI;
        String str2 = ili1ll.f28717liIli;
        iLVar.getClass();
        if (TextUtils.isEmpty(str2)) {
            task = iILliI1I1.iL.Iii1lill1("Package name is empty");
        } else {
            FirebaseUser firebaseUser = iLVar.f28424liIli.f25981Iii;
            if (firebaseUser == null) {
                task = iILliI1I1.iL.Iii1lill1("Sign-in is required");
            } else {
                com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
                try {
                    zIL1i1iil = i1lI111LL.Iii1lill1().IL1i1iil();
                } catch (Exception unused2) {
                    zIL1i1iil = false;
                }
                if (zIL1i1iil) {
                    try {
                        zLl11Ll = i1lI111LL.Iii1lill1().Ll11Ll();
                    } catch (Exception unused3) {
                    }
                    if (zLl11Ll || i1lI111LL.Ilil11ILI()) {
                        String uid = firebaseUser.getUid();
                        FirebaseFirestore firebaseFirestore = iLVar.f28423Iii1lill1;
                        firebaseFirestore.f26203il1.lLliL();
                        com.google.firebase.firestore.model.ILLl iLLlIilli = com.google.firebase.firestore.model.ILLl.iilli("users");
                        com.google.firebase.firestore.core.Ll1LIL1l ll1LIL1lLiIli = com.google.firebase.firestore.core.Ll1LIL1l.liIli(iLLlIilli);
                        List list = iLLlIilli.f26478ilI11;
                        if (list.size() % 2 != 1) {
                            throw new IllegalArgumentException("Invalid collection reference. Collection references must have an odd number of segments, but " + iLLlIilli.ILl() + " has " + list.size());
                        }
                        ii1l1lll.ilI1.lI(uid, "Provided document path must not be null.");
                        com.google.firebase.firestore.iL iLVarIii1lill1 = com.google.firebase.firestore.iL.Iii1lill1((com.google.firebase.firestore.model.ILLl) ll1LIL1lLiIli.f26285ILl.liIli(com.google.firebase.firestore.model.ILLl.iilli(uid)), firebaseFirestore);
                        com.google.firebase.firestore.model.ILLl iLLl = (com.google.firebase.firestore.model.ILLl) iLVarIii1lill1.f26338liIli.f26521ilI11.liIli(com.google.firebase.firestore.model.ILLl.iilli("keymaps"));
                        List list2 = iLLl.f26478ilI11;
                        FirebaseFirestore firebaseFirestore2 = iLVarIii1lill1.f26337Iii1lill1;
                        com.google.firebase.firestore.core.Ll1LIL1l ll1LIL1lLiIli2 = com.google.firebase.firestore.core.Ll1LIL1l.liIli(iLLl);
                        firebaseFirestore2.getClass();
                        if (list2.size() % 2 != 1) {
                            throw new IllegalArgumentException("Invalid collection reference. Collection references must have an odd number of segments, but " + iLLl.ILl() + " has " + list2.size());
                        }
                        ii1l1lll.ilI1.lI(str2, "Provided document path must not be null.");
                        com.google.firebase.firestore.iL iLVarIii1lill2 = com.google.firebase.firestore.iL.Iii1lill1((com.google.firebase.firestore.model.ILLl) ll1LIL1lLiIli2.f26285ILl.liIli(com.google.firebase.firestore.model.ILLl.iilli(str2)), firebaseFirestore2);
                        Source source = Source.DEFAULT;
                        if (source == Source.CACHE) {
                            iIi1il iii1il = iLVarIii1lill2.f26337Iii1lill1.f26203il1;
                            synchronized (iii1il) {
                                iii1il.lLliL();
                                com.google.firebase.firestore.core.IiI1l iiI1l = (com.google.firebase.firestore.core.IiI1l) iii1il.f22275lLL1L111l;
                                com.google.firebase.firestore.model.iL iLVar2 = iLVarIii1lill2.f26338liIli;
                                iiI1l.Ilil11ILI();
                                taskContinueWith = iiI1l.f26249lILlii1L.liIli(new com.google.firebase.firestore.core.LI1Il(iiI1l, iLVar2, 0)).continueWith(new com.google.firebase.firestore.Il1iLli(2));
                            }
                            task = taskContinueWith.continueWith(Il1ii.Il1iLli.f1802Iii1lill1, new com.google.firebase.firestore.lILlii1L(iLVarIii1lill2, 0));
                        } else {
                            TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
                            TaskCompletionSource taskCompletionSource2 = new TaskCompletionSource();
                            com.google.android.gms.measurement.internal.ilILLii ilillii = new com.google.android.gms.measurement.internal.ilILLii();
                            ilillii.f23223liIli = true;
                            ilillii.f23220Iii1lill1 = true;
                            ilillii.f23221Ilil11ILI = true;
                            taskCompletionSource2.setResult(iLVarIii1lill2.liIli(Il1ii.Il1iLli.f1802Iii1lill1, ilillii, new com.google.firebase.firestore.Iii(taskCompletionSource, taskCompletionSource2, source, 0)));
                            task = taskCompletionSource.getTask();
                        }
                    } else {
                        task = iILliI1I1.iL.Iii1lill1("Cloud sync subscription is required");
                    }
                } else {
                    task = iILliI1I1.iL.Iii1lill1("Cloud sync subscription is required");
                }
            }
        }
        task.addOnCompleteListener(new lli11(this, 2));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.io.Closeable] */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) throws Throwable {
        ?? r0;
        OutputStream outputStreamOpenOutputStream;
        InputStream inputStreamOpenInputStream;
        super.onActivityResult(i, i2, intent);
        if (i == 3 && i2 == -1) {
            ilI1LL ili1ll = this.f7916IlLi;
            if (ili1ll != null) {
                lIIl(this.f7918i1LIiLLl, ili1ll);
                return;
            }
            return;
        }
        InputStream inputStreamOpenInputStream2 = null;
        if (i == 1 && i2 == -1) {
            Uri data = intent.getData();
            try {
                try {
                    inputStreamOpenInputStream = getContentResolver().openInputStream(Uri.fromFile(this.f7919iLLL));
                    try {
                        outputStreamOpenOutputStream = getContentResolver().openOutputStream(data);
                        try {
                            byte[] bArr = new byte[4096];
                            while (true) {
                                int i3 = inputStreamOpenInputStream.read(bArr);
                                if (i3 == -1) {
                                    break;
                                } else {
                                    outputStreamOpenOutputStream.write(bArr, 0, i3);
                                }
                            }
                            Toast.makeText(this, "Game keymaps saved successfully!", 0).show();
                        } catch (Exception e) {
                            e = e;
                            e.printStackTrace();
                        }
                    } catch (Exception e2) {
                        e = e2;
                        outputStreamOpenOutputStream = null;
                    } catch (Throwable th) {
                        th = th;
                        data = null;
                        inputStreamOpenInputStream2 = inputStreamOpenInputStream;
                        r0 = data;
                        llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream2);
                        llL1i.Iii1lill1.lILlii1L(r0);
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                }
            } catch (Exception e3) {
                e = e3;
                outputStreamOpenOutputStream = null;
                inputStreamOpenInputStream = null;
            } catch (Throwable th3) {
                th = th3;
                r0 = 0;
                llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream2);
                llL1i.Iii1lill1.lILlii1L(r0);
                throw th;
            }
            llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream);
            llL1i.Iii1lill1.lILlii1L(outputStreamOpenOutputStream);
        }
        if (i == 2 && i2 == -1) {
            try {
                inputStreamOpenInputStream2 = getContentResolver().openInputStream(intent.getData());
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] bArr2 = new byte[100];
                while (true) {
                    int i4 = inputStreamOpenInputStream2.read(bArr2, 0, 100);
                    if (i4 <= 0) {
                        break;
                    } else {
                        byteArrayOutputStream.write(bArr2, 0, i4);
                    }
                }
                l1LLlI(new String(byteArrayOutputStream.toByteArray()));
            } catch (Throwable th4) {
                try {
                    Toast.makeText(this, "Imported keymap json is invalid!", 0).show();
                    th4.printStackTrace();
                } finally {
                    llL1i.Iii1lill1.lILlii1L(inputStreamOpenInputStream2);
                }
            }
        }
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(com.panda.mouse.R.layout.activity_keymaps);
        final int i = 0;
        ((ImageView) findViewById(com.panda.mouse.R.id.image_back)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.Ill1iI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ KeymapsActivity f7911IiiiL;

            {
                this.f7911IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                KeymapsActivity keymapsActivity = this.f7911IiiiL;
                switch (i2) {
                    case 0:
                        boolean z = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 1:
                        boolean z2 = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 2:
                        boolean z3 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        long jElapsedRealtime = SystemClock.elapsedRealtime();
                        int i3 = keymapsActivity.II;
                        if (i3 != 0 && jElapsedRealtime - keymapsActivity.f7921lii1 <= 5000) {
                            int i4 = i3 + 1;
                            keymapsActivity.II = i4;
                            if (i4 >= 7) {
                                keymapsActivity.II = 0;
                                boolean z4 = KeymapsActivity.f7913LLi;
                                KeymapsActivity.f7913LLi = !z4;
                                if (z4) {
                                    KeymapsActivity.f7914lIllIIiI = null;
                                }
                                Toast.makeText(keymapsActivity, !z4 ? "Operator mode enabled." : "Operator mode disabled.", 0).show();
                            }
                        } else {
                            keymapsActivity.f7921lii1 = jElapsedRealtime;
                            keymapsActivity.II = 1;
                        }
                        break;
                    default:
                        boolean z5 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        keymapsActivity.startActivity(new Intent(keymapsActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                }
            }
        });
        final int i2 = 1;
        ((TextView) findViewById(com.panda.mouse.R.id.text_title)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.Ill1iI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ KeymapsActivity f7911IiiiL;

            {
                this.f7911IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                KeymapsActivity keymapsActivity = this.f7911IiiiL;
                switch (i3) {
                    case 0:
                        boolean z = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 1:
                        boolean z2 = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 2:
                        boolean z3 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        long jElapsedRealtime = SystemClock.elapsedRealtime();
                        int i4 = keymapsActivity.II;
                        if (i4 != 0 && jElapsedRealtime - keymapsActivity.f7921lii1 <= 5000) {
                            int i5 = i4 + 1;
                            keymapsActivity.II = i5;
                            if (i5 >= 7) {
                                keymapsActivity.II = 0;
                                boolean z4 = KeymapsActivity.f7913LLi;
                                KeymapsActivity.f7913LLi = !z4;
                                if (z4) {
                                    KeymapsActivity.f7914lIllIIiI = null;
                                }
                                Toast.makeText(keymapsActivity, !z4 ? "Operator mode enabled." : "Operator mode disabled.", 0).show();
                            }
                        } else {
                            keymapsActivity.f7921lii1 = jElapsedRealtime;
                            keymapsActivity.II = 1;
                        }
                        break;
                    default:
                        boolean z5 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        keymapsActivity.startActivity(new Intent(keymapsActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                }
            }
        });
        final int i3 = 2;
        findViewById(com.panda.mouse.R.id.text_exported_tip).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.Ill1iI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ KeymapsActivity f7911IiiiL;

            {
                this.f7911IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                KeymapsActivity keymapsActivity = this.f7911IiiiL;
                switch (i4) {
                    case 0:
                        boolean z = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 1:
                        boolean z2 = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 2:
                        boolean z3 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        long jElapsedRealtime = SystemClock.elapsedRealtime();
                        int i5 = keymapsActivity.II;
                        if (i5 != 0 && jElapsedRealtime - keymapsActivity.f7921lii1 <= 5000) {
                            int i6 = i5 + 1;
                            keymapsActivity.II = i6;
                            if (i6 >= 7) {
                                keymapsActivity.II = 0;
                                boolean z4 = KeymapsActivity.f7913LLi;
                                KeymapsActivity.f7913LLi = !z4;
                                if (z4) {
                                    KeymapsActivity.f7914lIllIIiI = null;
                                }
                                Toast.makeText(keymapsActivity, !z4 ? "Operator mode enabled." : "Operator mode disabled.", 0).show();
                            }
                        } else {
                            keymapsActivity.f7921lii1 = jElapsedRealtime;
                            keymapsActivity.II = 1;
                        }
                        break;
                    default:
                        boolean z5 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        keymapsActivity.startActivity(new Intent(keymapsActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                }
            }
        });
        final int i4 = 3;
        ((ImageView) findViewById(com.panda.mouse.R.id.text_account)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.Ill1iI1

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ KeymapsActivity f7911IiiiL;

            {
                this.f7911IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                KeymapsActivity keymapsActivity = this.f7911IiiiL;
                switch (i5) {
                    case 0:
                        boolean z = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 1:
                        boolean z2 = KeymapsActivity.f7913LLi;
                        keymapsActivity.finish();
                        break;
                    case 2:
                        boolean z3 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        long jElapsedRealtime = SystemClock.elapsedRealtime();
                        int i6 = keymapsActivity.II;
                        if (i6 != 0 && jElapsedRealtime - keymapsActivity.f7921lii1 <= 5000) {
                            int i7 = i6 + 1;
                            keymapsActivity.II = i7;
                            if (i7 >= 7) {
                                keymapsActivity.II = 0;
                                boolean z4 = KeymapsActivity.f7913LLi;
                                KeymapsActivity.f7913LLi = !z4;
                                if (z4) {
                                    KeymapsActivity.f7914lIllIIiI = null;
                                }
                                Toast.makeText(keymapsActivity, !z4 ? "Operator mode enabled." : "Operator mode disabled.", 0).show();
                            }
                        } else {
                            keymapsActivity.f7921lii1 = jElapsedRealtime;
                            keymapsActivity.II = 1;
                        }
                        break;
                    default:
                        boolean z5 = KeymapsActivity.f7913LLi;
                        keymapsActivity.getClass();
                        keymapsActivity.startActivity(new Intent(keymapsActivity, (Class<?>) CloudAccountActivity.class));
                        break;
                }
            }
        });
        this.f7915II1 = (RecyclerView) findViewById(com.panda.mouse.R.id.recycler_view);
        com.google.firebase.crashlytics.internal.common.li1.il1().getClass();
        ListAppAdapter listAppAdapter = new ListAppAdapter(com.google.firebase.crashlytics.internal.common.li1.iI1());
        this.f7917Li = listAppAdapter;
        listAppAdapter.f7957liIli = 2;
        this.f7915II1.setLayoutManager(new LinearLayoutManager());
        this.f7915II1.setAdapter(this.f7917Li);
        this.f7917Li.setOnItemChildClickListener(new lli11(this, 0));
        BaseActivity.Il1iLli(findViewById(com.panda.mouse.R.id.id_toolbar_layout), findViewById(com.panda.mouse.R.id.id_root_layout));
    }
}
