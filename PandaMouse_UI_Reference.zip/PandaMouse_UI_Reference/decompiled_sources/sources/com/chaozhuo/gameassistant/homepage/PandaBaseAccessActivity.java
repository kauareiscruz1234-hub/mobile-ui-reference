package com.chaozhuo.gameassistant.homepage;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.homepage.helper.PandaApiClient$ApiException;
import com.panda.mouse.R;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class PandaBaseAccessActivity extends BaseActivity {
    public static final /* synthetic */ int iiIL1liI = 0;
    public TextView I1Ii1IilI;
    public final ExecutorService II = Executors.newSingleThreadExecutor();

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public EditText f7937II1;

    /* JADX INFO: renamed from: IIiiI, reason: collision with root package name */
    public View f7938IIiiI;
    public LinearLayout IIlII;

    /* JADX INFO: renamed from: IlLi, reason: collision with root package name */
    public View f7939IlLi;

    /* JADX INFO: renamed from: LLIi, reason: collision with root package name */
    public boolean f7940LLIi;

    /* JADX INFO: renamed from: LLi, reason: collision with root package name */
    public TextView f7941LLi;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public TextView f7942Li;

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public View f7943i1LIiLLl;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public View f7944iLLL;
    public View iilL1Ll;

    /* JADX INFO: renamed from: ilL, reason: collision with root package name */
    public View f7945ilL;

    /* JADX INFO: renamed from: ill, reason: collision with root package name */
    public TextView f7946ill;

    /* JADX INFO: renamed from: lIL, reason: collision with root package name */
    public View f7947lIL;

    /* JADX INFO: renamed from: lIllIIiI, reason: collision with root package name */
    public TextView f7948lIllIIiI;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public TextView f7949lLiLIli;

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public EditText f7950lii1;

    public static String ii1(String str) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = simpleDateFormat.parse(str);
            return date == null ? str : DateFormat.getDateInstance(2).format(date);
        } catch (Exception unused) {
            return str;
        }
    }

    public final void I1lI111LL(boolean z) {
        runOnUiThread(new iL(3, this, z));
    }

    public final String IL() {
        String strTrim = this.f7950lii1.getText() == null ? "" : this.f7950lii1.getText().toString().trim();
        if (!TextUtils.isEmpty(strTrim) && strTrim.contains("@")) {
            return strTrim;
        }
        iLLLiIl1(R.string.web_purchase_invalid_email);
        return null;
    }

    public final String L1i11iI(PandaApiClient$ApiException pandaApiClient$ApiException) {
        String str = pandaApiClient$ApiException.code;
        str.getClass();
        switch (str) {
            case "CODE_SEND_TOO_FREQUENT":
                return getString(R.string.web_purchase_code_request_too_frequent);
            case "INVALID_CODE":
            case "CODE_EXPIRED":
                return getString(R.string.web_purchase_code_invalid_or_expired);
            case "UNAUTHORIZED":
                return getString(R.string.web_purchase_session_expired);
            case "CODE_ATTEMPTS_EXCEEDED":
                return getString(R.string.web_purchase_code_attempts_exceeded);
            case "INVALID_EMAIL":
                return getString(R.string.web_purchase_invalid_email);
            case "EMAIL_CODE_DAILY_LIMIT_EXCEEDED":
            case "IP_CODE_HOURLY_LIMIT_EXCEEDED":
            case "IP_CODE_DAILY_LIMIT_EXCEEDED":
                return getString(R.string.web_purchase_code_request_limit);
            case "DEVICE_NOT_FOUND":
            case "DEVICE_ID_REQUIRED":
            case "INVALID_DEVICE_RECORD_ID":
                return getString(R.string.panda_access_device_request_failed);
            case "APP_ID_REQUIRED":
            case "INVALID_APP":
            case "PADDLE_PRICE_NOT_CONFIGURED":
                return getString(R.string.web_purchase_purchase_unavailable);
            case "EMAIL_SEND_FAILED":
                return getString(R.string.web_purchase_email_send_failed);
            default:
                if (pandaApiClient$ApiException.status >= 500) {
                    return getString(R.string.web_purchase_request_failed);
                }
                return pandaApiClient$ApiException.code + ": " + pandaApiClient$ApiException.getMessage();
        }
    }

    public final void Ll1LIL1l() {
        this.f7942Li.setText(R.string.web_purchase_not_signed_in);
        ilI1(true);
        this.I1Ii1IilI.setEnabled(false);
        this.I1Ii1IilI.setAlpha(0.45f);
        this.f7938IIiiI.setVisibility(8);
    }

    public final void iLLLiIl1(int i) {
        this.f7949lLiLIli.setText(getString(i));
    }

    public final void ilI1(boolean z) {
        this.f7947lIL.setVisibility(z ? 0 : 8);
        this.f7945ilL.setVisibility(z ? 8 : 0);
        this.iilL1Ll.setVisibility(z ? 8 : 0);
    }

    public final void l1LLlI() {
        if (TextUtils.isEmpty(getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null))) {
            Ll1LIL1l();
            return;
        }
        I1lI111LL(true);
        iilli iilliVar = new iilli(this, 1);
        ExecutorService executorService = iILliI1I1.lLliL.f28431liIli;
        Context applicationContext = getApplicationContext();
        String string = applicationContext.getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null);
        if (!TextUtils.isEmpty(string)) {
            iILliI1I1.lLliL.f28431liIli.execute(new p016Il.IiI1l(applicationContext, 14, string, iilliVar));
        } else {
            com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.ILl(false);
            iILliI1I1.lLliL.liIli(iilliVar, new iILliI1I1.iI1(false, false, "not_entitled", null, 2, Collections.EMPTY_LIST), null);
        }
    }

    public final void lIIl(IIiiLl1I iIiiLl1I) {
        I1lI111LL(true);
        this.II.execute(new Il1ii.Ilil11ILI(14, this, iIiiLl1I));
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_panda_base_access);
        final int i = 0;
        findViewById(R.id.image_back).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.LL1ili1lI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ PandaBaseAccessActivity f7929IiiiL;

            {
                this.f7929IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                final int i3 = 1;
                final int i4 = 0;
                final PandaBaseAccessActivity pandaBaseAccessActivity = this.f7929IiiiL;
                switch (i2) {
                    case 0:
                        int i5 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.finish();
                        break;
                    case 1:
                        int i6 = PandaBaseAccessActivity.iiIL1liI;
                        final String strIL = pandaBaseAccessActivity.IL();
                        if (strIL != null) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i7 = i3;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i7) {
                                        case 0:
                                            int i8 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", strIL, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i9 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", strIL);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                            break;
                        }
                        break;
                    case 2:
                        int i7 = PandaBaseAccessActivity.iiIL1liI;
                        String strIL2 = pandaBaseAccessActivity.IL();
                        if (strIL2 != null) {
                            String strTrim = pandaBaseAccessActivity.f7937II1.getText() == null ? "" : pandaBaseAccessActivity.f7937II1.getText().toString().trim();
                            if (strTrim.length() == 6) {
                                pandaBaseAccessActivity.lIIl(new l1lIi(pandaBaseAccessActivity, strIL2, strTrim, i3));
                            } else {
                                pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_invalid_code);
                            }
                            break;
                        }
                        break;
                    case 3:
                        int i8 = PandaBaseAccessActivity.iiIL1liI;
                        final String string = pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null);
                        if (!TextUtils.isEmpty(string)) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i9 = i4;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i9) {
                                        case 0:
                                            int i10 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", string, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i11 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", string);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                        } else {
                            pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_login_required);
                        }
                        break;
                    default:
                        int i9 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).edit().clear().apply();
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.ILl(false);
                        pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_signed_out);
                        pandaBaseAccessActivity.Ll1LIL1l();
                        break;
                }
            }
        });
        this.f7950lii1 = (EditText) findViewById(R.id.edit_email);
        this.f7937II1 = (EditText) findViewById(R.id.edit_code);
        this.f7942Li = (TextView) findViewById(R.id.text_account_status);
        this.f7949lLiLIli = (TextView) findViewById(R.id.text_result);
        this.f7944iLLL = findViewById(R.id.progress);
        this.f7943i1LIiLLl = findViewById(R.id.button_send_code);
        this.f7939IlLi = findViewById(R.id.button_login);
        this.I1Ii1IilI = (TextView) findViewById(R.id.button_buy_base);
        this.f7941LLi = (TextView) findViewById(R.id.text_access_status);
        this.f7948lIllIIiI = (TextView) findViewById(R.id.text_access_expiry);
        this.f7938IIiiI = findViewById(R.id.button_logout);
        this.f7947lIL = findViewById(R.id.layout_login_card);
        this.f7945ilL = findViewById(R.id.layout_access_card);
        this.iilL1Ll = findViewById(R.id.layout_devices_card);
        this.f7946ill = (TextView) findViewById(R.id.text_devices_description);
        this.IIlII = (LinearLayout) findViewById(R.id.layout_devices);
        String string = getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("email", null);
        if (!TextUtils.isEmpty(string)) {
            this.f7950lii1.setText(string);
        }
        final int i2 = 1;
        this.f7943i1LIiLLl.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.LL1ili1lI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ PandaBaseAccessActivity f7929IiiiL;

            {
                this.f7929IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                final int i4 = 1;
                final int i5 = 0;
                final PandaBaseAccessActivity pandaBaseAccessActivity = this.f7929IiiiL;
                switch (i3) {
                    case 0:
                        int i6 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.finish();
                        break;
                    case 1:
                        int i7 = PandaBaseAccessActivity.iiIL1liI;
                        final String strIL = pandaBaseAccessActivity.IL();
                        if (strIL != null) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i9 = i4;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i9) {
                                        case 0:
                                            int i10 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", strIL, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i11 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", strIL);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                            break;
                        }
                        break;
                    case 2:
                        int i8 = PandaBaseAccessActivity.iiIL1liI;
                        String strIL2 = pandaBaseAccessActivity.IL();
                        if (strIL2 != null) {
                            String strTrim = pandaBaseAccessActivity.f7937II1.getText() == null ? "" : pandaBaseAccessActivity.f7937II1.getText().toString().trim();
                            if (strTrim.length() == 6) {
                                pandaBaseAccessActivity.lIIl(new l1lIi(pandaBaseAccessActivity, strIL2, strTrim, i4));
                            } else {
                                pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_invalid_code);
                            }
                            break;
                        }
                        break;
                    case 3:
                        int i9 = PandaBaseAccessActivity.iiIL1liI;
                        final String string2 = pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null);
                        if (!TextUtils.isEmpty(string2)) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i10 = i5;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i10) {
                                        case 0:
                                            int i11 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", string2, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i12 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", string2);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                        } else {
                            pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_login_required);
                        }
                        break;
                    default:
                        int i10 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).edit().clear().apply();
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.ILl(false);
                        pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_signed_out);
                        pandaBaseAccessActivity.Ll1LIL1l();
                        break;
                }
            }
        });
        final int i3 = 2;
        this.f7939IlLi.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.LL1ili1lI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ PandaBaseAccessActivity f7929IiiiL;

            {
                this.f7929IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                final int i5 = 1;
                final int i6 = 0;
                final PandaBaseAccessActivity pandaBaseAccessActivity = this.f7929IiiiL;
                switch (i4) {
                    case 0:
                        int i7 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.finish();
                        break;
                    case 1:
                        int i8 = PandaBaseAccessActivity.iiIL1liI;
                        final String strIL = pandaBaseAccessActivity.IL();
                        if (strIL != null) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i10 = i5;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i10) {
                                        case 0:
                                            int i11 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", strIL, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i12 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", strIL);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                            break;
                        }
                        break;
                    case 2:
                        int i9 = PandaBaseAccessActivity.iiIL1liI;
                        String strIL2 = pandaBaseAccessActivity.IL();
                        if (strIL2 != null) {
                            String strTrim = pandaBaseAccessActivity.f7937II1.getText() == null ? "" : pandaBaseAccessActivity.f7937II1.getText().toString().trim();
                            if (strTrim.length() == 6) {
                                pandaBaseAccessActivity.lIIl(new l1lIi(pandaBaseAccessActivity, strIL2, strTrim, i5));
                            } else {
                                pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_invalid_code);
                            }
                            break;
                        }
                        break;
                    case 3:
                        int i10 = PandaBaseAccessActivity.iiIL1liI;
                        final String string2 = pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null);
                        if (!TextUtils.isEmpty(string2)) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i11 = i6;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i11) {
                                        case 0:
                                            int i12 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", string2, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i13 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", string2);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                        } else {
                            pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_login_required);
                        }
                        break;
                    default:
                        int i11 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).edit().clear().apply();
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.ILl(false);
                        pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_signed_out);
                        pandaBaseAccessActivity.Ll1LIL1l();
                        break;
                }
            }
        });
        final int i4 = 3;
        this.I1Ii1IilI.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.LL1ili1lI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ PandaBaseAccessActivity f7929IiiiL;

            {
                this.f7929IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                final int i6 = 1;
                final int i7 = 0;
                final PandaBaseAccessActivity pandaBaseAccessActivity = this.f7929IiiiL;
                switch (i5) {
                    case 0:
                        int i8 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.finish();
                        break;
                    case 1:
                        int i9 = PandaBaseAccessActivity.iiIL1liI;
                        final String strIL = pandaBaseAccessActivity.IL();
                        if (strIL != null) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i11 = i6;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i11) {
                                        case 0:
                                            int i12 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", strIL, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i13 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", strIL);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                            break;
                        }
                        break;
                    case 2:
                        int i10 = PandaBaseAccessActivity.iiIL1liI;
                        String strIL2 = pandaBaseAccessActivity.IL();
                        if (strIL2 != null) {
                            String strTrim = pandaBaseAccessActivity.f7937II1.getText() == null ? "" : pandaBaseAccessActivity.f7937II1.getText().toString().trim();
                            if (strTrim.length() == 6) {
                                pandaBaseAccessActivity.lIIl(new l1lIi(pandaBaseAccessActivity, strIL2, strTrim, i6));
                            } else {
                                pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_invalid_code);
                            }
                            break;
                        }
                        break;
                    case 3:
                        int i11 = PandaBaseAccessActivity.iiIL1liI;
                        final String string2 = pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null);
                        if (!TextUtils.isEmpty(string2)) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i12 = i7;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i12) {
                                        case 0:
                                            int i13 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", string2, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i14 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", string2);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                        } else {
                            pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_login_required);
                        }
                        break;
                    default:
                        int i12 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).edit().clear().apply();
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.ILl(false);
                        pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_signed_out);
                        pandaBaseAccessActivity.Ll1LIL1l();
                        break;
                }
            }
        });
        final int i5 = 4;
        this.f7938IIiiI.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.LL1ili1lI

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ PandaBaseAccessActivity f7929IiiiL;

            {
                this.f7929IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i6 = i5;
                final int i7 = 1;
                final int i8 = 0;
                final PandaBaseAccessActivity pandaBaseAccessActivity = this.f7929IiiiL;
                switch (i6) {
                    case 0:
                        int i9 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.finish();
                        break;
                    case 1:
                        int i10 = PandaBaseAccessActivity.iiIL1liI;
                        final String strIL = pandaBaseAccessActivity.IL();
                        if (strIL != null) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i12 = i7;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i12) {
                                        case 0:
                                            int i13 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", strIL, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i14 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", strIL);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                            break;
                        }
                        break;
                    case 2:
                        int i11 = PandaBaseAccessActivity.iiIL1liI;
                        String strIL2 = pandaBaseAccessActivity.IL();
                        if (strIL2 != null) {
                            String strTrim = pandaBaseAccessActivity.f7937II1.getText() == null ? "" : pandaBaseAccessActivity.f7937II1.getText().toString().trim();
                            if (strTrim.length() == 6) {
                                pandaBaseAccessActivity.lIIl(new l1lIi(pandaBaseAccessActivity, strIL2, strTrim, i7));
                            } else {
                                pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_invalid_code);
                            }
                            break;
                        }
                        break;
                    case 3:
                        int i12 = PandaBaseAccessActivity.iiIL1liI;
                        final String string2 = pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null);
                        if (!TextUtils.isEmpty(string2)) {
                            pandaBaseAccessActivity.lIIl(new IIiiLl1I() { // from class: com.chaozhuo.gameassistant.homepage.li1l
                                @Override // com.chaozhuo.gameassistant.homepage.IIiiLl1I
                                public final void run() throws JSONException {
                                    int i13 = i8;
                                    PandaBaseAccessActivity pandaBaseAccessActivity2 = pandaBaseAccessActivity;
                                    switch (i13) {
                                        case 0:
                                            int i14 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject = new JSONObject();
                                            jSONObject.put("appId", "panda_mouse_pro");
                                            String strOptString = iILliI1I1.LI1Il.Liii1("POST", "/fastspring/checkout/session", string2, jSONObject, null, null).optString("checkoutUrl");
                                            if (TextUtils.isEmpty(strOptString)) {
                                                throw new IllegalStateException("Checkout response does not contain checkoutUrl");
                                            }
                                            pandaBaseAccessActivity2.runOnUiThread(new lILil(pandaBaseAccessActivity2, strOptString, 1));
                                            return;
                                        default:
                                            int i15 = PandaBaseAccessActivity.iiIL1liI;
                                            JSONObject jSONObject2 = new JSONObject();
                                            jSONObject2.put("email", string2);
                                            jSONObject2.put("purpose", "login");
                                            iILliI1I1.LI1Il.Liii1("POST", "/auth/email/code", null, jSONObject2, null, null);
                                            pandaBaseAccessActivity2.runOnUiThread(new IilIl(pandaBaseAccessActivity2, 2));
                                            return;
                                    }
                                }
                            });
                        } else {
                            pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_login_required);
                        }
                        break;
                    default:
                        int i13 = PandaBaseAccessActivity.iiIL1liI;
                        pandaBaseAccessActivity.getApplicationContext().getSharedPreferences("panda_api_session", 0).edit().clear().apply();
                        iILliI1I1.iL.f28422Ilil11ILI.f28424liIli.Iii();
                        com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL.ILl(false);
                        pandaBaseAccessActivity.iLLLiIl1(R.string.web_purchase_signed_out);
                        pandaBaseAccessActivity.Ll1LIL1l();
                        break;
                }
            }
        });
        if (TextUtils.isEmpty(getApplicationContext().getSharedPreferences("panda_api_session", 0).getString("token", null))) {
            Ll1LIL1l();
        } else {
            this.f7942Li.setText("");
            this.f7949lLiLIli.setText("");
            this.f7947lIL.setVisibility(8);
            this.f7945ilL.setVisibility(8);
            this.iilL1Ll.setVisibility(8);
            this.f7938IIiiI.setVisibility(8);
            I1lI111LL(true);
            l1LLlI();
        }
        BaseActivity.Il1iLli(findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_root_layout));
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onDestroy() {
        this.II.shutdownNow();
        super.onDestroy();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public final void onResume() {
        super.onResume();
        if (this.f7940LLIi) {
            this.f7940LLIi = false;
            l1LLlI();
        }
    }
}
