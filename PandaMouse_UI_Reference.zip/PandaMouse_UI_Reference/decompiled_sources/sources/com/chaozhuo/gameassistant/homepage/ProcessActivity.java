package com.chaozhuo.gameassistant.homepage;

import android.app.ActivityManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.XApp;
import com.chaozhuo.gameassistant.homepage.adapter.ListAppAdapter;
import com.chaozhuo.gameassistant.ipc.handler.HSHandler;
import com.github.ybq.android.spinkit.SpinKitView;
import com.panda.mouse.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import p047iIiii.ilI1LL;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ProcessActivity extends BaseActivity implements com.chaozhuo.gameassistant.czkeymap.Ll1LIL1l {

    /* JADX INFO: renamed from: i1LIiLLl, reason: collision with root package name */
    public static final /* synthetic */ int f7951i1LIiLLl = 0;
    public ImageView II;

    /* JADX INFO: renamed from: II1, reason: collision with root package name */
    public RecyclerView f7952II1;

    /* JADX INFO: renamed from: Li, reason: collision with root package name */
    public ListAppAdapter f7953Li;

    /* JADX INFO: renamed from: iLLL, reason: collision with root package name */
    public SpinKitView f7954iLLL;

    /* JADX INFO: renamed from: lLiLIli, reason: collision with root package name */
    public final ArrayList f7955lLiLIli = new ArrayList();

    /* JADX INFO: renamed from: lii1, reason: collision with root package name */
    public ImageView f7956lii1;

    public final void IL(List list) {
        ArrayList arrayList = this.f7955lLiLIli;
        arrayList.clear();
        if (list != null) {
            Collections.sort(list, new Il1ii.iLLLiIl1(4));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                ActivityManager.RunningAppProcessInfo runningAppProcessInfo = (ActivityManager.RunningAppProcessInfo) it.next();
                if (!TextUtils.equals(runningAppProcessInfo.pkgList[0], XApp.f7417IiiiL.getPackageName())) {
                    com.google.firebase.crashlytics.internal.common.li1 li1VarIl1 = com.google.firebase.crashlytics.internal.common.li1.il1();
                    String str = runningAppProcessInfo.pkgList[0];
                    li1VarIl1.getClass();
                    ilI1LL ili1llLLliL = com.google.firebase.crashlytics.internal.common.li1.lLliL(str);
                    if (ili1llLLliL != null) {
                        ili1llLLliL.f28715Ilil11ILI = ((Object) ili1llLLliL.f28715Ilil11ILI) + String.format(" (%d %dMB)", Integer.valueOf(runningAppProcessInfo.pid), Integer.valueOf(runningAppProcessInfo.lastTrimLevel / 1024));
                        ili1llLLliL.f28716lILlii1L = runningAppProcessInfo.processName;
                        arrayList.add(ili1llLLliL);
                    } else if (liIli.liIli.f33010ilI11) {
                        liIli.liIli.LI1lllLl("ProcessActivity", "onGotProcessInfo getAppInfo failed: pid=", Integer.valueOf(runningAppProcessInfo.pid), ", processName=", runningAppProcessInfo.processName, ", packageName=", runningAppProcessInfo.pkgList[0]);
                    }
                }
            }
            this.f7953Li.setNewData(arrayList);
        }
        this.f7954iLLL.setVisibility(8);
    }

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_process);
        final int i = 0;
        ((ImageView) findViewById(R.id.image_back)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.iiiil

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ProcessActivity f7971IiiiL;

            {
                this.f7971IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                ProcessActivity processActivity = this.f7971IiiiL;
                switch (i2) {
                    case 0:
                        int i3 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 1:
                        int i4 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 2:
                        processActivity.f7954iLLL.setVisibility(0);
                        LiLLli.liIli.f3480liIli.postDelayed(new lILlii1L(1), 1000L);
                        break;
                    default:
                        int i5 = ProcessActivity.f7951i1LIiLLl;
                        HashSet hashSet = new HashSet();
                        ArrayList arrayList = processActivity.f7955lLiLIli;
                        int size = arrayList.size();
                        int i6 = 0;
                        while (i6 < size) {
                            Object obj = arrayList.get(i6);
                            i6++;
                            ilI1LL ili1ll = (ilI1LL) obj;
                            if (ili1ll.f28713ILl) {
                                hashSet.add(ili1ll.f28717liIli);
                            }
                        }
                        if (!hashSet.isEmpty()) {
                            processActivity.f7954iLLL.setVisibility(0);
                            StringBuilder sb = new StringBuilder("echo ");
                            Iterator it = hashSet.iterator();
                            while (it.hasNext()) {
                                sb.append((String) it.next());
                                sb.append(" ");
                            }
                            sb.append("| xargs -n 1 am force-stop");
                            com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1.Iii1lill1(sb.toString(), new ilILLii());
                            break;
                        }
                        break;
                }
            }
        });
        final int i2 = 1;
        ((TextView) findViewById(R.id.text_title)).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.iiiil

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ProcessActivity f7971IiiiL;

            {
                this.f7971IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                ProcessActivity processActivity = this.f7971IiiiL;
                switch (i3) {
                    case 0:
                        int i4 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 1:
                        int i5 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 2:
                        processActivity.f7954iLLL.setVisibility(0);
                        LiLLli.liIli.f3480liIli.postDelayed(new lILlii1L(1), 1000L);
                        break;
                    default:
                        int i6 = ProcessActivity.f7951i1LIiLLl;
                        HashSet hashSet = new HashSet();
                        ArrayList arrayList = processActivity.f7955lLiLIli;
                        int size = arrayList.size();
                        int i7 = 0;
                        while (i7 < size) {
                            Object obj = arrayList.get(i7);
                            i7++;
                            ilI1LL ili1ll = (ilI1LL) obj;
                            if (ili1ll.f28713ILl) {
                                hashSet.add(ili1ll.f28717liIli);
                            }
                        }
                        if (!hashSet.isEmpty()) {
                            processActivity.f7954iLLL.setVisibility(0);
                            StringBuilder sb = new StringBuilder("echo ");
                            Iterator it = hashSet.iterator();
                            while (it.hasNext()) {
                                sb.append((String) it.next());
                                sb.append(" ");
                            }
                            sb.append("| xargs -n 1 am force-stop");
                            com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1.Iii1lill1(sb.toString(), new ilILLii());
                            break;
                        }
                        break;
                }
            }
        });
        this.II = (ImageView) findViewById(R.id.id_reload);
        this.f7956lii1 = (ImageView) findViewById(R.id.id_terminate);
        this.f7952II1 = (RecyclerView) findViewById(R.id.recycler_view);
        ListAppAdapter listAppAdapter = new ListAppAdapter(this.f7955lLiLIli);
        this.f7953Li = listAppAdapter;
        listAppAdapter.f7957liIli = 3;
        this.f7952II1.setLayoutManager(new LinearLayoutManager());
        this.f7952II1.setAdapter(this.f7953Li);
        final int i3 = 2;
        this.f7953Li.setOnItemChildClickListener(new iilli(this, i3));
        this.f7954iLLL = (SpinKitView) findViewById(R.id.id_spin_kit);
        this.II.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.iiiil

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ProcessActivity f7971IiiiL;

            {
                this.f7971IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                ProcessActivity processActivity = this.f7971IiiiL;
                switch (i4) {
                    case 0:
                        int i5 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 1:
                        int i6 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 2:
                        processActivity.f7954iLLL.setVisibility(0);
                        LiLLli.liIli.f3480liIli.postDelayed(new lILlii1L(1), 1000L);
                        break;
                    default:
                        int i7 = ProcessActivity.f7951i1LIiLLl;
                        HashSet hashSet = new HashSet();
                        ArrayList arrayList = processActivity.f7955lLiLIli;
                        int size = arrayList.size();
                        int i8 = 0;
                        while (i8 < size) {
                            Object obj = arrayList.get(i8);
                            i8++;
                            ilI1LL ili1ll = (ilI1LL) obj;
                            if (ili1ll.f28713ILl) {
                                hashSet.add(ili1ll.f28717liIli);
                            }
                        }
                        if (!hashSet.isEmpty()) {
                            processActivity.f7954iLLL.setVisibility(0);
                            StringBuilder sb = new StringBuilder("echo ");
                            Iterator it = hashSet.iterator();
                            while (it.hasNext()) {
                                sb.append((String) it.next());
                                sb.append(" ");
                            }
                            sb.append("| xargs -n 1 am force-stop");
                            com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1.Iii1lill1(sb.toString(), new ilILLii());
                            break;
                        }
                        break;
                }
            }
        });
        final int i4 = 3;
        this.f7956lii1.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.iiiil

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ ProcessActivity f7971IiiiL;

            {
                this.f7971IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                ProcessActivity processActivity = this.f7971IiiiL;
                switch (i5) {
                    case 0:
                        int i6 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 1:
                        int i7 = ProcessActivity.f7951i1LIiLLl;
                        processActivity.finish();
                        break;
                    case 2:
                        processActivity.f7954iLLL.setVisibility(0);
                        LiLLli.liIli.f3480liIli.postDelayed(new lILlii1L(1), 1000L);
                        break;
                    default:
                        int i8 = ProcessActivity.f7951i1LIiLLl;
                        HashSet hashSet = new HashSet();
                        ArrayList arrayList = processActivity.f7955lLiLIli;
                        int size = arrayList.size();
                        int i9 = 0;
                        while (i9 < size) {
                            Object obj = arrayList.get(i9);
                            i9++;
                            ilI1LL ili1ll = (ilI1LL) obj;
                            if (ili1ll.f28713ILl) {
                                hashSet.add(ili1ll.f28717liIli);
                            }
                        }
                        if (!hashSet.isEmpty()) {
                            processActivity.f7954iLLL.setVisibility(0);
                            StringBuilder sb = new StringBuilder("echo ");
                            Iterator it = hashSet.iterator();
                            while (it.hasNext()) {
                                sb.append((String) it.next());
                                sb.append(" ");
                            }
                            sb.append("| xargs -n 1 am force-stop");
                            com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1.Iii1lill1(sb.toString(), new ilILLii());
                            break;
                        }
                        break;
                }
            }
        });
        BaseActivity.Il1iLli(findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_root_layout));
        com.chaozhuo.gameassistant.czkeymap.lIIl liil = com.chaozhuo.gameassistant.czkeymap.lIIl.f7582iI1;
        liil.getClass();
        liil.f7588iL = new WeakReference(this);
        liil.lILlii1L(HSHandler.MESSAGE_GET_PROCESSINFO, null);
    }
}
