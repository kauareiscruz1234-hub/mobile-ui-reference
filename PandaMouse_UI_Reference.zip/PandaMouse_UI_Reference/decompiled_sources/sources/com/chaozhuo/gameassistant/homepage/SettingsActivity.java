package com.chaozhuo.gameassistant.homepage;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import com.chaozhuo.gameassistant.BaseActivity;
import com.chaozhuo.gameassistant.XApp;
import com.panda.mouse.R;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class SettingsActivity extends BaseActivity {
    public static final /* synthetic */ int II = 0;

    @Override // com.chaozhuo.gameassistant.BaseActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public final void onCreate(Bundle bundle) {
        boolean zIll1iI1;
        boolean zLll;
        super.onCreate(bundle);
        setContentView(R.layout.activity_settings);
        BaseActivity.Il1iLli(findViewById(R.id.id_toolbar_layout), findViewById(R.id.id_root_layout));
        final int i = 0;
        findViewById(R.id.image_back).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingsActivity f7961IiiiL;

            {
                this.f7961IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = i;
                SettingsActivity settingsActivity = this.f7961IiiiL;
                switch (i2) {
                    case 0:
                        int i3 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 1:
                        int i4 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 2:
                        int i5 = SettingsActivity.II;
                        settingsActivity.getClass();
                        lLll1L.liIli.lI(settingsActivity);
                        break;
                    case 3:
                        int i6 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://pandagame.app")));
                        } catch (Exception unused) {
                            return;
                        }
                        break;
                    default:
                        int i7 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + settingsActivity.getPackageName())).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException unused2) {
                            try {
                                settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + settingsActivity.getPackageName())));
                            } catch (Exception unused3) {
                                return;
                            }
                        }
                        break;
                }
            }
        });
        final int i2 = 1;
        findViewById(R.id.text_title).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingsActivity f7961IiiiL;

            {
                this.f7961IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i3 = i2;
                SettingsActivity settingsActivity = this.f7961IiiiL;
                switch (i3) {
                    case 0:
                        int i4 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 1:
                        int i5 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 2:
                        int i6 = SettingsActivity.II;
                        settingsActivity.getClass();
                        lLll1L.liIli.lI(settingsActivity);
                        break;
                    case 3:
                        int i7 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://pandagame.app")));
                        } catch (Exception unused) {
                            return;
                        }
                        break;
                    default:
                        int i8 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + settingsActivity.getPackageName())).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException unused2) {
                            try {
                                settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + settingsActivity.getPackageName())));
                            } catch (Exception unused3) {
                                return;
                            }
                        }
                        break;
                }
            }
        });
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.id_theme_group);
        RadioButton radioButton = (RadioButton) findViewById(R.id.id_follow_system);
        RadioButton radioButton2 = (RadioButton) findViewById(R.id.id_light_mode);
        RadioButton radioButton3 = (RadioButton) findViewById(R.id.id_dark_mode);
        int iLl1Li = lLll1L.liIli.ll1Li(XApp.f7417IiiiL);
        final int i3 = 2;
        if (iLl1Li == 1) {
            radioButton2.setChecked(true);
        } else if (iLl1Li != 2) {
            radioButton.setChecked(true);
        } else {
            radioButton3.setChecked(true);
        }
        radioGroup.setOnCheckedChangeListener(new IlII());
        Switch r8 = (Switch) findViewById(R.id.grab_touchscreen_switch);
        com.chaozhuo.gameassistant.czkeymap.I1lI111LL i1lI111LL = com.chaozhuo.gameassistant.czkeymap.I1lI111LL.f7502IiiiL;
        try {
            zIll1iI1 = i1lI111LL.Iii1lill1().Ill1iI1();
        } catch (Exception unused) {
            zIll1iI1 = false;
        }
        r8.setChecked(zIll1iI1);
        r8.setEnabled(true);
        r8.setOnCheckedChangeListener(new LILllili.lILil(1));
        Switch r9 = (Switch) findViewById(R.id.touch_translated_switch);
        try {
            zLll = i1lI111LL.Iii1lill1().lll();
        } catch (Exception unused2) {
            zLll = false;
        }
        r9.setChecked(zLll);
        r9.setOnCheckedChangeListener(new LILllili.lILil(2));
        findViewById(R.id.id_background_operation).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingsActivity f7961IiiiL;

            {
                this.f7961IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i4 = i3;
                SettingsActivity settingsActivity = this.f7961IiiiL;
                switch (i4) {
                    case 0:
                        int i5 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 1:
                        int i6 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 2:
                        int i7 = SettingsActivity.II;
                        settingsActivity.getClass();
                        lLll1L.liIli.lI(settingsActivity);
                        break;
                    case 3:
                        int i8 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://pandagame.app")));
                        } catch (Exception unused3) {
                            return;
                        }
                        break;
                    default:
                        int i9 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + settingsActivity.getPackageName())).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException unused4) {
                            try {
                                settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + settingsActivity.getPackageName())));
                            } catch (Exception unused5) {
                                return;
                            }
                        }
                        break;
                }
            }
        });
        final int i4 = 3;
        findViewById(R.id.id_official_website).setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingsActivity f7961IiiiL;

            {
                this.f7961IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i5 = i4;
                SettingsActivity settingsActivity = this.f7961IiiiL;
                switch (i5) {
                    case 0:
                        int i6 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 1:
                        int i7 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 2:
                        int i8 = SettingsActivity.II;
                        settingsActivity.getClass();
                        lLll1L.liIli.lI(settingsActivity);
                        break;
                    case 3:
                        int i9 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://pandagame.app")));
                        } catch (Exception unused3) {
                            return;
                        }
                        break;
                    default:
                        int i10 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + settingsActivity.getPackageName())).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException unused4) {
                            try {
                                settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + settingsActivity.getPackageName())));
                            } catch (Exception unused5) {
                                return;
                            }
                        }
                        break;
                }
            }
        });
        ((TextView) findViewById(R.id.id_official_website_version)).setText(getString(R.string.app_version_info, p067il1.liIli.f29525ILl, Integer.valueOf(p067il1.liIli.f29528lILlii1L)));
        View viewFindViewById = findViewById(R.id.id_rate_on_google_play);
        viewFindViewById.setVisibility(0);
        findViewById(R.id.id_rate_divider).setVisibility(0);
        final int i5 = 4;
        viewFindViewById.setOnClickListener(new View.OnClickListener(this) { // from class: com.chaozhuo.gameassistant.homepage.i1L

            /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
            public final /* synthetic */ SettingsActivity f7961IiiiL;

            {
                this.f7961IiiiL = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i6 = i5;
                SettingsActivity settingsActivity = this.f7961IiiiL;
                switch (i6) {
                    case 0:
                        int i7 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 1:
                        int i8 = SettingsActivity.II;
                        settingsActivity.finish();
                        break;
                    case 2:
                        int i9 = SettingsActivity.II;
                        settingsActivity.getClass();
                        lLll1L.liIli.lI(settingsActivity);
                        break;
                    case 3:
                        int i10 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://pandagame.app")));
                        } catch (Exception unused3) {
                            return;
                        }
                        break;
                    default:
                        int i11 = SettingsActivity.II;
                        try {
                            settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + settingsActivity.getPackageName())).setPackage("com.android.vending"));
                            break;
                        } catch (ActivityNotFoundException unused4) {
                            try {
                                settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + settingsActivity.getPackageName())));
                            } catch (Exception unused5) {
                                return;
                            }
                        }
                        break;
                }
            }
        });
    }
}
