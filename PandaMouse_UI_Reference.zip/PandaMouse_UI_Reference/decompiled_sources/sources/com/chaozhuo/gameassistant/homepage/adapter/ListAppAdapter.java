package com.chaozhuo.gameassistant.homepage.adapter;

import android.text.TextUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.panda.mouse.R;
import java.util.ArrayList;
import p047iIiii.ilI1LL;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class ListAppAdapter extends BaseQuickAdapter<ilI1LL, BaseViewHolder> {

    /* JADX INFO: renamed from: liIli, reason: collision with root package name */
    public int f7957liIli;

    public ListAppAdapter(ArrayList arrayList) {
        super(R.layout.item_add_app, arrayList);
        this.f7957liIli = 1;
    }

    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public final void convert(BaseViewHolder baseViewHolder, ilI1LL ili1ll) {
        ilI1LL ili1ll2 = ili1ll;
        baseViewHolder.setImageDrawable(R.id.image_icon, ili1ll2.f28714Iii1lill1);
        baseViewHolder.setText(R.id.text_app_name, ili1ll2.f28715Ilil11ILI);
        baseViewHolder.setText(R.id.text_package_name, TextUtils.isEmpty(ili1ll2.f28716lILlii1L) ? ili1ll2.f28717liIli : ili1ll2.f28716lILlii1L);
        baseViewHolder.addOnClickListener(R.id.text_add);
        baseViewHolder.addOnClickListener(R.id.id_checkbox);
        int i = this.f7957liIli;
        if (i == 2) {
            baseViewHolder.setVisible(R.id.text_add, true);
            baseViewHolder.setText(R.id.text_add, R.string.actions);
        } else if (i == 3) {
            baseViewHolder.setVisible(R.id.id_checkbox, true);
            baseViewHolder.getView(R.id.id_checkbox).setSelected(ili1ll2.f28713ILl);
        } else {
            baseViewHolder.setVisible(R.id.text_add, !ili1ll2.f28713ILl);
            baseViewHolder.setVisible(R.id.text_has_add, ili1ll2.f28713ILl);
        }
        if (baseViewHolder.getAdapterPosition() == getHeaderLayoutCount() + (this.mData.size() - 1)) {
            baseViewHolder.setVisible(R.id.view_line_full, true);
            baseViewHolder.setVisible(R.id.view_line_short, false);
        } else {
            baseViewHolder.setVisible(R.id.view_line_full, false);
            baseViewHolder.setVisible(R.id.view_line_short, true);
        }
    }
}
