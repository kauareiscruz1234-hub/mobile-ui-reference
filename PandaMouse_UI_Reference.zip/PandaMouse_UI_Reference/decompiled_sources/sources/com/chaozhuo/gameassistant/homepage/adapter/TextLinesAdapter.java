package com.chaozhuo.gameassistant.homepage.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.gms.internal.ads.Lllll11;
import com.panda.mouse.R;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class TextLinesAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public final void convert(BaseViewHolder baseViewHolder, String str) {
        baseViewHolder.setText(R.id.id_line_number, String.format(Lllll11.lLliL("%", String.valueOf(String.valueOf(getData().size()).length()), "d "), Integer.valueOf(baseViewHolder.getAbsoluteAdapterPosition() + 1)));
        baseViewHolder.setText(R.id.id_line_text, str);
    }
}
