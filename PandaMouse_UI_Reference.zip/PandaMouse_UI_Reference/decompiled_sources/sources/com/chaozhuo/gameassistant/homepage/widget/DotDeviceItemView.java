package com.chaozhuo.gameassistant.homepage.widget;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.homepage.ConnectStatusActivity;
import lLll1L.liIli;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class DotDeviceItemView extends LinearLayout {

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public TextView f8024IiiiL;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public ImageView f8025ilI11;

    public DotDeviceItemView(ConnectStatusActivity connectStatusActivity) {
        super(connectStatusActivity);
        Iii1lill1();
    }

    public final void Iii1lill1() {
        setOrientation(0);
        setGravity(16);
        TextView textView = new TextView(getContext());
        this.f8024IiiiL = textView;
        textView.setTextColor(-13421773);
        this.f8024IiiiL.setTextSize(13.0f);
        addView(this.f8024IiiiL);
    }

    public final void liIli(int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(i);
        gradientDrawable.setSize(liIli.ilI1(getContext(), 5.0f), liIli.ilI1(getContext(), 5.0f));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 16;
        layoutParams.topMargin = liIli.ilI1(getContext(), 15.0f);
        layoutParams.bottomMargin = liIli.ilI1(getContext(), 15.0f);
        layoutParams.setMarginEnd(liIli.ilI1(getContext(), 15.0f));
        ImageView imageView = new ImageView(getContext());
        this.f8025ilI11 = imageView;
        imageView.setLayoutParams(layoutParams);
        this.f8025ilI11.setImageDrawable(gradientDrawable);
        addView(this.f8025ilI11, 0);
    }

    public void setDeviceNameColor(int i) {
        this.f8024IiiiL.setTextColor(i);
    }

    public void setDevicesName(CharSequence charSequence) {
        this.f8024IiiiL.setText(charSequence);
    }

    public DotDeviceItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Iii1lill1();
    }

    public DotDeviceItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Iii1lill1();
    }
}
