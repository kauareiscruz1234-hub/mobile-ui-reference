package com.chaozhuo.gameassistant.homepage.widget;

import L11L.iL;
import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.chaozhuo.gameassistant.XApp;
import com.chaozhuo.gameassistant.inject.input.ILl;
import com.panda.mouse.R;
import iil1lIl.Iii1lill1;
import iil1lIl.Ilil11ILI;
import iil1lIl.liIli;
import java.util.ArrayList;
import java.util.List;
import p047iIiii.IIlI;
import p047iIiii.ilI1LL;
import p109llL.ILLl;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class GameLauncherLayout extends FrameLayout {
    public static final /* synthetic */ int II = 0;

    /* JADX INFO: renamed from: IL1LiliI, reason: collision with root package name */
    public final ArrayList f8026IL1LiliI;

    /* JADX INFO: renamed from: IiiiL, reason: collision with root package name */
    public final int f8027IiiiL;

    /* JADX INFO: renamed from: L11I, reason: collision with root package name */
    public int f8028L11I;

    /* JADX INFO: renamed from: LIIl, reason: collision with root package name */
    public boolean f8029LIIl;

    /* JADX INFO: renamed from: LLl1LlLL, reason: collision with root package name */
    public final int f8030LLl1LlLL;

    /* JADX INFO: renamed from: ii111, reason: collision with root package name */
    public int f8031ii111;

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public int f8032ilI11;

    /* JADX INFO: renamed from: lLL1L111l, reason: collision with root package name */
    public int f8033lLL1L111l;
    public Ilil11ILI lLi1I;

    public GameLauncherLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8032ilI11 = 4;
        this.f8027IiiiL = 1;
        this.f8033lLL1L111l = 10;
        this.f8030LLl1LlLL = 10;
        this.f8029LIIl = false;
        this.f8026IL1LiliI = new ArrayList();
        setOnClickListener(new iL(this, 11));
    }

    public final void Iii1lill1(boolean z) {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getTag() == null || TextUtils.equals(childAt.getTag().toString(), "false")) {
                childAt.findViewById(R.id.image_remove).setVisibility(z ? 0 : 8);
            }
        }
    }

    public final void Ilil11ILI() {
        removeAllViewsInLayout();
        int i = 0;
        int i2 = 0;
        while (true) {
            ArrayList arrayList = this.f8026IL1LiliI;
            if (i2 >= arrayList.size()) {
                requestLayout();
                return;
            }
            ilI1LL ili1ll = (ilI1LL) arrayList.get(i2);
            int i3 = 1;
            if (ili1ll != null) {
                View viewInflate = View.inflate(getContext(), R.layout.item_installed_app, null);
                View viewFindViewById = viewInflate.findViewById(R.id.layout_app);
                viewFindViewById.setOnClickListener(new liIli(this, ili1ll, i));
                viewFindViewById.setOnLongClickListener(new Iii1lill1(this, ili1ll));
                ((TextView) viewInflate.findViewById(R.id.text_app_name)).setText(ili1ll.f28715Ilil11ILI);
                ((ImageView) viewInflate.findViewById(R.id.image_icon)).setImageDrawable(ili1ll.f28714Iii1lill1);
                ImageView imageView = (ImageView) viewInflate.findViewById(R.id.image_remove);
                imageView.setVisibility(8);
                imageView.setOnClickListener(new liIli(this, ili1ll, i3));
                addViewInLayout(viewInflate, getChildCount(), new FrameLayout.LayoutParams(-2, -2));
            } else if (liIli.liIli.f33010ilI11) {
                liIli.liIli.lILil("GameLauncherLayout", "We can not bind the null AppInfo to View!");
            }
            i2++;
        }
    }

    public final void lILlii1L() {
        ArrayList arrayList = this.f8026IL1LiliI;
        ArrayList arrayList2 = new ArrayList(arrayList.size());
        for (int i = 0; i < arrayList.size(); i++) {
            if (arrayList.get(i) instanceof IIlI) {
                arrayList2.add((ilI1LL) arrayList.get(i));
            }
        }
        arrayList.removeAll(arrayList2);
        if (this.f8029LIIl) {
            return;
        }
        Context context = getContext();
        IIlI iIlI = new IIlI();
        iIlI.f28715Ilil11ILI = XApp.f7417IiiiL.getResources().getString(R.string.add_app);
        Resources resources = context.getResources();
        Resources.Theme theme = context.getTheme();
        ThreadLocal threadLocal = ILLl.f33098liIli;
        iIlI.f28714Iii1lill1 = resources.getDrawable(R.drawable.btn_app_add, theme);
        arrayList.add(iIlI);
    }

    public final void liIli(boolean z) {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getTag() == null || TextUtils.equals(childAt.getTag().toString(), "false")) {
                boolean z2 = i % 2 == 0;
                if (z) {
                    RotateAnimation rotateAnimation = z2 ? new RotateAnimation(-2.0f, 2.0f, this.f8031ii111 / 2, this.f8028L11I / 2) : new RotateAnimation(2.0f, -2.0f, this.f8031ii111 / 2, this.f8028L11I / 2);
                    rotateAnimation.setDuration(110L);
                    rotateAnimation.setRepeatCount(-1);
                    rotateAnimation.setRepeatMode(2);
                    rotateAnimation.setInterpolator(new LinearInterpolator());
                    childAt.startAnimation(rotateAnimation);
                } else {
                    childAt.clearAnimation();
                }
            }
        }
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int paddingStart = ((i3 - i) - getPaddingStart()) - getPaddingEnd();
        getPaddingTop();
        getPaddingBottom();
        for (int i5 = 0; i5 < getChildCount(); i5++) {
            int measuredWidth = getChildAt(0).getMeasuredWidth();
            int measuredHeight = getChildAt(0).getMeasuredHeight();
            View childAt = getChildAt(i5);
            int i6 = this.f8032ilI11;
            int i7 = i5 % i6;
            int i8 = i5 / i6;
            int i9 = i6 == 1 ? paddingStart : (paddingStart - measuredWidth) / (i6 - 1);
            if (i8 == 0) {
                int paddingStart2 = getPaddingStart() + (i7 * i9);
                int i10 = i8 * measuredHeight;
                childAt.layout(paddingStart2, i10, measuredWidth + paddingStart2, measuredHeight + i10);
            } else {
                int paddingStart3 = getPaddingStart() + (i7 * i9);
                int i11 = (i8 * this.f8033lLL1L111l) + (i8 * measuredHeight);
                childAt.layout(paddingStart3, i11, measuredWidth + paddingStart3, measuredHeight + i11);
            }
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        if (getChildCount() <= 0) {
            super.onMeasure(i, i2);
            return;
        }
        int mode = View.MeasureSpec.getMode(i);
        View.MeasureSpec.getSize(i);
        int mode2 = View.MeasureSpec.getMode(i2);
        View.MeasureSpec.getSize(i2);
        measureChild(getChildAt(0), 0, 0);
        this.f8031ii111 = getChildAt(0).getMeasuredWidth();
        this.f8028L11I = getChildAt(0).getMeasuredHeight();
        int i3 = this.f8030LLl1LlLL;
        if (mode2 == 1073741824) {
            if (mode == 1073741824) {
                super.onMeasure(i, i2);
                return;
            }
            int i4 = this.f8031ii111;
            int i5 = this.f8032ilI11;
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(((i5 - 1) * i3) + (i4 * i5), ILl.f8205iL1), i2);
            return;
        }
        int iMax = Math.max(((getChildCount() - 1) / this.f8032ilI11) + 1, this.f8027IiiiL);
        int i6 = ((iMax - 1) * i3) + (this.f8028L11I * iMax);
        if (mode == 1073741824) {
            super.onMeasure(i, View.MeasureSpec.makeMeasureSpec(i6, ILl.f8205iL1));
            return;
        }
        int i7 = this.f8031ii111;
        int i8 = this.f8032ilI11;
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(((i8 - 1) * i3) + (i7 * i8), ILl.f8205iL1), View.MeasureSpec.makeMeasureSpec(i6, ILl.f8205iL1));
    }

    public void setColumnCount(int i) {
        if (i <= 0) {
            throw new RuntimeException("setColumnCount must be > 0");
        }
        if (i != this.f8032ilI11) {
            this.f8032ilI11 = i;
            requestLayout();
        }
    }

    public void setEditing(boolean z) {
        if (this.f8029LIIl != z) {
            this.f8029LIIl = z;
            liIli(false);
            lILlii1L();
            Ilil11ILI();
            liIli(this.f8029LIIl);
            Iii1lill1(this.f8029LIIl);
        }
    }

    public void setNewAppList(List<ilI1LL> list) {
        if (list == null) {
            throw new AndroidRuntimeException("The data list is null");
        }
        ArrayList arrayList = this.f8026IL1LiliI;
        arrayList.clear();
        arrayList.addAll(list);
        liIli(false);
        if (arrayList.isEmpty()) {
            this.f8029LIIl = false;
        }
        lILlii1L();
        Ilil11ILI();
        liIli(this.f8029LIIl);
        Iii1lill1(this.f8029LIIl);
    }

    public void setOnItemActionListener(Ilil11ILI ilil11ILI) {
        this.lLi1I = ilil11ILI;
    }

    public void setRowSpacePX(int i) {
        this.f8033lLL1L111l = i;
    }

    public GameLauncherLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f8032ilI11 = 4;
        this.f8027IiiiL = 1;
        this.f8033lLL1L111l = 10;
        this.f8030LLl1LlLL = 10;
        this.f8029LIIl = false;
        this.f8026IL1LiliI = new ArrayList();
        setOnClickListener(new iL(this, 11));
    }
}
