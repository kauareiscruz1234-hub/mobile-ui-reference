package com.chaozhuo.gameassistant.homepage.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.InputDevice;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chaozhuo.gameassistant.czkeymap.il1;
import com.panda.mouse.R;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-09d09b7a3dc428966a6a6307eb641304dea77b0ab5c349b14eb76835f82973cd */
/* JADX INFO: loaded from: classes.dex */
public class IndicatorView extends LinearLayout {

    /* JADX INFO: renamed from: ilI11, reason: collision with root package name */
    public final ArrayList f8034ilI11;

    public IndicatorView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8034ilI11 = new ArrayList();
    }

    private String getConnectedDevicesName() {
        ArrayList arrayList = this.f8034ilI11;
        if (arrayList.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arrayList.size(); i++) {
            sb.append(((InputDevice) arrayList.get(i)).getName());
            sb.append(",");
        }
        return sb.substring(0, sb.length() - 1);
    }

    public final void liIli(boolean z) {
        ArrayList arrayList = this.f8034ilI11;
        arrayList.clear();
        arrayList.addAll(il1.liIli().f7571IiiiL);
        if (arrayList.isEmpty()) {
            ((ImageView) findViewById(R.id.status1)).setImageResource(R.drawable.index_icon_weilanjie);
            ((TextView) findViewById(R.id.info1)).setText(R.string.connect_no_peripherals);
        } else {
            ((ImageView) findViewById(R.id.status1)).setImageResource(R.drawable.index_icon_lanjie);
            ((TextView) findViewById(R.id.info1)).setText(getConnectedDevicesName());
        }
        if (z) {
            ((ImageView) findViewById(R.id.status2)).setImageResource(R.drawable.index_icon_lanjie);
            ((TextView) findViewById(R.id.info2)).setText(R.string.actived);
        } else {
            ((ImageView) findViewById(R.id.status2)).setImageResource(R.drawable.index_icon_weilanjie);
            ((TextView) findViewById(R.id.info2)).setText(R.string.not_active);
        }
    }

    public IndicatorView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f8034ilI11 = new ArrayList();
    }
}
